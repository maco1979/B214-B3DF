#!/usr/bin/env python3
"""
简单验证脚本 - 快速验证迁移学习和边缘计算集成的基本功能
"""

import sys
import os
import asyncio
from pathlib import Path

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def check_imports():
    """检查必要的导入是否可用"""
    print("检查模块导入...")
    
    modules_to_check = [
        "backend.src.migration_learning.risk_control",
        "backend.src.migration_learning.data_validation", 
        "backend.src.migration_learning.rule_constraints",
        "backend.src.migration_learning.warning_system",
        "backend.src.edge_computing.model_lightweight",
        "backend.src.edge_computing.deployment_strategy",
        "backend.src.edge_computing.cloud_edge_sync",
        "backend.src.edge_computing.resource_optimizer",
        "backend.src.integration.migration_integration",
        "backend.src.integration.edge_integration",
        "backend.src.integration.decision_integration",
        "backend.src.integration.api_integration",
        "backend.src.performance.performance_monitor",
        "backend.src.performance.performance_optimizer",
        "backend.src.performance.benchmark_test"
    ]
    
    missing_modules = []
    for module_path in modules_to_check:
        try:
            __import__(module_path)
            print(f"  [OK] {module_path}")
        except ImportError as e:
            print(f"  ❌ {module_path}: {e}")
            missing_modules.append(module_path)
    
    return len(missing_modules) == 0

def check_config_files():
    """检查配置文件是否存在"""
    print("\n检查配置文件...")
    
    config_files = [
        "backend/config/migration_edge_integration_config.py",
        "backend/config/performance_config.py",
        "backend/src/config.py"
    ]
    
    missing_files = []
    for config_file in config_files:
        file_path = Path(config_file)
        if file_path.exists():
            print(f"  ✅ {config_file}")
        else:
            print(f"  ❌ {config_file} - 文件不存在")
            missing_files.append(config_file)
    
    return len(missing_files) == 0

def check_test_files():
    """检查测试文件是否存在"""
    print("\n检查测试文件...")
    
    test_files = [
        "backend/tests/integration/test_migration_integration.py",
        "backend/tests/integration/test_edge_integration.py",
        "backend/tests/integration/test_decision_integration.py"
    ]
    
    missing_files = []
    for test_file in test_files:
        file_path = Path(test_file)
        if file_path.exists():
            print(f"  ✅ {test_file}")
        else:
            print(f"  ❌ {test_file} - 文件不存在")
            missing_files.append(test_file)
    
    return len(missing_files) == 0

def check_api_files():
    """检查API相关文件"""
    print("\n检查API文件...")
    
    api_files = [
        "backend/src/api/routes/performance.py",
        "frontend/src/services/api.ts",
        "frontend/src/hooks/useApi.ts",
        "frontend/src/pages/PerformanceMonitoring.tsx"
    ]
    
    missing_files = []
    for api_file in api_files:
        file_path = Path(api_file)
        if file_path.exists():
            print(f"  ✅ {api_file}")
        else:
            print(f"  ❌ {api_file} - 文件不存在")
            missing_files.append(api_file)
    
    return len(missing_files) == 0

def check_deployment_files():
    """检查部署相关文件"""
    print("\n🚀 检查部署文件...")
    
    deployment_files = [
        "deploy_integration_system.py",
        "run_performance_benchmark.py",
        "run_integration_tests.py",
        "docker-compose.yml"
    ]
    
    missing_files = []
    for deploy_file in deployment_files:
        file_path = Path(deploy_file)
        if file_path.exists():
            print(f"  ✅ {deploy_file}")
        else:
            print(f"  ❌ {deploy_file} - 文件不存在")
            missing_files.append(deploy_file)
    
    return len(missing_files) == 0

def check_directory_structure():
    """检查目录结构"""
    print("\n📂 检查目录结构...")
    
    directories = [
        "backend/src/migration_learning",
        "backend/src/edge_computing", 
        "backend/src/integration",
        "backend/src/performance",
        "backend/tests/integration",
        "backend/config",
        "frontend/src/pages",
        "frontend/src/hooks",
        "frontend/src/services"
    ]
    
    missing_dirs = []
    for directory in directories:
        dir_path = Path(directory)
        if dir_path.exists() and dir_path.is_dir():
            print(f"  ✅ {directory}/")
        else:
            print(f"  ❌ {directory}/ - 目录不存在")
            missing_dirs.append(directory)
    
    return len(missing_dirs) == 0

async def quick_functionality_check():
    """快速功能检查"""
    print("\n⚡ 快速功能检查...")
    
    try:
        # 尝试导入关键类
        from backend.src.migration_learning.risk_control import RiskControlSystem
        from backend.src.edge_computing.model_lightweight import ModelLightweight
        from backend.src.integration.migration_integration import MigrationIntegration
        
        print("  ✅ 关键类导入成功")
        
        # 尝试实例化对象
        risk_control = RiskControlSystem()
        lightweight = ModelLightweight()
        migration_integration = MigrationIntegration()
        
        print("  ✅ 对象实例化成功")
        
        # 检查基本方法
        if hasattr(risk_control, 'validate_migration_data') and \
           hasattr(lightweight, 'compress_model') and \
           hasattr(migration_integration, 'integrate_with_system'):
            print("  ✅ 基本方法检查通过")
            return True
        else:
            print("  ❌ 部分方法缺失")
            return False
            
    except Exception as e:
        print(f"  ❌ 功能检查失败: {e}")
        return False

def generate_summary_report(checks):
    """生成总结报告"""
    print("\n" + "="*60)
    print("📋 验证总结报告")
    print("="*60)
    
    total_checks = len(checks)
    passed_checks = sum(1 for check in checks.values() if check)
    failed_checks = total_checks - passed_checks
    
    for check_name, result in checks.items():
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{status}: {check_name}")
    
    print(f"\n总计: {passed_checks}/{total_checks} 项检查通过")
    print(f"成功率: {(passed_checks/total_checks)*100:.1f}%")
    
    if passed_checks == total_checks:
        print("\n🎉 所有检查通过！系统集成验证完成。")
        return True
    else:
        print(f"\n⚠️  {failed_checks} 项检查失败，请修复问题后重新验证。")
        return False

async def main():
    """主验证函数"""
    print("开始迁移学习和边缘计算集成验证...\n")
    
    # 执行各项检查
    checks = {
        "模块导入检查": check_imports(),
        "配置文件检查": check_config_files(),
        "测试文件检查": check_test_files(),
        "API文件检查": check_api_files(),
        "部署文件检查": check_deployment_files(),
        "目录结构检查": check_directory_structure(),
        "功能检查": await quick_functionality_check()
    }
    
    # 生成报告
    all_passed = generate_summary_report(checks)
    
    # 根据结果退出
    sys.exit(0 if all_passed else 1)

if __name__ == "__main__":
    asyncio.run(main())