"""
区块链管理器
统一管理区块链服务和智能合约交互
"""

import asyncio
import json
import hashlib
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from .fabric_client import FabricClient
from .smart_contracts import (
    ModelRegistryContract, 
    DataProvenanceContract, 
    FederatedLearningContract
)

logger = logging.getLogger(__name__)


class BlockchainManager:
    """区块链管理器"""
    
    def __init__(self, config_path: str = "blockchain/fabric_config.yaml"):
        self.config_path = config_path
        self.fabric_client = FabricClient(config_path)
        self.model_registry = None
        self.data_provenance = None
        self.federated_learning = None
        self.initialized = False
    
    async def initialize(self) -> bool:
        """初始化区块链管理器"""
        try:
            # 初始化Fabric客户端
            if not await self.fabric_client.initialize():
                logger.error("Fabric客户端初始化失败")
                return False
            
            # 初始化智能合约
            self.model_registry = ModelRegistryContract(self.fabric_client)
            self.data_provenance = DataProvenanceContract(self.fabric_client)
            self.federated_learning = FederatedLearningContract(self.fabric_client)
            
            self.initialized = True
            logger.info("区块链管理器初始化成功")
            return True
            
        except Exception as e:
            logger.error(f"区块链管理器初始化失败: {e}")
            return False
    
    # 模型管理相关方法
    async def register_ai_model(self, 
                              model_id: str,
                              model_data: bytes,
                              metadata: Dict[str, Any]) -> Dict[str, Any]:
        """注册AI模型到区块链"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        # 计算模型哈希
        model_hash = hashlib.sha256(model_data).hexdigest()
        
        # 添加额外元数据
        metadata.update({
            'model_size': len(model_data),
            'hash_algorithm': 'sha256',
            'registration_time': datetime.utcnow().isoformat()
        })
        
        return await self.model_registry.register_model(model_id, model_hash, metadata)
    
    async def update_model_version(self,
                                 model_id: str,
                                 new_model_data: bytes,
                                 version_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """更新模型版本"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        # 计算新模型哈希
        new_hash = hashlib.sha256(new_model_data).hexdigest()
        
        version_metadata.update({
            'update_time': datetime.utcnow().isoformat(),
            'hash_algorithm': 'sha256'
        })
        
        return await self.model_registry.update_model_version(
            model_id, new_hash, version_metadata
        )
    
    async def verify_model_integrity(self, 
                                   model_id: str, 
                                   model_data: bytes) -> Dict[str, Any]:
        """验证模型完整性"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        current_hash = hashlib.sha256(model_data).hexdigest()
        return await self.model_registry.verify_model_integrity(model_id, current_hash)
    
    # 数据溯源相关方法
    async def record_training_data_usage(self,
                                       data_id: str,
                                       model_id: str,
                                       data_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """记录训练数据使用"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        metadata = {
            'data_size': data_metadata.get('size', 0),
            'data_type': data_metadata.get('type', 'unknown'),
            'usage_purpose': 'training',
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return await self.data_provenance.record_data_usage(
            data_id, 'training', model_id, metadata
        )
    
    async def record_inference_data_usage(self,
                                        data_id: str,
                                        model_id: str,
                                        inference_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """记录推理数据使用"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        metadata = {
            'inference_time': inference_metadata.get('duration', 0),
            'confidence_score': inference_metadata.get('confidence', 0),
            'usage_purpose': 'inference',
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return await self.data_provenance.record_data_usage(
            data_id, 'inference', model_id, metadata
        )
    
    # 联邦学习相关方法
    async def start_federated_learning_round(self,
                                           round_id: str,
                                           model_id: str,
                                           edge_nodes: List[str]) -> Dict[str, Any]:
        """开始联邦学习轮次"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        return await self.federated_learning.start_federated_round(
            round_id, model_id, edge_nodes
        )
    
    async def submit_edge_model_update(self,
                                     round_id: str,
                                     edge_node_id: str,
                                     model_data: bytes,
                                     metrics: Dict[str, Any]) -> Dict[str, Any]:
        """提交边缘节点模型更新"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        model_hash = hashlib.sha256(model_data).hexdigest()
        
        contribution_metrics = {
            'model_hash': model_hash,
            'training_samples': metrics.get('samples', 0),
            'training_loss': metrics.get('loss', 0),
            'accuracy': metrics.get('accuracy', 0),
            'submission_time': datetime.utcnow().isoformat()
        }
        
        return await self.federated_learning.submit_model_update(
            round_id, edge_node_id, model_hash, contribution_metrics
        )
    
    async def complete_federated_round(self,
                                     round_id: str,
                                     aggregated_model_data: bytes,
                                     aggregation_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """完成联邦学习轮次"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        aggregated_hash = hashlib.sha256(aggregated_model_data).hexdigest()
        
        metrics = {
            'aggregated_model_hash': aggregated_hash,
            'participant_count': aggregation_metrics.get('participants', 0),
            'aggregation_algorithm': aggregation_metrics.get('algorithm', 'fedavg'),
            'completion_time': datetime.utcnow().isoformat()
        }
        
        return await self.federated_learning.complete_federated_round(
            round_id, aggregated_hash, metrics
        )
    
    # 查询方法
    async def get_model_history(self, model_id: str) -> Dict[str, Any]:
        """获取模型历史记录"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        return await self.model_registry.get_model_history(model_id)
    
    async def get_data_provenance(self, data_id: str) -> Dict[str, Any]:
        """获取数据溯源记录"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        return await self.data_provenance.get_data_provenance(data_id)
    
    async def get_federated_round_status(self, round_id: str) -> Dict[str, Any]:
        """获取联邦学习轮次状态"""
        if not self.initialized:
            raise RuntimeError("区块链管理器未初始化")
        
        return await self.federated_learning.get_round_status(round_id)
    
    # 系统管理方法
    async def get_blockchain_status(self) -> Dict[str, Any]:
        """获取区块链系统状态"""
        if not self.initialized:
            return {
                'status': 'not_initialized',
                'timestamp': datetime.utcnow().isoformat()
            }
        
        try:
            # 获取最新区块信息
            latest_block = await self.fabric_client.get_block_info(-1)
            
            return {
                'status': 'healthy',
                'initialized': True,
                'latest_block': latest_block if latest_block['success'] else None,
                'timestamp': datetime.utcnow().isoformat()
            }
        except Exception as e:
            logger.error(f"获取区块链状态失败: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    async def close(self):
        """关闭区块链管理器"""
        if self.initialized:
            await self.fabric_client.close()
            self.initialized = False
            logger.info("区块链管理器已关闭")