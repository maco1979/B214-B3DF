"""
区块链配置管理
包含Hyperledger Fabric网络配置和智能合约配置
"""

import os
from pathlib import Path
from typing import Dict, Any


class BlockchainConfig:
    """区块链配置类"""
    
    # 默认Fabric网络配置
    FABRIC_CONFIG = {
        "version": "1.0.0",
        "client": {
            "organization": "Org1",
            "credentialStore": {
                "path": "/tmp/hfc-kvs",
                "cryptoStore": {
                    "path": "/tmp/hfc-cvs"
                }
            }
        },
        "channels": {
            "mychannel": {
                "orderers": ["orderer.example.com"],
                "peers": {
                    "peer0.org1.example.com": {}
                }
            }
        },
        "organizations": {
            "Org1": {
                "mspid": "Org1MSP",
                "peers": ["peer0.org1.example.com"],
                "certificateAuthorities": ["ca.org1.example.com"]
            }
        },
        "orderers": {
            "orderer.example.com": {
                "url": "grpc://localhost:7050"
            }
        },
        "peers": {
            "peer0.org1.example.com": {
                "url": "grpc://localhost:7051",
                "eventUrl": "grpc://localhost:7053"
            }
        },
        "certificateAuthorities": {
            "ca.org1.example.com": {
                "url": "http://localhost:7054",
                "caName": "ca-org1"
            }
        }
    }
    
    # 智能合约配置
    SMART_CONTRACTS = {
        "model_registry": {
            "name": "modelregistry",
            "version": "1.0",
            "functions": [
                "registerModel",
                "updateModelVersion", 
                "getModelInfo",
                "verifyModelIntegrity",
                "getModelHistory"
            ]
        },
        "data_provenance": {
            "name": "dataprovenance", 
            "version": "1.0",
            "functions": [
                "recordDataUsage",
                "getDataProvenance",
                "verifyDataAuthenticity"
            ]
        },
        "federated_learning": {
            "name": "federatedlearning",
            "version": "1.0", 
            "functions": [
                "startFederatedRound",
                "submitModelUpdate",
                "completeFederatedRound",
                "getRoundStatus"
            ]
        }
    }
    
    # 区块链网络类型
    NETWORK_TYPES = {
        "development": {
            "orderer_url": "grpc://localhost:7050",
            "peer_url": "grpc://localhost:7051",
            "ca_url": "http://localhost:7054"
        },
        "production": {
            "orderer_url": "grpc://orderer.example.com:7050",
            "peer_url": "grpc://peer0.org1.example.com:7051", 
            "ca_url": "http://ca.org1.example.com:7054"
        }
    }
    
    @classmethod
    def get_config(cls, network_type: str = "development") -> Dict[str, Any]:
        """获取区块链配置"""
        config = cls.FABRIC_CONFIG.copy()
        
        # 根据网络类型更新URL
        if network_type in cls.NETWORK_TYPES:
            network_config = cls.NETWORK_TYPES[network_type]
            
            config["orderers"]["orderer.example.com"]["url"] = network_config["orderer_url"]
            config["peers"]["peer0.org1.example.com"]["url"] = network_config["peer_url"]
            config["peers"]["peer0.org1.example.com"]["eventUrl"] = network_config["peer_url"].replace("grpc", "grpc")
            config["certificateAuthorities"]["ca.org1.example.com"]["url"] = network_config["ca_url"]
        
        return config
    
    @classmethod
    def save_config_to_file(cls, config_path: str, network_type: str = "development"):
        """保存配置到文件"""
        import yaml
        
        config = cls.get_config(network_type)
        
        # 确保目录存在
        Path(config_path).parent.mkdir(parents=True, exist_ok=True)
        
        # 保存YAML配置
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
    
    @classmethod
    def get_smart_contract_config(cls, contract_type: str) -> Dict[str, Any]:
        """获取智能合约配置"""
        return cls.SMART_CONTRACTS.get(contract_type, {})
    
    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> bool:
        """验证配置有效性"""
        required_sections = ["channels", "organizations", "orderers", "peers"]
        
        for section in required_sections:
            if section not in config:
                return False
        
        return True