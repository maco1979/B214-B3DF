"""
区块链API路由
提供区块链相关的RESTful API接口
"""

from fastapi import APIRouter, HTTPException, Depends, status
from typing import Dict, Any, List
import json
import hashlib

from ....blockchain import BlockchainManager
from ....blockchain.config import BlockchainConfig

router = APIRouter(prefix="/blockchain", tags=["blockchain"])

# 全局区块链管理器实例
_blockchain_manager = None


def get_blockchain_manager():
    """获取区块链管理器依赖"""
    global _blockchain_manager
    if _blockchain_manager is None:
        _blockchain_manager = BlockchainManager()
    return _blockchain_manager


@router.on_event("startup")
async def startup_event():
    """应用启动时初始化区块链管理器"""
    global _blockchain_manager
    _blockchain_manager = BlockchainManager()
    await _blockchain_manager.initialize()


@router.on_event("shutdown")
async def shutdown_event():
    """应用关闭时清理区块链管理器"""
    global _blockchain_manager
    if _blockchain_manager:
        await _blockchain_manager.close()


@router.get("/status", summary="获取区块链系统状态")
async def get_blockchain_status(
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """获取区块链系统健康状态"""
    try:
        status = await manager.get_blockchain_status()
        return status
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取区块链状态失败: {str(e)}"
        )


@router.post("/models/register", summary="注册AI模型到区块链")
async def register_model(
    model_data: Dict[str, Any],
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """注册AI模型到区块链，记录模型哈希和元数据"""
    try:
        model_id = model_data.get("model_id")
        model_bytes = model_data.get("model_bytes", b"").encode() if isinstance(model_data.get("model_bytes"), str) else model_data.get("model_bytes", b"")
        metadata = model_data.get("metadata", {})
        
        if not model_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="模型ID不能为空"
            )
        
        result = await manager.register_ai_model(model_id, model_bytes, metadata)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.get("error", "模型注册失败")
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"模型注册失败: {str(e)}"
        )


@router.put("/models/{model_id}/version", summary="更新模型版本")
async def update_model_version(
    model_id: str,
    version_data: Dict[str, Any],
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """更新模型版本到区块链"""
    try:
        model_bytes = version_data.get("model_bytes", b"").encode() if isinstance(version_data.get("model_bytes"), str) else version_data.get("model_bytes", b"")
        version_metadata = version_data.get("metadata", {})
        
        result = await manager.update_model_version(model_id, model_bytes, version_metadata)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.get("error", "模型版本更新失败")
            )
        
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"模型版本更新失败: {str(e)}"
        )


@router.get("/models/{model_id}/verify", summary="验证模型完整性")
async def verify_model_integrity(
    model_id: str,
    model_hash: str,
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """验证模型完整性，检查模型哈希是否匹配"""
    try:
        # 模拟模型数据字节
        model_bytes = hashlib.sha256(model_hash.encode()).digest()
        
        result = await manager.verify_model_integrity(model_id, model_bytes)
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"模型完整性验证失败: {str(e)}"
        )


@router.get("/models/{model_id}/history", summary="获取模型版本历史")
async def get_model_history(
    model_id: str,
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """获取模型在区块链上的版本历史记录"""
    try:
        result = await manager.get_model_history(model_id)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="模型历史记录不存在"
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取模型历史失败: {str(e)}"
        )


@router.post("/data/provenance", summary="记录数据使用溯源")
async def record_data_provenance(
    provenance_data: Dict[str, Any],
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """记录数据使用溯源信息到区块链"""
    try:
        data_id = provenance_data.get("data_id")
        operation = provenance_data.get("operation", "training")
        model_id = provenance_data.get("model_id")
        metadata = provenance_data.get("metadata", {})
        
        if operation == "training":
            result = await manager.record_training_data_usage(data_id, model_id, metadata)
        elif operation == "inference":
            result = await manager.record_inference_data_usage(data_id, model_id, metadata)
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"不支持的操作类型: {operation}"
            )
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.get("error", "数据溯源记录失败")
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"数据溯源记录失败: {str(e)}"
        )


@router.get("/data/{data_id}/provenance", summary="获取数据溯源记录")
async def get_data_provenance(
    data_id: str,
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """获取数据在区块链上的完整溯源记录"""
    try:
        result = await manager.get_data_provenance(data_id)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="数据溯源记录不存在"
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取数据溯源记录失败: {str(e)}"
        )


@router.post("/federated/rounds/start", summary="开始联邦学习轮次")
async def start_federated_round(
    round_data: Dict[str, Any],
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """在区块链上开始新的联邦学习轮次"""
    try:
        round_id = round_data.get("round_id")
        model_id = round_data.get("model_id")
        participants = round_data.get("participants", [])
        
        result = await manager.start_federated_learning_round(round_id, model_id, participants)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.get("error", "联邦学习轮次启动失败")
            )
        
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"联邦学习轮次启动失败: {str(e)}"
        )


@router.post("/federated/rounds/{round_id}/submit", summary="提交联邦学习模型更新")
async def submit_federated_update(
    round_id: str,
    update_data: Dict[str, Any],
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """提交边缘节点的联邦学习模型更新"""
    try:
        participant_id = update_data.get("participant_id")
        model_bytes = update_data.get("model_bytes", b"").encode() if isinstance(update_data.get("model_bytes"), str) else update_data.get("model_bytes", b"")
        metrics = update_data.get("metrics", {})
        
        result = await manager.submit_edge_model_update(round_id, participant_id, model_bytes, metrics)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.get("error", "模型更新提交失败")
            )
        
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"模型更新提交失败: {str(e)}"
        )


@router.post("/federated/rounds/{round_id}/complete", summary="完成联邦学习轮次")
async def complete_federated_round(
    round_id: str,
    completion_data: Dict[str, Any],
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """完成联邦学习轮次并记录聚合结果"""
    try:
        model_bytes = completion_data.get("model_bytes", b"").encode() if isinstance(completion_data.get("model_bytes"), str) else completion_data.get("model_bytes", b"")
        metrics = completion_data.get("metrics", {})
        
        result = await manager.complete_federated_round(round_id, model_bytes, metrics)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.get("error", "联邦学习轮次完成失败")
            )
        
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"联邦学习轮次完成失败: {str(e)}"
        )


@router.get("/federated/rounds/{round_id}/status", summary="获取联邦学习轮次状态")
async def get_federated_round_status(
    round_id: str,
    manager: BlockchainManager = Depends(get_blockchain_manager)
) -> Dict[str, Any]:
    """获取联邦学习轮次的当前状态"""
    try:
        result = await manager.get_federated_round_status(round_id)
        
        if not result.get("success"):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="联邦学习轮次不存在"
            )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取联邦学习轮次状态失败: {str(e)}"
        )


@router.get("/config", summary="获取区块链配置信息")
async def get_blockchain_config() -> Dict[str, Any]:
    """获取当前区块链网络配置信息"""
    try:
        config = BlockchainConfig.get_config()
        return {
            "network_type": "development",
            "smart_contracts": BlockchainConfig.SMART_CONTRACTS,
            "fabric_config": config
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取配置信息失败: {str(e)}"
        )