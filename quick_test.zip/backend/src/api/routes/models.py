"""
模型管理API路由
提供模型的创建、查询、更新和删除功能
"""

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from ...core.services.model_manager import ModelManager

router = APIRouter(prefix="/models", tags=["models"])

# 创建模型管理器实例
model_manager = ModelManager()


class CreateModelRequest(BaseModel):
    """创建模型请求"""
    model_type: str  # "transformer", "vision", "diffusion"
    model_id: str
    hyperparameters: Dict[str, Any]
    description: Optional[str] = ""


class ModelResponse(BaseModel):
    """模型响应"""
    model_id: str
    model_type: str
    version: str
    created_at: str
    metrics: Dict[str, float]
    hyperparameters: Dict[str, Any]
    description: str


class ListModelsResponse(BaseModel):
    """模型列表响应"""
    models: List[ModelResponse]
    total_count: int


@router.post("/", response_model=ModelResponse, status_code=status.HTTP_201_CREATED)
async def create_model(request: CreateModelRequest):
    """创建新模型"""
    try:
        metadata = model_manager.create_model(
            model_type=request.model_type,
            model_id=request.model_id,
            hyperparameters=request.hyperparameters,
            description=request.description or ""
        )
        
        return ModelResponse(**metadata.to_dict())
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"创建模型失败: {str(e)}"
        )


@router.get("/", response_model=ListModelsResponse)
async def list_models():
    """获取模型列表"""
    try:
        models = model_manager.list_models()
        
        model_responses = [
            ModelResponse(**model.to_dict()) for model in models
        ]
        
        return ListModelsResponse(
            models=model_responses,
            total_count=len(model_responses)
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取模型列表失败: {str(e)}"
        )


@router.get("/{model_id}", response_model=ModelResponse)
async def get_model(model_id: str):
    """获取模型详情"""
    try:
        metadata = model_manager.get_model_info(model_id)
        return ModelResponse(**metadata.to_dict())
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取模型详情失败: {str(e)}"
        )


@router.put("/{model_id}/metrics")
async def update_model_metrics(model_id: str, metrics: Dict[str, float]):
    """更新模型指标"""
    try:
        model_manager.update_model_metrics(model_id, metrics)
        return {"message": "模型指标更新成功"}
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"更新模型指标失败: {str(e)}"
        )


@router.delete("/{model_id}")
async def delete_model(model_id: str):
    """删除模型"""
    try:
        model_manager.delete_model(model_id)
        return {"message": "模型删除成功"}
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"删除模型失败: {str(e)}"
        )