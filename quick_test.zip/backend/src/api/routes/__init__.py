"""
API路由模块
包含所有API端点的定义
"""

from .models import router as models_router
from .inference import router as inference_router
from .training import router as training_router
from .system import router as system_router
from .edge import router as edge_router
from .blockchain import router as blockchain_router
from .federated import router as federated_router
from .agriculture import router as agriculture_router
from .decision import router as decision_router
from .blockchain_decision import router as blockchain_decision_router
from .model_training_decision import router as model_training_decision_router
from .resource_decision import router as resource_decision_router
from .decision_monitoring import router as decision_monitoring_router

__all__ = ["models_router", "inference_router", "training_router", "system_router", "edge_router", "blockchain_router", "federated_router", "agriculture_router", "decision_router", "blockchain_decision_router", "model_training_decision_router", "resource_decision_router", "decision_monitoring_router"]