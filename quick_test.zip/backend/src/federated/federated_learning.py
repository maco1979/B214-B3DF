"""
联邦学习模块
实现联邦学习算法，支持多设备协同训练
"""

import json
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import numpy as np
import jax.numpy as jnp
from jax import random

from ..privacy.differential_privacy import DifferentialPrivacy


class FederatedLearningServer:
    """联邦学习服务器"""
    
    def __init__(self, model_architecture: Dict[str, Any]):
        """
        初始化联邦学习服务器
        
        Args:
            model_architecture: 模型架构定义
        """
        self.model_architecture = model_architecture
        self.global_model = self._initialize_model()
        self.clients = {}
        self.rounds_completed = 0
        self.training_history = []
        
        # 差分隐私配置
        self.dp_enabled = True
        self.dp_mechanism = DifferentialPrivacy(epsilon=1.0, delta=1e-5)
    
    def _initialize_model(self) -> Dict[str, Any]:
        """初始化全局模型"""
        # 这里应该根据模型架构初始化参数
        # 简化实现，返回空模型
        return {
            'parameters': {},
            'metadata': {
                'created_at': datetime.now().isoformat(),
                'version': '1.0.0',
                'architecture': self.model_architecture
            }
        }
    
    def register_client(self, client_id: str, client_info: Dict[str, Any]) -> bool:
        """注册客户端"""
        if client_id in self.clients:
            return False
        
        self.clients[client_id] = {
            'info': client_info,
            'registered_at': datetime.now().isoformat(),
            'last_seen': datetime.now().isoformat(),
            'status': 'active',
            'model_updates': []
        }
        return True
    
    def start_training_round(self, round_config: Dict[str, Any]) -> Dict[str, Any]:
        """开始新的训练轮次"""
        round_id = f"round_{self.rounds_completed + 1}"
        
        round_info = {
            'round_id': round_id,
            'start_time': datetime.now().isoformat(),
            'config': round_config,
            'participants': [],
            'status': 'active'
        }
        
        self.training_history.append(round_info)
        
        # 选择参与本轮训练的客户端
        selected_clients = self._select_clients(round_config.get('client_fraction', 0.1))
        
        # 准备发送给客户端的模型
        client_model = self._prepare_client_model()
        
        return {
            'round_id': round_id,
            'global_model': client_model,
            'selected_clients': selected_clients,
            'training_config': round_config
        }
    
    def _select_clients(self, fraction: float) -> List[str]:
        """选择参与训练的客户端"""
        active_clients = [cid for cid, info in self.clients.items() 
                         if info['status'] == 'active']
        
        num_selected = max(1, int(len(active_clients) * fraction))
        selected = np.random.choice(active_clients, num_selected, replace=False)
        
        return selected.tolist()
    
    def _prepare_client_model(self) -> Dict[str, Any]:
        """准备发送给客户端的模型"""
        return {
            'parameters': self.global_model['parameters'],
            'round': self.rounds_completed,
            'timestamp': datetime.now().isoformat()
        }
    
    def receive_client_update(self, 
                            client_id: str, 
                            round_id: str, 
                            update: Dict[str, Any]) -> bool:
        """接收客户端模型更新"""
        if client_id not in self.clients:
            return False
        
        # 验证轮次ID
        current_round = self.training_history[-1] if self.training_history else None
        if not current_round or current_round['round_id'] != round_id:
            return False
        
        # 存储更新
        update_info = {
            'client_id': client_id,
            'round_id': round_id,
            'update': update,
            'received_at': datetime.now().isoformat(),
            'data_size': update.get('data_size', 0),
            'training_time': update.get('training_time', 0)
        }
        
        self.clients[client_id]['model_updates'].append(update_info)
        current_round['participants'].append(client_id)
        
        return True
    
    def aggregate_updates(self, round_id: str) -> bool:
        """聚合客户端更新"""
        # 查找对应的轮次
        round_info = None
        for round_data in self.training_history:
            if round_data['round_id'] == round_id:
                round_info = round_data
                break
        
        if not round_info or round_info['status'] != 'active':
            return False
        
        # 收集所有更新
        updates = []
        data_sizes = []
        
        for client_id in round_info['participants']:
            client_updates = self.clients[client_id]['model_updates']
            latest_update = None
            
            # 找到该轮次的最新更新
            for update in reversed(client_updates):
                if update['round_id'] == round_id:
                    latest_update = update
                    break
            
            if latest_update:
                updates.append(latest_update['update'])
                data_sizes.append(latest_update['data_size'])
        
        if not updates:
            return False
        
        # 联邦平均算法
        self._federated_averaging(updates, data_sizes)
        
        # 更新轮次状态
        round_info['status'] = 'completed'
        round_info['end_time'] = datetime.now().isoformat()
        round_info['participants_count'] = len(updates)
        
        self.rounds_completed += 1
        
        return True
    
    def _federated_averaging(self, updates: List[Dict], data_sizes: List[int]):
        """联邦平均算法"""
        total_data_size = sum(data_sizes)
        
        # 计算加权平均
        averaged_params = {}
        
        for key in updates[0]['parameters'].keys():
            weighted_sum = None
            
            for i, update in enumerate(updates):
                weight = data_sizes[i] / total_data_size
                param_update = update['parameters'][key]
                
                if weighted_sum is None:
                    weighted_sum = param_update * weight
                else:
                    weighted_sum += param_update * weight
            
            # 应用差分隐私
            if self.dp_enabled:
                sensitivity = 1.0  # 需要根据实际敏感度调整
                weighted_sum = self.dp_mechanism.gaussian_mechanism(
                    weighted_sum, sensitivity
                )
            
            # 更新全局模型参数
            if key in self.global_model['parameters']:
                self.global_model['parameters'][key] += weighted_sum
            else:
                self.global_model['parameters'][key] = weighted_sum
    
    def get_server_status(self) -> Dict[str, Any]:
        """获取服务器状态"""
        active_clients = len([c for c in self.clients.values() if c['status'] == 'active'])
        
        return {
            'rounds_completed': self.rounds_completed,
            'total_clients': len(self.clients),
            'active_clients': active_clients,
            'current_round': self.training_history[-1] if self.training_history else None,
            'dp_enabled': self.dp_enabled,
            'model_metadata': self.global_model['metadata']
        }


class FederatedLearningClient:
    """联邦学习客户端"""
    
    def __init__(self, client_id: str, local_data: Any):
        """
        初始化联邦学习客户端
        
        Args:
            client_id: 客户端ID
            local_data: 本地数据
        """
        self.client_id = client_id
        self.local_data = local_data
        self.local_model = None
        self.training_history = []
    
    def initialize_with_global_model(self, global_model: Dict[str, Any]):
        """使用全局模型初始化本地模型"""
        self.local_model = {
            'parameters': global_model['parameters'].copy(),
            'metadata': global_model.get('metadata', {}),
            'client_id': self.client_id
        }
    
    def local_training(self, 
                      training_config: Dict[str, Any]) -> Dict[str, Any]:
        """本地训练"""
        if not self.local_model:
            raise ValueError("本地模型未初始化")
        
        start_time = time.time()
        
        # 模拟本地训练过程
        # 在实际实现中，这里应该包含完整的训练逻辑
        local_updates = self._simulate_training(training_config)
        
        training_time = time.time() - start_time
        
        update_info = {
            'client_id': self.client_id,
            'parameters': local_updates,
            'data_size': len(self.local_data) if hasattr(self.local_data, '__len__') else 0,
            'training_time': training_time,
            'training_config': training_config,
            'timestamp': datetime.now().isoformat()
        }
        
        self.training_history.append({
            'timestamp': datetime.now().isoformat(),
            'config': training_config,
            'update_size': len(str(local_updates))
        })
        
        return update_info
    
    def _simulate_training(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """模拟训练过程，返回参数更新"""
        # 简化实现，返回随机更新
        # 在实际系统中，这里应该包含真实的训练逻辑
        updates = {}
        
        if 'parameters' in self.local_model:
            for key, param in self.local_model['parameters'].items():
                # 生成模拟的梯度更新
                update_shape = param.shape if hasattr(param, 'shape') else (1,)
                gradient = np.random.normal(0, 0.01, update_shape)
                
                # 应用学习率
                learning_rate = config.get('learning_rate', 0.01)
                updates[key] = gradient * learning_rate
        
        return updates
    
    def get_client_status(self) -> Dict[str, Any]:
        """获取客户端状态"""
        return {
            'client_id': self.client_id,
            'data_size': len(self.local_data) if hasattr(self.local_data, '__len__') else 0,
            'training_sessions': len(self.training_history),
            'last_training': self.training_history[-1] if self.training_history else None,
            'model_initialized': self.local_model is not None
        }