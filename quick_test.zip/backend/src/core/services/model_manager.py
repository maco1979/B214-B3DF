"""
AI模型管理器
负责模型的加载、保存、版本管理和生命周期管理
"""

import json
import os
import pickle
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import jax
import jax.numpy as jnp
import flax
from flax.training import train_state
import optax

from ..models import TransformerModel, VisionModel, DiffusionModel


class ModelMetadata:
    """模型元数据"""
    
    def __init__(
        self,
        model_id: str,
        model_type: str,
        version: str = "1.0.0",
        created_at: Optional[str] = None,
        metrics: Optional[Dict[str, float]] = None,
        hyperparameters: Optional[Dict[str, Any]] = None,
        description: str = ""
    ):
        self.model_id = model_id
        self.model_type = model_type
        self.version = version
        self.created_at = created_at or datetime.now().isoformat()
        self.metrics = metrics or {}
        self.hyperparameters = hyperparameters or {}
        self.description = description
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "model_id": self.model_id,
            "model_type": self.model_type,
            "version": self.version,
            "created_at": self.created_at,
            "metrics": self.metrics,
            "hyperparameters": self.hyperparameters,
            "description": self.description
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModelMetadata":
        """从字典创建"""
        return cls(
            model_id=data["model_id"],
            model_type=data["model_type"],
            version=data["version"],
            created_at=data["created_at"],
            metrics=data["metrics"],
            hyperparameters=data["hyperparameters"],
            description=data["description"]
        )


class ModelManager:
    """AI模型管理器"""
    
    def __init__(self, models_dir: str = "models"):
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        
        # 内存中的模型缓存
        self._models: Dict[str, Tuple[Any, ModelMetadata]] = {}
        
        # 加载现有模型索引
        self._load_model_index()
    
    def _load_model_index(self):
        """加载模型索引"""
        index_file = self.models_dir / "model_index.json"
        if index_file.exists():
            with open(index_file, 'r') as f:
                self._model_index = json.load(f)
        else:
            self._model_index = {}
    
    def _save_model_index(self):
        """保存模型索引"""
        index_file = self.models_dir / "model_index.json"
        with open(index_file, 'w') as f:
            json.dump(self._model_index, f, indent=2)
    
    def create_model(
        self,
        model_type: str,
        model_id: str,
        hyperparameters: Dict[str, Any],
        description: str = ""
    ) -> ModelMetadata:
        """创建新模型"""
        
        # 检查模型ID是否已存在
        if model_id in self._model_index:
            raise ValueError(f"模型ID '{model_id}' 已存在")
        
        # 创建模型实例
        if model_type == "transformer":
            model = TransformerModel(**hyperparameters)
        elif model_type == "vision":
            model = VisionModel(**hyperparameters)
        elif model_type == "diffusion":
            model = DiffusionModel(**hyperparameters)
        else:
            raise ValueError(f"不支持的模型类型: {model_type}")
        
        # 初始化模型参数
        rng = jax.random.PRNGKey(0)
        dummy_input = self._create_dummy_input(model_type, hyperparameters)
        
        params = model.init(rng, dummy_input)
        
        # 创建训练状态
        tx = optax.adam(learning_rate=0.001)
        state = train_state.TrainState.create(
            apply_fn=model.apply,
            params=params,
            tx=tx
        )
        
        # 创建元数据
        metadata = ModelMetadata(
            model_id=model_id,
            model_type=model_type,
            hyperparameters=hyperparameters,
            description=description
        )
        
        # 保存模型
        self._save_model(model_id, state, metadata)
        
        # 更新索引
        self._model_index[model_id] = metadata.to_dict()
        self._save_model_index()
        
        return metadata
    
    def _create_dummy_input(self, model_type: str, hyperparameters: Dict[str, Any]) -> Any:
        """创建虚拟输入"""
        if model_type == "transformer":
            vocab_size = hyperparameters.get("vocab_size", 1000)
            seq_len = hyperparameters.get("max_seq_len", 512)
            return jnp.ones((1, seq_len), dtype=jnp.int32)
        
        elif model_type in ["vision", "diffusion"]:
            image_size = hyperparameters.get("image_size", 224)
            channels = hyperparameters.get("image_channels", 3)
            return jnp.ones((1, image_size, image_size, channels), dtype=jnp.float32)
        
        else:
            raise ValueError(f"不支持的模型类型: {model_type}")
    
    def _save_model(self, model_id: str, state: train_state.TrainState, metadata: ModelMetadata):
        """保存模型"""
        model_dir = self.models_dir / model_id
        model_dir.mkdir(exist_ok=True)
        
        # 保存模型参数
        with open(model_dir / "model_state.pkl", "wb") as f:
            pickle.dump(state, f)
        
        # 保存元数据
        with open(model_dir / "metadata.json", "w") as f:
            json.dump(metadata.to_dict(), f, indent=2)
    
    def load_model(self, model_id: str) -> Tuple[train_state.TrainState, ModelMetadata]:
        """加载模型"""
        
        # 检查缓存
        if model_id in self._models:
            return self._models[model_id]
        
        # 检查模型是否存在
        if model_id not in self._model_index:
            raise ValueError(f"模型 '{model_id}' 不存在")
        
        model_dir = self.models_dir / model_id
        
        # 加载元数据
        with open(model_dir / "metadata.json", "r") as f:
            metadata_dict = json.load(f)
        metadata = ModelMetadata.from_dict(metadata_dict)
        
        # 加载模型参数
        with open(model_dir / "model_state.pkl", "rb") as f:
            state = pickle.load(f)
        
        # 缓存模型
        self._models[model_id] = (state, metadata)
        
        return state, metadata
    
    def update_model_metrics(self, model_id: str, metrics: Dict[str, float]):
        """更新模型指标"""
        
        if model_id not in self._model_index:
            raise ValueError(f"模型 '{model_id}' 不存在")
        
        model_dir = self.models_dir / model_id
        
        # 加载元数据
        with open(model_dir / "metadata.json", "r") as f:
            metadata_dict = json.load(f)
        
        # 更新指标
        metadata_dict["metrics"].update(metrics)
        metadata_dict["metrics"]["last_updated"] = datetime.now().isoformat()
        
        # 保存更新后的元数据
        with open(model_dir / "metadata.json", "w") as f:
            json.dump(metadata_dict, f, indent=2)
        
        # 更新索引
        self._model_index[model_id] = metadata_dict
        self._save_model_index()
    
    def list_models(self) -> List[ModelMetadata]:
        """列出所有模型"""
        models = []
        for model_data in self._model_index.values():
            models.append(ModelMetadata.from_dict(model_data))
        
        # 按创建时间排序
        models.sort(key=lambda x: x.created_at, reverse=True)
        
        return models
    
    def delete_model(self, model_id: str):
        """删除模型"""
        
        if model_id not in self._model_index:
            raise ValueError(f"模型 '{model_id}' 不存在")
        
        # 从缓存中移除
        if model_id in self._models:
            del self._models[model_id]
        
        # 删除模型文件
        model_dir = self.models_dir / model_id
        if model_dir.exists():
            import shutil
            shutil.rmtree(model_dir)
        
        # 更新索引
        del self._model_index[model_id]
        self._save_model_index()
    
    def get_model_info(self, model_id: str) -> ModelMetadata:
        """获取模型信息"""
        
        if model_id not in self._model_index:
            raise ValueError(f"模型 '{model_id}' 不存在")
        
        return ModelMetadata.from_dict(self._model_index[model_id])