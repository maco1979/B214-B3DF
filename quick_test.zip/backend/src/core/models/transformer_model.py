"""
基于JAX和Flax的Transformer模型实现
支持高效并行训练和推理
"""

from typing import Any, Dict, Optional, Tuple
import jax
import jax.numpy as jnp
import flax.linen as nn
from flax.core.frozen_dict import FrozenDict


class MultiHeadAttention(nn.Module):
    """多头注意力机制"""
    d_model: int
    num_heads: int
    
    def setup(self):
        self.d_k = self.d_model // self.num_heads
        self.w_q = nn.Dense(self.d_model, use_bias=False)
        self.w_k = nn.Dense(self.d_model, use_bias=False)
        self.w_v = nn.Dense(self.d_model, use_bias=False)
        self.w_o = nn.Dense(self.d_model)
    
    def __call__(self, q, k, v, mask=None):
        batch_size, seq_len, _ = q.shape
        
        # 线性变换
        q = self.w_q(q).reshape(batch_size, seq_len, self.num_heads, self.d_k)
        k = self.w_k(k).reshape(batch_size, -1, self.num_heads, self.d_k)
        v = self.w_v(v).reshape(batch_size, -1, self.num_heads, self.d_k)
        
        # 转置以进行批量矩阵乘法
        q = q.transpose(0, 2, 1, 3)  # (batch, heads, seq_len, d_k)
        k = k.transpose(0, 2, 3, 1)  # (batch, heads, d_k, seq_len)
        v = v.transpose(0, 2, 1, 3)  # (batch, heads, seq_len, d_k)
        
        # 注意力分数计算
        scores = jnp.matmul(q, k) / jnp.sqrt(self.d_k)
        
        if mask is not None:
            scores = scores + mask
        
        # 注意力权重
        attn_weights = jax.nn.softmax(scores, axis=-1)
        
        # 上下文向量
        context = jnp.matmul(attn_weights, v)
        context = context.transpose(0, 2, 1, 3).reshape(batch_size, seq_len, self.d_model)
        
        return self.w_o(context)


class FeedForward(nn.Module):
    """前馈神经网络"""
    d_model: int
    d_ff: int
    
    def setup(self):
        self.linear1 = nn.Dense(self.d_ff)
        self.linear2 = nn.Dense(self.d_model)
    
    def __call__(self, x):
        return self.linear2(nn.gelu(self.linear1(x)))


class TransformerEncoderLayer(nn.Module):
    """Transformer编码器层"""
    d_model: int
    num_heads: int
    d_ff: int
    dropout_rate: float = 0.1
    
    def setup(self):
        self.self_attn = MultiHeadAttention(d_model=self.d_model, num_heads=self.num_heads)
        self.feed_forward = FeedForward(d_model=self.d_model, d_ff=self.d_ff)
        self.norm1 = nn.LayerNorm()
        self.norm2 = nn.LayerNorm()
        self.dropout = nn.Dropout(self.dropout_rate)
    
    def __call__(self, x, mask=None, deterministic=True):
        # 自注意力子层
        attn_output = self.self_attn(x, x, x, mask)
        x = self.norm1(x + self.dropout(attn_output, deterministic=deterministic))
        
        # 前馈子层
        ff_output = self.feed_forward(x)
        x = self.norm2(x + self.dropout(ff_output, deterministic=deterministic))
        
        return x


class TransformerModel(nn.Module):
    """Transformer模型"""
    vocab_size: int
    d_model: int = 512
    num_layers: int = 6
    num_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 512
    dropout_rate: float = 0.1
    
    def setup(self):
        self.token_embedding = nn.Embed(num_embeddings=self.vocab_size, features=self.d_model)
        self.position_embedding = nn.Embed(num_embeddings=self.max_seq_len, features=self.d_model)
        
        self.layers = [
            TransformerEncoderLayer(
                d_model=self.d_model,
                num_heads=self.num_heads,
                d_ff=self.d_ff,
                dropout_rate=self.dropout_rate
            ) for _ in range(self.num_layers)
        ]
        
        self.output_projection = nn.Dense(self.vocab_size)
        self.dropout = nn.Dropout(self.dropout_rate)
    
    def __call__(self, input_ids, deterministic=True):
        batch_size, seq_len = input_ids.shape
        
        # 嵌入层
        token_embeddings = self.token_embedding(input_ids)
        position_ids = jnp.arange(seq_len)
        position_embeddings = self.position_embedding(position_ids)
        
        # 合并嵌入
        x = token_embeddings + position_embeddings
        x = self.dropout(x, deterministic=deterministic)
        
        # 注意力掩码
        mask = jnp.triu(jnp.ones((seq_len, seq_len)) * -jnp.inf, k=1)
        
        # Transformer层
        for layer in self.layers:
            x = layer(x, mask=mask, deterministic=deterministic)
        
        # 输出投影
        logits = self.output_projection(x)
        
        return logits
    
    def generate(self, params, rng, prompt, max_length=100, temperature=1.0):
        """文本生成"""
        def step_fn(carry, _):
            tokens, rng = carry
            
            # 获取当前预测
            logits = self.apply(params, tokens[None, :], deterministic=False)
            next_token_logits = logits[0, -1, :] / temperature
            
            # 采样
            rng, sample_rng = jax.random.split(rng)
            next_token = jax.random.categorical(sample_rng, next_token_logits)
            
            # 更新序列
            tokens = jnp.concatenate([tokens, next_token[None]], axis=0)
            
            return (tokens, rng), next_token
        
        # 初始化序列
        tokens = prompt
        
        # 生成序列
        (tokens, _), _ = jax.lax.scan(
            step_fn, (tokens, rng), jnp.arange(max_length)
        )
        
        return tokens