from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# 创建FastAPI应用
app = FastAPI(
    title="AI平台API",
    description="农业AI迁移学习与边缘计算集成平台",
    version="1.0.0"
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "AI平台API服务运行正常"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": "2025-12-21T15:10:00Z"}

@app.get("/metrics")
async def metrics():
    """提供Prometheus监控指标"""
    return {
        "status": "ok",
        "metrics": {
            "requests_total": 1000,
            "success_rate": 0.98,
            "response_time_ms": 120
        }
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)