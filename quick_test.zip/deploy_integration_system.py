#!/usr/bin/env python3
"""
迁移学习和边缘计算集成系统部署脚本
自动化部署完整的集成系统，包括性能监控和优化功能
"""

import os
import sys
import json
import subprocess
import time
import argparse
from datetime import datetime
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from backend.config.migration_edge_integration_config import (
    IntegrationConfigManager, 
    DeploymentEnvironment, 
    OptimizationStrategy
)


def setup_environment():
    """设置部署环境"""
    print("🚀 设置部署环境...")
    
    # 创建必要的目录
    directories = [
        "logs",
        "data",
        "models",
        "config",
        "tmp"
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"  创建目录: {directory}")
    
    # 设置环境变量
    env_vars = {
        "PYTHONPATH": str(project_root),
        "PROJECT_ROOT": str(project_root),
        "LOG_LEVEL": "INFO"
    }
    
    for key, value in env_vars.items():
        os.environ[key] = value
        print(f"  设置环境变量: {key}={value}")
    
    print("✅ 环境设置完成")


def install_dependencies():
    """安装项目依赖"""
    print("📦 安装项目依赖...")
    
    # 检查并安装后端依赖
    if os.path.exists("backend/requirements.txt"):
        print("  安装后端依赖...")
        try:
            subprocess.run([
                sys.executable, "-m", "pip", "install", 
                "-r", "backend/requirements.txt"
            ], check=True)
            print("  ✅ 后端依赖安装完成")
        except subprocess.CalledProcessError as e:
            print(f"  ❌ 后端依赖安装失败: {e}")
            return False
    
    # 检查并安装前端依赖
    if os.path.exists("frontend/package.json"):
        print("  安装前端依赖...")
        try:
            # 检查是否安装了Node.js
            subprocess.run(["node", "--version"], check=True, capture_output=True)
            
            # 安装npm包
            os.chdir("frontend")
            subprocess.run(["npm", "install"], check=True)
            os.chdir("..")
            print("  ✅ 前端依赖安装完成")
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            print(f"  ⚠️  前端依赖安装跳过: {e}")
    
    print("✅ 依赖安装完成")
    return True


def load_configuration(environment, strategy):
    """加载配置"""
    print("⚙️  加载配置...")
    
    config_manager = IntegrationConfigManager()
    
    try:
        # 获取优化配置
        config = config_manager.get_optimized_config(
            DeploymentEnvironment(environment),
            OptimizationStrategy(strategy)
        )
        
        # 保存配置到文件
        config_file = "config/integration_config.json"
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config.to_dict(), f, indent=2, ensure_ascii=False)
        
        print(f"  ✅ 配置已保存到: {config_file}")
        print(f"  环境: {environment}")
        print(f"  优化策略: {strategy}")
        
        return config, config_file
        
    except Exception as e:
        print(f"  ❌ 配置加载失败: {e}")
        return None, None


def validate_configuration(config):
    """验证配置"""
    print("🔍 验证配置...")
    
    config_manager = IntegrationConfigManager()
    validation_result = config_manager.validate_deployment(config)
    
    if validation_result["valid"]:
        print("  ✅ 配置验证通过")
        
        # 显示警告和建议
        if validation_result["warnings"]:
            print("  ⚠️  警告:")
            for warning in validation_result["warnings"]:
                print(f"    - {warning}")
        
        if validation_result["recommendations"]:
            print("  💡 建议:")
            for recommendation in validation_result["recommendations"]:
                print(f"    - {recommendation}")
        
        return True
    else:
        print("  ❌ 配置验证失败:")
        for error in validation_result["errors"]:
            print(f"    - {error}")
        return False


def start_backend_services(config):
    """启动后端服务"""
    print("🔧 启动后端服务...")
    
    services = [
        {
            "name": "API服务",
            "module": "src.api",
            "env": {
                "CONFIG_FILE": "config/integration_config.json"
            }
        },
        {
            "name": "性能监控服务",
            "module": "src.performance.performance_monitor",
            "env": {
                "PERFORMANCE_MONITORING_ENABLED": "true"
            }
        },
        {
            "name": "边缘计算同步服务",
            "module": "src.edge_computing.cloud_edge_sync",
            "env": {
                "EDGE_COMPUTING_ENABLED": str(config.edge_computing.enabled).lower()
            }
        }
    ]
    
    processes = []
    
    for service in services:
        print(f"  启动 {service['name']}...")
        
        # 设置环境变量
        env = os.environ.copy()
        env.update(service.get("env", {}))
        
        try:
            process = subprocess.Popen([
                sys.executable, "-m", service["module"]
            ], env=env, cwd="backend")
            
            processes.append({
                "name": service["name"],
                "process": process,
                "module": service["module"]
            })
            
            print(f"  ✅ {service['name']} 已启动 (PID: {process.pid})")
            
            # 给服务一些启动时间
            time.sleep(2)
            
        except Exception as e:
            print(f"  ❌ 启动 {service['name']} 失败: {e}")
    
    return processes


def start_frontend_service():
    """启动前端服务"""
    print("🌐 启动前端服务...")
    
    if not os.path.exists("frontend/package.json"):
        print("  ⚠️  前端项目不存在，跳过前端启动")
        return None
    
    try:
        # 切换到前端目录
        os.chdir("frontend")
        
        # 启动开发服务器
        process = subprocess.Popen([
            "npm", "run", "dev"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # 返回项目根目录
        os.chdir("..")
        
        print(f"  ✅ 前端服务已启动 (PID: {process.pid})")
        
        # 等待前端服务启动
        time.sleep(5)
        
        return process
        
    except Exception as e:
        print(f"  ❌ 启动前端服务失败: {e}")
        return None


def run_health_check():
    """运行健康检查"""
    print("🏥 运行健康检查...")
    
    health_endpoints = [
        ("API服务", "http://localhost:8000/system/health"),
        ("性能监控", "http://localhost:8000/performance/summary"),
    ]
    
    import requests
    
    all_healthy = True
    
    for service_name, endpoint in health_endpoints:
        try:
            response = requests.get(endpoint, timeout=10)
            
            if response.status_code == 200:
                print(f"  ✅ {service_name} 健康检查通过")
            else:
                print(f"  ❌ {service_name} 健康检查失败: HTTP {response.status_code}")
                all_healthy = False
                
        except Exception as e:
            print(f"  ❌ {service_name} 健康检查失败: {e}")
            all_healthy = False
    
    return all_healthy


def run_integration_tests():
    """运行集成测试"""
    print("🧪 运行集成测试...")
    
    test_modules = [
        "tests.integration.test_migration_integration",
        "tests.integration.test_edge_integration",
        "tests.integration.test_decision_integration"
    ]
    
    all_passed = True
    
    for test_module in test_modules:
        print(f"  运行 {test_module}...")
        
        try:
            result = subprocess.run([
                sys.executable, "-m", "pytest", 
                f"backend/{test_module.replace('.', '/')}.py",
                "-v"
            ], cwd=".", capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"  ✅ {test_module} 测试通过")
            else:
                print(f"  ❌ {test_module} 测试失败")
                print(f"    错误输出: {result.stderr}")
                all_passed = False
                
        except Exception as e:
            print(f"  ❌ {test_module} 测试执行失败: {e}")
            all_passed = False
    
    return all_passed


def generate_deployment_report(config, processes, health_check_passed, tests_passed):
    """生成部署报告"""
    print("📊 生成部署报告...")
    
    report = {
        "timestamp": datetime.now().isoformat(),
        "environment": config.environment.value,
        "optimization_strategy": config.optimization_strategy.value,
        "services": [
            {
                "name": process_info["name"],
                "pid": process_info["process"].pid,
                "status": "running" if process_info["process"].poll() is None else "stopped"
            }
            for process_info in processes
        ],
        "health_check": "passed" if health_check_passed else "failed",
        "integration_tests": "passed" if tests_passed else "failed",
        "overall_status": "success" if (health_check_passed and tests_passed) else "partial"
    }
    
    # 保存报告
    report_file = "logs/deployment_report.json"
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"  ✅ 部署报告已保存到: {report_file}")
    
    # 显示摘要
    print("\n📋 部署摘要:")
    print(f"  环境: {config.environment.value}")
    print(f"  优化策略: {config.optimization_strategy.value}")
    print(f"  运行服务: {len([s for s in report['services'] if s['status'] == 'running'])}")
    print(f"  健康检查: {report['health_check']}")
    print(f"  集成测试: {report['integration_tests']}")
    print(f"  总体状态: {report['overall_status']}")
    
    return report


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='迁移学习和边缘计算集成系统部署脚本')
    parser.add_argument('--environment', '-e', 
                       choices=['development', 'testing', 'staging', 'production', 'edge'],
                       default='development',
                       help='部署环境')
    parser.add_argument('--strategy', '-s',
                       choices=['performance', 'accuracy', 'resource_efficiency', 'latency', 'cost'],
                       default='performance',
                       help='优化策略')
    parser.add_argument('--skip-tests', action='store_true',
                       help='跳过集成测试')
    parser.add_argument('--skip-frontend', action='store_true',
                       help='跳过前端部署')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("🚀 迁移学习和边缘计算集成系统部署")
    print("=" * 60)
    
    try:
        # 1. 设置环境
        setup_environment()
        
        # 2. 安装依赖
        if not install_dependencies():
            print("❌ 依赖安装失败，退出部署")
            return 1
        
        # 3. 加载和验证配置
        config, config_file = load_configuration(args.environment, args.strategy)
        if not config:
            print("❌ 配置加载失败，退出部署")
            return 1
        
        if not validate_configuration(config):
            print("❌ 配置验证失败，退出部署")
            return 1
        
        # 4. 启动后端服务
        backend_processes = start_backend_services(config)
        if not backend_processes:
            print("❌ 后端服务启动失败，退出部署")
            return 1
        
        # 5. 启动前端服务（可选）
        frontend_process = None
        if not args.skip_frontend:
            frontend_process = start_frontend_service()
        
        # 6. 等待服务启动
        print("⏳ 等待服务启动...")
        time.sleep(10)
        
        # 7. 运行健康检查
        health_check_passed = run_health_check()
        
        # 8. 运行集成测试（可选）
        tests_passed = True
        if not args.skip_tests:
            tests_passed = run_integration_tests()
        
        # 9. 生成部署报告
        report = generate_deployment_report(config, backend_processes, 
                                          health_check_passed, tests_passed)
        
        # 10. 显示部署结果
        print("\n" + "=" * 60)
        if report["overall_status"] == "success":
            print("🎉 部署成功完成!")
        else:
            print("⚠️  部署完成，但存在一些问题")
        
        print("\n📡 服务访问信息:")
        print("  后端API: http://localhost:8000")
        if frontend_process:
            print("  前端界面: http://localhost:5173")
        print("  性能监控: http://localhost:8000/performance")
        
        print("\n🔧 管理命令:")
        print("  停止服务: Ctrl+C")
        print("  查看日志: tail -f logs/*.log")
        
        print("\n💡 下一步:")
        print("  1. 访问前端界面验证功能")
        print("  2. 查看性能监控仪表板")
        print("  3. 运行基准测试验证性能")
        
        print("\n" + "=" * 60)
        
        # 等待用户中断
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 收到中断信号，停止服务...")
        
        # 清理进程
        print("🧹 清理进程...")
        for process_info in backend_processes:
            try:
                process_info["process"].terminate()
                process_info["process"].wait(timeout=5)
                print(f"  ✅ 停止 {process_info['name']}")
            except:
                process_info["process"].kill()
                print(f"  ⚠️  强制停止 {process_info['name']}")
        
        if frontend_process:
            try:
                frontend_process.terminate()
                frontend_process.wait(timeout=5)
                print("  ✅ 停止前端服务")
            except:
                frontend_process.kill()
                print("  ⚠️  强制停止前端服务")
        
        print("✅ 清理完成")
        
        return 0 if report["overall_status"] == "success" else 1
        
    except Exception as e:
        print(f"❌ 部署过程中发生错误: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())