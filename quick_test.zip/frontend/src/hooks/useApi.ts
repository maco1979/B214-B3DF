import { useState, useEffect, useCallback } from 'react'
import { apiClient, ApiResponse } from '@/services/api'

// API状态类型
export interface ApiState<T> {
  data: T | null
  loading: boolean
  error: string | null
  success: boolean
}

// 初始状态
const initialApiState = {
  data: null,
  loading: false,
  error: null,
  success: false,
}

// 通用API Hook
export function useApi<T>() {
  const [state, setState] = useState<ApiState<T>>(initialApiState)

  const execute = useCallback(async (
    apiCall: () => Promise<ApiResponse<T>>,
    onSuccess?: (data: T) => void,
    onError?: (error: string) => void
  ) => {
    setState(prev => ({ ...prev, loading: true, error: null }))
    
    try {
      const response = await apiCall()
      
      if (response.success && response.data) {
        setState({
          data: response.data,
          loading: false,
          error: null,
          success: true,
        })
        onSuccess?.(response.data)
      } else {
        setState({
          data: null,
          loading: false,
          error: response.error || 'Unknown error',
          success: false,
        })
        onError?.(response.error || 'Unknown error')
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Network error'
      setState({
        data: null,
        loading: false,
        error: errorMessage,
        success: false,
      })
      onError?.(errorMessage)
    }
  }, [])

  const reset = useCallback(() => {
    setState(initialApiState)
  }, [])

  return {
    ...state,
    execute,
    reset,
  }
}

// 模型相关Hooks
export function useModels() {
  const apiState = useApi<any[]>()
  
  const fetchModels = useCallback(() => {
    return apiState.execute(() => apiClient.getModels())
  }, [apiState.execute])

  useEffect(() => {
    fetchModels()
  }, [fetchModels])

  return {
    ...apiState,
    refetch: fetchModels,
  }
}

export function useModel(id: string) {
  const apiState = useApi<any>()
  
  const fetchModel = useCallback(() => {
    if (!id) return
    return apiState.execute(() => apiClient.getModel(id))
  }, [apiState.execute, id])

  useEffect(() => {
    fetchModel()
  }, [fetchModel])

  return {
    ...apiState,
    refetch: fetchModel,
  }
}

// 推理相关Hooks
export function useInference() {
  const apiState = useApi<any>()
  
  const runInference = useCallback((request: any) => {
    return apiState.execute(() => apiClient.runInference(request))
  }, [apiState.execute])

  return {
    ...apiState,
    runInference,
  }
}

// 训练任务相关Hooks
export function useTrainingTasks() {
  const apiState = useApi<any[]>()
  
  const fetchTasks = useCallback(() => {
    return apiState.execute(() => apiClient.getTrainingTasks())
  }, [apiState.execute])

  useEffect(() => {
    fetchTasks()
  }, [fetchTasks])

  return {
    ...apiState,
    refetch: fetchTasks,
  }
}

// 区块链相关Hooks
export function useBlockchainStatus() {
  const apiState = useApi<any>()
  
  const fetchStatus = useCallback(() => {
    return apiState.execute(() => apiClient.getBlockchainStatus())
  }, [apiState.execute])

  useEffect(() => {
    fetchStatus()
  }, [fetchStatus])

  return {
    ...apiState,
    refetch: fetchStatus,
  }
}

export function useModelVerification() {
  const apiState = useApi<any>()
  
  const verifyModel = useCallback((modelId: string, modelHash: string) => {
    return apiState.execute(() => apiClient.verifyModelIntegrity(modelId, modelHash))
  }, [apiState.execute])

  return {
    ...apiState,
    verifyModel,
  }
}

// 系统监控相关Hooks
export function useSystemMetrics() {
  const apiState = useApi<any>()
  
  const fetchMetrics = useCallback(() => {
    return apiState.execute(() => apiClient.getSystemMetrics())
  }, [apiState.execute])

  useEffect(() => {
    fetchMetrics()
  }, [fetchMetrics])

  return {
    ...apiState,
    refetch: fetchMetrics,
  }
}

// 边缘计算相关Hooks
export function useEdgeDevices() {
  const apiState = useApi<any[]>()
  
  const fetchDevices = useCallback(() => {
    return apiState.execute(() => apiClient.getEdgeDevices())
  }, [apiState.execute])

  useEffect(() => {
    fetchDevices()
  }, [fetchDevices])

  return {
    ...apiState,
    refetch: fetchDevices,
  }
}

// 轮询Hook
export function usePolling<T>(
  apiCall: () => Promise<ApiResponse<T>>,
  interval: number = 5000,
  enabled: boolean = true
) {
  const apiState = useApi<T>()

  useEffect(() => {
    if (!enabled) return

    const fetchData = () => {
      apiState.execute(apiCall)
    }

    // 立即执行一次
    fetchData()

    // 设置轮询
    const pollInterval = setInterval(fetchData, interval)

    return () => {
      clearInterval(pollInterval)
    }
  }, [apiCall, interval, enabled, apiState.execute])

  return apiState
}

// 性能监控相关Hooks
export function usePerformanceMetrics() {
  const apiState = useApi<any>()
  
  const fetchMetrics = useCallback(() => {
    return apiState.execute(() => apiClient.getPerformanceMetrics())
  }, [apiState.execute])

  useEffect(() => {
    fetchMetrics()
  }, [fetchMetrics])

  return {
    ...apiState,
    refetch: fetchMetrics,
  }
}

export function usePerformanceSummary(timeRange: string = "1h") {
  const apiState = useApi<any>()
  
  const fetchSummary = useCallback(() => {
    return apiState.execute(() => apiClient.getPerformanceSummary(timeRange))
  }, [apiState.execute, timeRange])

  useEffect(() => {
    fetchSummary()
  }, [fetchSummary])

  return {
    ...apiState,
    refetch: fetchSummary,
  }
}

export function useOptimizationStatus() {
  const apiState = useApi<any>()
  
  const fetchStatus = useCallback(() => {
    return apiState.execute(() => apiClient.getOptimizationStatus())
  }, [apiState.execute])

  useEffect(() => {
    fetchStatus()
  }, [fetchStatus])

  return {
    ...apiState,
    refetch: fetchStatus,
  }
}

export function useOptimizationRecommendations() {
  const apiState = useApi<any[]>()
  
  const fetchRecommendations = useCallback(() => {
    return apiState.execute(() => apiClient.getOptimizationRecommendations())
  }, [apiState.execute])

  useEffect(() => {
    fetchRecommendations()
  }, [fetchRecommendations])

  return {
    ...apiState,
    refetch: fetchRecommendations,
  }
}

export function usePerformanceAlerts() {
  const apiState = useApi<any>()
  
  const fetchAlerts = useCallback(() => {
    return apiState.execute(() => apiClient.getPerformanceAlerts())
  }, [apiState.execute])

  useEffect(() => {
    fetchAlerts()
  }, [fetchAlerts])

  return {
    ...apiState,
    refetch: fetchAlerts,
  }
}

export function useBenchmarkReport() {
  const apiState = useApi<any>()
  
  const fetchReport = useCallback(() => {
    return apiState.execute(() => apiClient.getBenchmarkReport())
  }, [apiState.execute])

  useEffect(() => {
    fetchReport()
  }, [fetchReport])

  return {
    ...apiState,
    refetch: fetchReport,
  }
}