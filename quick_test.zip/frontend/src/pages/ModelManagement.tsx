import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Upload,
  Play,
  Pause,
  Edit,
  Trash2,
  Brain,
  RefreshCw
} from 'lucide-react'
import { useModels } from '@/hooks/useApi'

export function ModelManagement() {
  const [searchTerm, setSearchTerm] = useState('')
  const { data: models, loading, error, refetch } = useModels()
  
  // 转换API数据格式
  const modelList = models?.map(model => ({
    id: model.id,
    name: model.name,
    type: model.description || 'AI模型',
    status: model.status === 'ready' ? '运行中' : 
            model.status === 'training' ? '训练中' : 
            model.status === 'deployed' ? '运行中' : '已停止',
    accuracy: model.accuracy ? `${(model.accuracy * 100).toFixed(1)}%` : '--',
    size: '--', // 需要后端提供
    lastTrained: model.updated_at ? new Date(model.updated_at).toLocaleDateString() : '--',
    version: model.version || 'v1.0.0'
  })) || []

  const filteredModels = modelList.filter(model =>
    model.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    model.type.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case '运行中': return 'text-green-400'
      case '训练中': return 'text-yellow-400'
      case '已停止': return 'text-red-400'
      default: return 'text-gray-400'
    }
  }

  return (
    <div className="space-y-6">
      {/* 页面标题和操作 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold gradient-text mb-2">模型管理</h1>
          <p className="text-gray-300">管理和监控AI模型的训练、部署和版本控制</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="tech" className="flex items-center space-x-2">
            <Plus className="w-4 h-4" />
            <span>新建模型</span>
          </Button>
          <Button variant="outline" className="flex items-center space-x-2">
            <Upload className="w-4 h-4" />
            <span>导入模型</span>
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center space-x-2"
            onClick={refetch}
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>刷新</span>
          </Button>
        </div>
      </div>

      {/* 搜索和筛选 */}
      <Card className="glass-effect">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="搜索模型名称或类型..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="flex items-center space-x-2">
              <Filter className="w-4 h-4" />
              <span>筛选</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 模型列表 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredModels.map((model) => (
          <Card key={model.id} className="glass-effect hover:neon-glow transition-all duration-300">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-tech-primary to-tech-secondary rounded-lg flex items-center justify-center">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{model.name}</CardTitle>
                    <CardDescription>{model.type}</CardDescription>
                  </div>
                </div>
                <div className={`text-sm font-medium ${getStatusColor(model.status)}`}>
                  {model.status}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">准确率:</span>
                  <span className="ml-2 text-white">{model.accuracy}</span>
                </div>
                <div>
                  <span className="text-gray-400">模型大小:</span>
                  <span className="ml-2 text-white">{model.size}</span>
                </div>
                <div>
                  <span className="text-gray-400">最后训练:</span>
                  <span className="ml-2 text-white">{model.lastTrained}</span>
                </div>
                <div>
                  <span className="text-gray-400">版本:</span>
                  <span className="ml-2 text-white">{model.version}</span>
                </div>
              </div>
              
              <div className="flex justify-between pt-2 border-t border-tech-light">
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="flex items-center space-x-1">
                    <Play className="w-3 h-3" />
                    <span>启动</span>
                  </Button>
                  <Button size="sm" variant="outline" className="flex items-center space-x-1">
                    <Pause className="w-3 h-3" />
                    <span>暂停</span>
                  </Button>
                </div>
                <div className="flex space-x-2">
                  <Button size="sm" variant="ghost">
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 统计信息 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-effect">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-tech-primary">
                {loading ? '--' : modelList.length}
              </div>
              <div className="text-gray-400 mt-1">总模型数量</div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-effect">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">
                {loading ? '--' : modelList.filter(m => m.status === '运行中').length}
              </div>
              <div className="text-gray-400 mt-1">运行中模型</div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-effect">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400">
                {loading ? '--' : modelList.filter(m => m.status === '训练中').length}
              </div>
              <div className="text-gray-400 mt-1">训练中模型</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}