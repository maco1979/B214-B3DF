import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { 
  Cpu, 
  Play, 
  Pause, 
  RefreshCw,
  TrendingUp,
  Clock,
  Server,
  Activity
} from 'lucide-react'

export function InferenceService() {
  const [isRunning, setIsRunning] = useState(true)
  
  const services = [
    {
      id: 1,
      name: '图像分类服务',
      endpoint: '/api/v1/classify',
      status: '运行中',
      latency: '45ms',
      requests: '1.2K',
      successRate: '99.8%'
    },
    {
      id: 2,
      name: '目标检测服务',
      endpoint: '/api/v1/detect',
      status: '运行中',
      latency: '78ms',
      requests: '890',
      successRate: '98.5%'
    },
    {
      id: 3,
      name: '文本生成服务',
      endpoint: '/api/v1/generate',
      status: '维护中',
      latency: '120ms',
      requests: '560',
      successRate: '97.2%'
    }
  ]

  const performanceMetrics = [
    { label: '平均响应时间', value: '65ms', change: '-12%', trend: 'up' },
    { label: '错误率', value: '0.8%', change: '-0.3%', trend: 'down' },
    { label: '并发连接数', value: '256', change: '+15%', trend: 'up' },
    { label: 'CPU使用率', value: '42%', change: '+5%', trend: 'up' }
  ]

  return (
    <div className="space-y-6">
      {/* 页面标题和操作 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold gradient-text mb-2">推理服务</h1>
          <p className="text-gray-300">实时监控和管理AI模型的推理服务性能</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button 
            variant={isRunning ? "outline" : "tech"} 
            onClick={() => setIsRunning(!isRunning)}
            className="flex items-center space-x-2"
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isRunning ? '暂停服务' : '启动服务'}</span>
          </Button>
          <Button variant="outline" className="flex items-center space-x-2">
            <RefreshCw className="w-4 h-4" />
            <span>刷新状态</span>
          </Button>
        </div>
      </div>

      {/* 性能指标 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {performanceMetrics.map((metric, index) => (
          <Card key={index} className="glass-effect">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-white">{metric.value}</div>
                  <div className="text-sm text-gray-400 mt-1">{metric.label}</div>
                </div>
                <div className={`flex items-center space-x-1 ${
                  metric.trend === 'up' ? 'text-green-400' : 'text-red-400'
                }`}>
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-xs">{metric.change}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 服务列表 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {services.map((service) => (
          <Card key={service.id} className="glass-effect hover:neon-glow transition-all duration-300">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-tech-primary to-tech-secondary rounded-lg flex items-center justify-center">
                    <Cpu className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{service.name}</CardTitle>
                    <CardDescription className="text-xs">{service.endpoint}</CardDescription>
                  </div>
                </div>
                <div className={`text-sm font-medium ${
                  service.status === '运行中' ? 'text-green-400' : 
                  service.status === '维护中' ? 'text-yellow-400' : 'text-red-400'
                }`}>
                  {service.status}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400">延迟:</span>
                  <span className="text-white">{service.latency}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400">请求数:</span>
                  <span className="text-white">{service.requests}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400">成功率:</span>
                  <span className="text-white">{service.successRate}</span>
                </div>
              </div>
              
              <div className="flex justify-between pt-3 border-t border-tech-light">
                <Button size="sm" variant="outline" className="flex items-center space-x-1">
                  <Play className="w-3 h-3" />
                  <span>测试</span>
                </Button>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline">监控</Button>
                  <Button size="sm" variant="outline">日志</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 实时监控 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-effect">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Server className="w-5 h-5 text-tech-primary" />
              <span>节点状态</span>
            </CardTitle>
            <CardDescription>边缘计算节点运行状态</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">主节点</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-green-400">在线</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">边缘节点1</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-green-400">在线</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">边缘节点2</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
                <span className="text-yellow-400">延迟</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">边缘节点3</span>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-red-400">离线</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-effect">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-tech-primary" />
              <span>实时流量</span>
            </CardTitle>
            <CardDescription>当前推理请求统计</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-300">图像分类</span>
                <span className="text-white">45 请求/分钟</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">目标检测</span>
                <span className="text-white">32 请求/分钟</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">文本生成</span>
                <span className="text-white">18 请求/分钟</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">语音识别</span>
                <span className="text-white">12 请求/分钟</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}