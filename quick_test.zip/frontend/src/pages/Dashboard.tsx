import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  Brain, 
  Cpu, 
  Database, 
  TrendingUp, 
  Users, 
  Clock,
  Play,
  Pause,
  RefreshCw,
  AlertCircle,
  CheckCircle
} from 'lucide-react'
import { 
  useModels, 
  useSystemMetrics, 
  useBlockchainStatus,
  useEdgeDevices 
} from '@/hooks/useApi'

export function Dashboard() {
  const { data: models, loading: modelsLoading, error: modelsError } = useModels()
  const { data: metrics, loading: metricsLoading, error: metricsError } = useSystemMetrics()
  const { data: blockchainStatus, loading: blockchainLoading } = useBlockchainStatus()
  const { data: edgeDevices, loading: devicesLoading } = useEdgeDevices()

  const [lastUpdate, setLastUpdate] = useState(new Date())

  const stats = [
    { 
      label: '活跃模型', 
      value: models?.length || '12', 
      icon: Brain, 
      change: modelsLoading ? '加载中...' : '+2', 
      color: 'text-tech-primary' 
    },
    { 
      label: '推理请求', 
      value: metrics?.inference_requests || '1.2K', 
      icon: Cpu, 
      change: metricsLoading ? '加载中...' : '+15%', 
      color: 'text-green-400' 
    },
    { 
      label: '数据总量', 
      value: metrics?.data_size || '45.6GB', 
      icon: Database, 
      change: metricsLoading ? '加载中...' : '+3.2GB', 
      color: 'text-blue-400' 
    },
    { 
      label: '在线设备', 
      value: edgeDevices?.length || '156', 
      icon: Users, 
      change: devicesLoading ? '加载中...' : '+8', 
      color: 'text-purple-400' 
    },
  ]

  const systemStatus = [
    {
      name: 'AI服务',
      status: metrics?.ai_service_status === 'healthy' ? 'running' : 'error',
      message: metrics?.ai_service_status === 'healthy' ? '运行中' : '异常'
    },
    {
      name: '区块链节点',
      status: blockchainStatus?.status === 'healthy' ? 'running' : 'error',
      message: blockchainStatus?.status === 'healthy' ? '同步完成' : '同步中'
    },
    {
      name: '边缘计算',
      status: edgeDevices && edgeDevices.length > 0 ? 'running' : 'warning',
      message: edgeDevices && edgeDevices.length > 0 ? `${edgeDevices.length}台在线` : '无设备'
    },
    {
      name: '数据存储',
      status: metrics?.storage_status === 'healthy' ? 'running' : 'error',
      message: metrics?.storage_status === 'healthy' ? '正常' : '异常'
    }
  ]

  const recentActivities = [
    { time: '2分钟前', action: '模型训练完成', model: 'ResNet-50', status: 'success' },
    { time: '5分钟前', action: '推理服务部署', model: 'YOLOv8', status: 'success' },
    { time: '10分钟前', action: '区块链交易确认', model: '智能合约', status: 'pending' },
    { time: '15分钟前', action: '数据同步完成', model: 'MNIST数据集', status: 'success' },
  ]

  const refreshData = () => {
    setLastUpdate(new Date())
    // 这里可以添加手动刷新逻辑
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return <CheckCircle className="w-4 h-4 text-green-400" />
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-400" />
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-400" />
      default:
        return <AlertCircle className="w-4 h-4 text-gray-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
        return 'text-green-400'
      case 'warning':
        return 'text-yellow-400'
      case 'error':
        return 'text-red-400'
      default:
        return 'text-gray-400'
    }
  }

  return (
    <div className="space-y-6">
      {/* 欢迎区域 */}
      <div className="bg-gradient-to-r from-tech-primary/10 to-tech-secondary/10 rounded-lg p-6 border border-tech-primary/20">
        <h1 className="text-3xl font-bold gradient-text mb-2">欢迎使用AI平台</h1>
        <p className="text-gray-300">监控系统状态，管理AI模型，探索区块链集成功能</p>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card key={index} className="glass-effect hover:neon-glow transition-all duration-300">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">
                  {stat.label}
                </CardTitle>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <p className="text-xs text-green-400">{stat.change}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 系统状态 */}
        <Card className="glass-effect">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-tech-primary" />
                <span>系统状态</span>
              </div>
              <div className="text-xs text-gray-400">
                更新于: {lastUpdate.toLocaleTimeString()}
              </div>
            </CardTitle>
            <CardDescription>实时监控系统运行状态</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {systemStatus.map((service, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-gray-300">{service.name}</span>
                <div className="flex items-center space-x-2">
                  {getStatusIcon(service.status)}
                  <span className={getStatusColor(service.status)}>{service.message}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* 最近活动 */}
        <Card className="glass-effect">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-tech-primary" />
              <span>最近活动</span>
            </CardTitle>
            <CardDescription>系统最近的操作记录</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-tech-dark/50 rounded-lg">
                <div>
                  <div className="font-medium text-white">{activity.action}</div>
                  <div className="text-sm text-gray-400">{activity.model}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-300">{activity.time}</div>
                  <div className={`text-xs ${activity.status === 'success' ? 'text-green-400' : 'text-yellow-400'}`}>
                    {activity.status === 'success' ? '成功' : '进行中'}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* 快速操作 */}
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle>快速操作</CardTitle>
          <CardDescription>常用功能的快捷入口</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button variant="tech" className="flex items-center space-x-2">
              <Play className="w-4 h-4" />
              <span>启动训练</span>
            </Button>
            <Button variant="outline" className="flex items-center space-x-2">
              <Pause className="w-4 h-4" />
              <span>暂停服务</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center space-x-2"
              onClick={refreshData}
            >
              <RefreshCw className="w-4 h-4" />
              <span>刷新数据</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}