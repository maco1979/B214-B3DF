import { API_BASE_URL } from '@/config'

// API响应类型定义
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// 模型相关类型
export interface Model {
  id: string
  name: string
  version: string
  description: string
  status: 'training' | 'ready' | 'deployed' | 'error'
  accuracy?: number
  created_at: string
  updated_at: string
}

// 推理请求类型
export interface InferenceRequest {
  model_id: string
  input_data: any
  parameters?: {
    temperature?: number
    max_tokens?: number
    top_p?: number
  }
}

// 推理响应类型
export interface InferenceResponse {
  result: any
  inference_time: number
  model_version: string
}

// 训练任务类型
export interface TrainingTask {
  id: string
  model_name: string
  dataset: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  progress: number
  start_time: string
  end_time?: string
}

// 区块链状态类型
export interface BlockchainStatus {
  status: string
  initialized: boolean
  latest_block?: {
    block_number: number
    transaction_count: number
  }
  timestamp: string
}

// API客户端类
class ApiClient {
  private baseUrl: string

  constructor(baseUrl: string = API_BASE_URL) {
    this.baseUrl = baseUrl
  }

  private async request<T>(
    endpoint: string, 
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const url = `${this.baseUrl}${endpoint}`
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      return { success: true, data }
    } catch (error) {
      console.error(`API request failed for ${endpoint}:`, error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    }
  }

  // 模型管理API
  async getModels(): Promise<ApiResponse<Model[]>> {
    return this.request<Model[]>('/models')
  }

  async getModel(id: string): Promise<ApiResponse<Model>> {
    return this.request<Model>(`/models/${id}`)
  }

  async createModel(modelData: Partial<Model>): Promise<ApiResponse<Model>> {
    return this.request<Model>('/models', {
      method: 'POST',
      body: JSON.stringify(modelData),
    })
  }

  async updateModel(id: string, modelData: Partial<Model>): Promise<ApiResponse<Model>> {
    return this.request<Model>(`/models/${id}`, {
      method: 'PUT',
      body: JSON.stringify(modelData),
    })
  }

  async deleteModel(id: string): Promise<ApiResponse<void>> {
    return this.request<void>(`/models/${id}`, {
      method: 'DELETE',
    })
  }

  // 推理服务API
  async runInference(request: InferenceRequest): Promise<ApiResponse<InferenceResponse>> {
    return this.request<InferenceResponse>('/inference', {
      method: 'POST',
      body: JSON.stringify(request),
    })
  }

  async getInferenceHistory(): Promise<ApiResponse<any[]>> {
    return this.request<any[]>('/inference/history')
  }

  // 训练任务API
  async getTrainingTasks(): Promise<ApiResponse<TrainingTask[]>> {
    return this.request<TrainingTask[]>('/training/tasks')
  }

  async createTrainingTask(taskData: Partial<TrainingTask>): Promise<ApiResponse<TrainingTask>> {
    return this.request<TrainingTask>('/training/tasks', {
      method: 'POST',
      body: JSON.stringify(taskData),
    })
  }

  async getTrainingTask(id: string): Promise<ApiResponse<TrainingTask>> {
    return this.request<TrainingTask>(`/training/tasks/${id}`)
  }

  // 区块链API
  async getBlockchainStatus(): Promise<ApiResponse<BlockchainStatus>> {
    return this.request<BlockchainStatus>('/blockchain/status')
  }

  async verifyModelIntegrity(modelId: string, modelHash: string): Promise<ApiResponse<any>> {
    return this.request<any>(`/blockchain/models/${modelId}/verify?model_hash=${modelHash}`)
  }

  async getModelHistory(modelId: string): Promise<ApiResponse<any>> {
    return this.request<any>(`/blockchain/models/${modelId}/history`)
  }

  // 联邦学习API
  async getFederatedClients(): Promise<ApiResponse<any[]>> {
    return this.request<any[]>('/federated/clients')
  }

  async registerFederatedClient(clientInfo: any): Promise<ApiResponse<any>> {
    return this.request<any>('/federated/clients/register', {
      method: 'POST',
      body: JSON.stringify(clientInfo),
    })
  }

  async getFederatedRounds(): Promise<ApiResponse<any[]>> {
    return this.request<any[]>('/federated/rounds')
  }

  async startFederatedRound(config: any): Promise<ApiResponse<any>> {
    return this.request<any>('/federated/rounds/start', {
      method: 'POST',
      body: JSON.stringify(config),
    })
  }

  async aggregateFederatedRound(roundId: string): Promise<ApiResponse<any>> {
    return this.request<any>(`/federated/rounds/${roundId}/aggregate`, {
      method: 'POST',
    })
  }

  async getFederatedStatus(): Promise<ApiResponse<any>> {
    return this.request<any>('/federated/status')
  }

  async getFederatedPrivacyStatus(): Promise<ApiResponse<any>> {
    return this.request<any>('/federated/privacy/status')
  }

  async updateFederatedPrivacyConfig(config: any): Promise<ApiResponse<any>> {
    return this.request<any>('/federated/privacy/config', {
      method: 'POST',
      body: JSON.stringify(config),
    })
  }

  // 系统监控API
  async getSystemMetrics(): Promise<ApiResponse<any>> {
    return this.request<any>('/system/metrics')
  }

  async getHealthStatus(): Promise<ApiResponse<any>> {
    return this.request<any>('/system/health')
  }

  // 边缘计算API
  async getEdgeDevices(): Promise<ApiResponse<any[]>> {
    return this.request<any[]>('/edge/devices')
  }

  async syncEdgeDevice(deviceId: string): Promise<ApiResponse<any>> {
    return this.request<any>(`/edge/devices/${deviceId}/sync`, {
      method: 'POST',
    })
  }

  // 性能监控API
  async getPerformanceMetrics(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/summary')
  }

  async getPerformanceSummary(timeRange: string = "1h"): Promise<ApiResponse<any>> {
    return this.request<any>(`/performance/summary?time_range=${timeRange}`)
  }

  async getIntegrationPerformanceSummary(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/integration-summary')
  }

  async getOptimizationStatus(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/optimization/status')
  }

  async getOptimizationRecommendations(): Promise<ApiResponse<any[]>> {
    return this.request<any[]>('/performance/optimization/recommendations')
  }

  async applyOptimization(component: string, recommendationType: string): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/optimization/apply', {
      method: 'POST',
      body: JSON.stringify({ component, recommendation_type: recommendationType }),
    })
  }

  async getPerformanceAlerts(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/alerts')
  }

  async acknowledgeAlert(alertId: string): Promise<ApiResponse<any>> {
    return this.request<any>(`/performance/alerts/${alertId}/acknowledge`, {
      method: 'POST',
    })
  }

  async getBenchmarkReport(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/benchmark/report')
  }

  async runBenchmarkTest(testType: string, parameters: any): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/benchmark/run', {
      method: 'POST',
      body: JSON.stringify({ test_type: testType, parameters }),
    })
  }

  async enableAutoOptimization(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/auto-optimization/enable', {
      method: 'POST',
    })
  }

  async disableAutoOptimization(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/auto-optimization/disable', {
      method: 'POST',
    })
  }

  async runAutoOptimization(): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/auto-optimization/run', {
      method: 'POST',
    })
  }

  async getMetricDetails(metricType: string, timeRange: string = "1h"): Promise<ApiResponse<any>> {
    return this.request<any>(`/performance/metrics/${metricType}?time_range=${timeRange}`)
  }

  async recordPerformanceMetric(metricData: any): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/metrics', {
      method: 'POST',
      body: JSON.stringify(metricData),
    })
  }

  async recordIntegrationPerformance(performanceData: any): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/integration-metrics', {
      method: 'POST',
      body: JSON.stringify(performanceData),
    })
  }

  async recordMigrationLearningPerformance(performanceData: any): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/migration-learning-metrics', {
      method: 'POST',
      body: JSON.stringify(performanceData),
    })
  }

  async recordEdgeComputingPerformance(performanceData: any): Promise<ApiResponse<any>> {
    return this.request<any>('/performance/edge-computing-metrics', {
      method: 'POST',
      body: JSON.stringify(performanceData),
    })
  }
}

// 创建全局API客户端实例
export const apiClient = new ApiClient()

// 导出所有类型
export type {
  ApiResponse,
  Model,
  InferenceRequest,
  InferenceResponse,
  TrainingTask,
  BlockchainStatus,
}