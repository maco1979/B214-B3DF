import React from 'react'
import { Bell, Search, User, Settings as SettingsIcon } from 'lucide-react'
import { Button } from './ui/button'

export function Header() {
  return (
    <header className="flex items-center justify-between p-4 bg-tech-gray border-b border-tech-light">
      {/* 搜索框 */}
      <div className="flex-1 max-w-md">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="搜索模型、服务或数据..."
            className="w-full pl-10 pr-4 py-2 bg-tech-dark border border-tech-light rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-tech-primary transition-colors"
          />
        </div>
      </div>

      {/* 右侧功能区 */}
      <div className="flex items-center space-x-4">
        {/* 通知 */}
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
        </Button>

        {/* 设置 */}
        <Button variant="ghost" size="icon">
          <SettingsIcon className="w-5 h-5" />
        </Button>

        {/* 用户信息 */}
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-tech-primary to-tech-secondary rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="text-sm">
            <div className="font-medium text-white">AI管理员</div>
            <div className="text-gray-400">超级管理员</div>
          </div>
        </div>
      </div>
    </header>
  )
}