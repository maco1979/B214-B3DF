import React, { useState } from 'react'
import { NavLink } from 'react-router-dom'
import { 
  LayoutDashboard, 
  Brain, 
  Cpu, 
  Link2, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Sprout,
  BarChart3
} from 'lucide-react'

const menuItems = [
  { path: '/', icon: LayoutDashboard, label: '仪表盘' },
  { path: '/agriculture', icon: Sprout, label: '农业AI' },
  { path: '/models', icon: Brain, label: '模型管理' },
  { path: '/inference', icon: Cpu, label: '推理服务' },
  { path: '/blockchain', icon: Link2, label: '区块链' },
  { path: '/performance', icon: BarChart3, label: '性能监控' },
  { path: '/settings', icon: Settings, label: '系统设置' },
]

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false)

  return (
    <div className={`flex flex-col bg-tech-gray border-r border-tech-light transition-all duration-300 ${isCollapsed ? 'w-16' : 'w-64'}`}>
      {/* Logo区域 */}
      <div className="flex items-center justify-between p-4 border-b border-tech-light">
        {!isCollapsed && (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-tech-primary to-tech-secondary rounded-lg flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">AI平台</span>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1 rounded-md hover:bg-tech-light transition-colors"
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* 导航菜单 */}
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-tech-primary/20 text-tech-primary border-l-4 border-tech-primary'
                    : 'text-gray-300 hover:bg-tech-light hover:text-white'
                } ${isCollapsed ? 'justify-center' : ''}`
              }
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {!isCollapsed && <span className="font-medium">{item.label}</span>}
            </NavLink>
          )
        })}
      </nav>

      {/* 系统状态 */}
      {!isCollapsed && (
        <div className="p-4 border-t border-tech-light">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">系统状态</span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            </div>
            <div className="text-xs text-gray-500">
              AI模型: <span className="text-green-400">运行中</span>
            </div>
            <div className="text-xs text-gray-500">
              区块链: <span className="text-green-400">同步完成</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}