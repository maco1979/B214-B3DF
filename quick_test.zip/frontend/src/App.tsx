import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'

import { Dashboard } from './pages/Dashboard'
import AgriculturePage from './pages/Agriculture'
import { ModelManagement } from './pages/ModelManagement'
import { InferenceService } from './pages/InferenceService'
import { Blockchain } from './pages/Blockchain'
import { PerformanceMonitoring } from './pages/PerformanceMonitoring'
import { Settings } from './pages/Settings'

import { Layout } from './components/Layout'
import { AuthProvider } from './hooks/useAuth'

import './index.css'

function App() {
  return (
    <AuthProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/agriculture" element={<AgriculturePage />} />
            <Route path="/models" element={<ModelManagement />} />
            <Route path="/inference" element={<InferenceService />} />
            <Route path="/blockchain" element={<Blockchain />} />
            <Route path="/performance" element={<PerformanceMonitoring />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </Layout>
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#1A1A1A',
              color: '#FFFFFF',
              border: '1px solid #2D2D2D',
            },
          }}
        />
      </Router>
    </AuthProvider>
  )
}

export default App