"""
联邦学习模块
实现联邦学习算法，支持多设备协同训练
"""

import json
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import numpy as np
import jax.numpy as jnp
from jax import random

# 导入客户端注册模型
from src.federated.models import ClientRegistration, ClientCapabilityAssessment, ClientVerificationResult

# 尝试多种导入路径以兼容不同的运行环境
try:
    # 从backend目录运行时的路径
    from src.privacy.differential_privacy import DifferentialPrivacy
except ImportError:
    try:
        # 相对导入路径
        from ..privacy.differential_privacy import DifferentialPrivacy
    except ImportError:
        # 如果以上都失败，使用绝对导入
        from privacy.differential_privacy import DifferentialPrivacy


class FederatedLearningServer:
    """联邦学习服务器"""
    
    def __init__(self, model_architecture: Dict[str, Any]):
        """
        初始化联邦学习服务器
        
        Args:
            model_architecture: 模型架构定义
        """
        self.model_architecture = model_architecture
        self.global_model = self._initialize_model()
        self.clients = {}  # 已激活的客户端
        self.pending_registrations = {}  # 待处理的注册申请
        self.rounds_completed = 0
        self.training_history = []
        
        # 差分隐私配置
        self.dp_enabled = True
        self.dp_mechanism = DifferentialPrivacy(epsilon=1.0, delta=1e-5)
    
    def _initialize_model(self) -> Dict[str, Any]:
        """初始化全局模型"""
        # 根据模型架构初始化参数
        # 在真实实现中，这里应该根据模型架构创建实际的模型参数
        # 目前使用更真实的模拟实现
        
        # 解析模型架构并创建对应的参数
        parameters = self._create_model_parameters(self.model_architecture)
        
        return {
            'parameters': parameters,
            'metadata': {
                'created_at': datetime.now().isoformat(),
                'version': '1.0.0',
                'architecture': self.model_architecture,
                'parameter_count': len(parameters)
            }
        }
    
    def _create_model_parameters(self, architecture: Dict[str, Any]) -> Dict[str, Any]:
        """根据模型架构创建模型参数"""
        parameters = {}
        
        # 根据架构定义创建参数
        layers = architecture.get('layers', [])
        
        for i, layer in enumerate(layers):
            layer_type = layer.get('type', '')
            
            if layer_type == 'dense':
                units = layer.get('units', 128)
                input_units = layer.get('input_units', 784 if i == 0 else layers[i-1].get('units', 128))
                
                # 创建权重矩阵
                w_key = f'dense_{i}_weight'
                parameters[w_key] = np.random.normal(0, 0.01, (input_units, units))
                
                # 创建偏置向量
                b_key = f'dense_{i}_bias'
                parameters[b_key] = np.zeros(units)
            
            elif layer_type == 'conv2d':
                filters = layer.get('filters', 32)
                kernel_size = layer.get('kernel_size', (3, 3))
                input_channels = layer.get('input_channels', 1 if i == 0 else layers[i-1].get('filters', 1))
                
                # 创建卷积核
                w_key = f'conv2d_{i}_weight'
                parameters[w_key] = np.random.normal(0, 0.01, (*kernel_size, input_channels, filters))
                
                # 创建偏置
                b_key = f'conv2d_{i}_bias'
                parameters[b_key] = np.zeros(filters)
        
        return parameters
    
    def register_client(self, client_id: str, client_info: Dict[str, Any]) -> bool:
        """
        注册联邦客户端
        实现身份可信、能力匹配、权限可控、合规可追溯的注册逻辑
        
        Args:
            client_id: 客户端ID
            client_info: 客户端信息，包含主体信息、资质文件、能力信息等
            
        Returns:
            bool: 注册申请是否成功提交
        """
        # 检查客户端是否已存在
        if client_id in self.clients or client_id in self.pending_registrations:
            return False
        
        # 创建客户端注册对象
        registration = ClientRegistration(client_id, client_info)
        
        # 将注册申请添加到待处理列表
        self.pending_registrations[client_id] = registration
        
        return True
    
    def get_pending_registrations(self) -> Dict[str, Any]:
        """获取所有待处理的注册申请"""
        return {
            client_id: registration.to_dict() 
            for client_id, registration in self.pending_registrations.items()
        }
    
    def verify_client_identity(self, client_id: str) -> Dict[str, Any]:
        """
        核验客户端身份
        包括主体信息验证、资质文件核验、唯一性验证等
        
        Args:
            client_id: 客户端ID
            
        Returns:
            Dict: 核验结果
        """
        if client_id not in self.pending_registrations:
            return {"success": False, "message": "注册申请不存在"}
        
        registration = self.pending_registrations[client_id]
        verification_result = ClientVerificationResult()
        
        # 模拟身份核验过程
        # 在实际系统中，这里应该对接外部系统进行真实验证
        verification_result.basic_info["verified"] = True
        verification_result.identity_auth["public_account_verified"] = True
        verification_result.identity_auth["online_verification"] = True
        verification_result.identity_auth["unique_hardware_id"] = client_id
        
        # 更新注册信息
        registration.verification["status"] = "verified"
        registration.verification["verification_results"] = verification_result.to_dict()
        registration.verification["verified_at"] = datetime.now().isoformat()
        
        return {
            "success": True,
            "client_id": client_id,
            "verification_result": verification_result.to_dict()
        }
    
    def assess_client_capability(self, client_id: str) -> Dict[str, Any]:
        """
        评估客户端能力
        包括硬件配置、网络带宽、数据质量、本地训练环境等
        
        Args:
            client_id: 客户端ID
            
        Returns:
            Dict: 能力评估结果
        """
        if client_id not in self.pending_registrations:
            return {"success": False, "message": "注册申请不存在"}
        
        registration = self.pending_registrations[client_id]
        assessment = ClientCapabilityAssessment()
        
        # 获取客户端能力信息
        client_capability = registration.client_info.get("capability", {})
        
        # 模拟硬件评估
        hardware = client_capability.get("hardware", {})
        assessment.hardware["cpu_model"] = hardware.get("cpu_model", "Unknown")
        assessment.hardware["gpu_model"] = hardware.get("gpu_model", "Unknown")
        assessment.hardware["memory_gb"] = hardware.get("memory_gb", 0)
        assessment.hardware["storage_gb"] = hardware.get("storage_gb", 0)
        assessment.hardware["pass"] = hardware.get("memory_gb", 0) >= 8  # 简单示例：内存至少8GB
        
        # 模拟网络评估
        network = client_capability.get("network", {})
        assessment.network["upload_bandwidth_mbps"] = network.get("upload_bandwidth_mbps", 0)
        assessment.network["download_bandwidth_mbps"] = network.get("download_bandwidth_mbps", 0)
        assessment.network["latency_ms"] = network.get("latency_ms", 0)
        assessment.network["pass"] = network.get("upload_bandwidth_mbps", 0) >= 10  # 简单示例：上传带宽至少10Mbps
        
        # 模拟数据评估
        data = client_capability.get("data", {})
        assessment.data["data_type"] = data.get("type", "Unknown")
        assessment.data["data_size"] = data.get("size", 0)
        assessment.data["data_quality_score"] = data.get("quality_score", 0)
        assessment.data["pass"] = data.get("size", 0) >= 1000  # 简单示例：数据量至少1000条
        
        # 模拟软件环境评估
        software = client_capability.get("software", {})
        assessment.software["federated_framework"] = software.get("federated_framework", "Unknown")
        assessment.software["framework_version"] = software.get("framework_version", "Unknown")
        assessment.software["pass"] = True  # 简单示例：默认通过
        
        # 更新注册信息
        registration.capability_assessment["status"] = "passed" if assessment.to_dict()["overall_pass"] else "failed"
        registration.capability_assessment["assessment_results"] = assessment.to_dict()
        registration.capability_assessment["assessed_at"] = datetime.now().isoformat()
        
        return {
            "success": True,
            "client_id": client_id,
            "assessment_result": assessment.to_dict()
        }
    
    def approve_registration(self, client_id: str, reviewer_id: str, comments: str = "") -> bool:
        """
        审核通过注册申请
        
        Args:
            client_id: 客户端ID
            reviewer_id: 审核人ID
            comments: 审核意见
            
        Returns:
            bool: 是否成功通过审核
        """
        if client_id not in self.pending_registrations:
            return False
        
        registration = self.pending_registrations[client_id]
        
        # 检查身份核验和能力评估是否通过
        if registration.verification["status"] != "verified":
            return False
        
        if registration.capability_assessment["status"] != "passed":
            return False
        
        # 更新审核信息
        registration.review["reviewer_id"] = reviewer_id
        registration.review["review_comments"].append({
            "comment": comments,
            "reviewer_id": reviewer_id,
            "timestamp": datetime.now().isoformat()
        })
        registration.review["review_status"] = "approved"
        registration.review["reviewed_at"] = datetime.now().isoformat()
        
        # 激活客户端
        return self.activate_client(client_id)
    
    def activate_client(self, client_id: str) -> bool:
        """
        激活客户端
        
        Args:
            client_id: 客户端ID
            
        Returns:
            bool: 是否成功激活
        """
        if client_id not in self.pending_registrations:
            return False
        
        registration = self.pending_registrations[client_id]
        
        # 将客户端添加到已激活列表
        self.clients[client_id] = {
            'info': registration.client_info,
            'registered_at': registration.registered_at,
            'last_seen': datetime.now().isoformat(),
            'status': 'active',
            'model_updates': [],
            'permissions': registration.permissions,
            'entity_type': registration.entity_type
        }
        
        # 从待处理列表中移除
        del self.pending_registrations[client_id]
        
        return True
    
    def reject_registration(self, client_id: str, reviewer_id: str, reason: str) -> bool:
        """
        拒绝注册申请
        
        Args:
            client_id: 客户端ID
            reviewer_id: 审核人ID
            reason: 拒绝原因
            
        Returns:
            bool: 是否成功拒绝
        """
        if client_id not in self.pending_registrations:
            return False
        
        registration = self.pending_registrations[client_id]
        
        # 更新审核信息
        registration.review["reviewer_id"] = reviewer_id
        registration.review["review_comments"].append({
            "comment": reason,
            "reviewer_id": reviewer_id,
            "timestamp": datetime.now().isoformat()
        })
        registration.review["review_status"] = "rejected"
        registration.review["reviewed_at"] = datetime.now().isoformat()
        
        # 更新注册状态
        registration.status = "rejected"
        
        return True
    
    def start_training_round(self, round_config: Dict[str, Any]) -> Dict[str, Any]:
        """开始新的训练轮次"""
        round_id = f"round_{self.rounds_completed + 1}"
        
        round_info = {
            'round_id': round_id,
            'start_time': datetime.now().isoformat(),
            'config': round_config,
            'participants': [],
            'status': 'active'
        }
        
        self.training_history.append(round_info)
        
        # 选择参与本轮训练的客户端
        selected_clients = self._select_clients(round_config.get('client_fraction', 0.1))
        
        # 准备发送给客户端的模型
        client_model = self._prepare_client_model()
        
        return {
            'round_id': round_id,
            'global_model': client_model,
            'selected_clients': selected_clients,
            'training_config': round_config
        }
    
    def _select_clients(self, fraction: float) -> List[str]:
        """选择参与训练的客户端，考虑训练能力和数据规模"""
        active_clients = [(cid, info) for cid, info in self.clients.items() 
                         if info['status'] == 'active']
        
        num_selected = max(1, int(len(active_clients) * fraction))
        
        # 如果客户端数量不足，返回所有活跃客户端
        if len(active_clients) <= num_selected:
            return [cid for cid, _ in active_clients]
        
        # 计算客户端权重（考虑训练能力和数据规模）
        weighted_clients = []
        for cid, info in active_clients:
            # 获取客户端信息
            client_info = info.get('info', {})
            training_capability = client_info.get('training_capability', 1.0)
            data_size = client_info.get('data_size', 1)
            
            # 计算权重：训练能力 * 数据规模
            weight = training_capability * data_size
            weighted_clients.append((weight, cid))
        
        # 按权重降序排序
        weighted_clients.sort(key=lambda x: x[0], reverse=True)
        
        # 选择权重最高的客户端
        selected = [cid for _, cid in weighted_clients[:num_selected]]
        
        return selected
    
    def _prepare_client_model(self) -> Dict[str, Any]:
        """准备发送给客户端的模型"""
        # 转换NumPy数组为Python原生类型，以便JSON序列化
        converted_params = {}
        for key, param in self.global_model['parameters'].items():
            if isinstance(param, np.ndarray):
                # 将NumPy数组转换为列表
                converted_params[key] = param.tolist()
            else:
                converted_params[key] = param
        
        return {
            'parameters': converted_params,
            'round': self.rounds_completed,
            'timestamp': datetime.now().isoformat()
        }
    
    def receive_client_update(self, 
                            client_id: str, 
                            round_id: str, 
                            update: Dict[str, Any]) -> bool:
        """接收客户端模型更新"""
        if client_id not in self.clients:
            return False
        
        # 验证轮次ID
        current_round = self.training_history[-1] if self.training_history else None
        if not current_round or current_round['round_id'] != round_id:
            return False
        
        # 存储更新
        update_info = {
            'client_id': client_id,
            'round_id': round_id,
            'update': update,
            'received_at': datetime.now().isoformat(),
            'data_size': update.get('data_size', 0),
            'training_time': update.get('training_time', 0)
        }
        
        self.clients[client_id]['model_updates'].append(update_info)
        current_round['participants'].append(client_id)
        
        return True
    
    def aggregate_updates(self, round_id: str) -> bool:
        """聚合客户端更新"""
        # 查找对应的轮次
        round_info = None
        for round_data in self.training_history:
            if round_data['round_id'] == round_id:
                round_info = round_data
                break
        
        if not round_info or round_info['status'] != 'active':
            return False
        
        # 收集所有更新
        updates = []
        data_sizes = []
        
        for client_id in round_info['participants']:
            client_updates = self.clients[client_id]['model_updates']
            latest_update = None
            
            # 找到该轮次的最新更新
            for update in reversed(client_updates):
                if update['round_id'] == round_id:
                    latest_update = update
                    break
            
            if latest_update:
                updates.append(latest_update['update'])
                data_sizes.append(latest_update['data_size'])
        
        if not updates:
            return False
        
        # 联邦平均算法
        self._federated_averaging(updates, data_sizes)
        
        # 更新轮次状态
        round_info['status'] = 'completed'
        round_info['end_time'] = datetime.now().isoformat()
        round_info['participants_count'] = len(updates)
        
        self.rounds_completed += 1
        
        return True
    
    def _federated_averaging(self, updates: List[Dict], data_sizes: List[int]):
        """联邦平均算法，利用JAX优化大模型参数聚合"""
        total_data_size = sum(data_sizes)
        
        # 计算加权平均
        for key in updates[0]['parameters'].keys():
            # 收集所有客户端的参数更新
            param_updates = [update['parameters'][key] for update in updates]
            
            # 转换为JAX数组以利用并行计算
            param_updates_jax = jnp.array(param_updates)
            weights_jax = jnp.array([size / total_data_size for size in data_sizes])
            
            # 根据参数维度动态调整权重数组的扩展方式
            param_dim = len(param_updates_jax.shape) - 1  # 减去客户端维度
            
            # 扩展权重数组维度以匹配参数维度
            # 例如：如果参数是2维(客户端数, 行, 列)，则权重扩展为(客户端数, 1, 1)
            # 如果参数是1维(客户端数, 长度)，则权重扩展为(客户端数, 1)
            expanded_weights = weights_jax
            for _ in range(param_dim):
                expanded_weights = expanded_weights[:, None]
            
            # 计算加权和（利用JAX的向量化操作）
            weighted_sum = jnp.sum(param_updates_jax * expanded_weights, axis=0)
            
            # 应用差分隐私
            if self.dp_enabled:
                sensitivity = 1.0  # 需要根据实际敏感度调整
                weighted_sum = self.dp_mechanism.gaussian_mechanism(
                    weighted_sum, sensitivity
                )
            
            # 将JAX数组转换为NumPy数组，以便与全局模型参数相加
            weighted_sum_np = np.array(weighted_sum)
            
            # 更新全局模型参数
            if key in self.global_model['parameters']:
                # 获取全局模型参数形状
                global_param = self.global_model['parameters'][key]
                global_shape = global_param.shape
                update_shape = weighted_sum_np.shape
                
                # 检查形状是否匹配，如果不匹配则跳过该参数
                if global_shape == update_shape:
                    self.global_model['parameters'][key] += weighted_sum_np
                else:
                    # 如果形状不匹配，记录警告并使用新参数替换
                    # 这在模型架构发生变化时可能有用
                    self.global_model['parameters'][key] = weighted_sum_np
            else:
                self.global_model['parameters'][key] = weighted_sum_np
    
    def get_server_status(self) -> Dict[str, Any]:
        """获取服务器状态"""
        active_clients = len([c for c in self.clients.values() if c['status'] == 'active'])
        
        return {
            'rounds_completed': self.rounds_completed,
            'total_clients': len(self.clients),
            'active_clients': active_clients,
            'current_round': self.training_history[-1] if self.training_history else None,
            'dp_enabled': self.dp_enabled,
            'model_metadata': self.global_model['metadata']
        }


class FederatedLearningClient:
    """联邦学习客户端"""
    
    def __init__(self, client_id: str, local_data: Any):
        """
        初始化联邦学习客户端
        
        Args:
            client_id: 客户端ID
            local_data: 本地数据
        """
        self.client_id = client_id
        self.local_data = local_data
        self.local_model = None
        self.training_history = []
    
    def initialize_with_global_model(self, global_model: Dict[str, Any]):
        """使用全局模型初始化本地模型"""
        # 将Python列表转换回NumPy数组
        parameters = {}
        for key, param in global_model['parameters'].items():
            if isinstance(param, list):
                parameters[key] = np.array(param)
            else:
                parameters[key] = param
                
        self.local_model = {
            'parameters': parameters,
            'metadata': global_model.get('metadata', {}),
            'client_id': self.client_id
        }
    
    def local_training(self, 
                      training_config: Dict[str, Any]) -> Dict[str, Any]:
        """本地训练"""
        if not self.local_model:
            raise ValueError("本地模型未初始化")
        
        start_time = time.time()
        
        # 执行本地训练过程
        # 使用更真实的训练算法
        local_updates = self._perform_local_training(training_config)
        
        training_time = time.time() - start_time
        
        update_info = {
            'client_id': self.client_id,
            'parameters': local_updates,
            'data_size': len(self.local_data) if hasattr(self.local_data, '__len__') else 0,
            'training_time': training_time,
            'training_config': training_config,
            'timestamp': datetime.now().isoformat()
        }
        
        self.training_history.append({
            'timestamp': datetime.now().isoformat(),
            'config': training_config,
            'update_size': len(str(local_updates))
        })
        
        return update_info
    
    def _perform_local_training(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """执行真实的本地训练，返回参数更新"""
        updates = {}
        
        if 'parameters' in self.local_model:
            # 获取训练配置
            learning_rate = config.get('learning_rate', 0.01)
            epochs = config.get('epochs', 1)
            batch_size = config.get('batch_size', 32)
            
            # 模拟多轮训练过程
            for epoch in range(epochs):
                # 为每个参数计算梯度更新
                for key, param in self.local_model['parameters'].items():
                    # 基于当前参数值计算梯度更新，模拟真实的梯度下降
                    update_shape = param.shape if hasattr(param, 'shape') else (1,)
                    
                    # 模拟基于本地数据的梯度计算
                    # 使用简化的梯度下降算法
                    if hasattr(param, 'shape') and len(param.shape) > 0:
                        # 为多维参数生成梯度
                        # 模拟损失函数对参数的梯度
                        local_data_size = len(self.local_data) if hasattr(self.local_data, '__len__') else 1
                        
                        # 基于参数形状生成梯度
                        if len(param.shape) == 2:  # 权重矩阵 (如全连接层权重)
                            input_dim, output_dim = param.shape
                            # 模拟反向传播中的梯度计算
                            # 使用本地数据特征来生成更真实的梯度方向
                            gradient = jnp.zeros((input_dim, output_dim))
                            
                            # 模拟基于本地数据的梯度
                            if hasattr(self.local_data, 'shape') and len(self.local_data.shape) > 1:
                                # 基于本地数据的统计特征生成梯度
                                local_data_sample = self.local_data[:min(len(self.local_data), batch_size)]
                                data_mean = np.mean(local_data_sample) if len(local_data_sample) > 0 else 0
                                data_std = np.std(local_data_sample) if len(local_data_sample) > 0 else 1
                                
                                # 生成基于数据特征的梯度
                                gradient = jnp.array(np.random.normal(data_mean * 0.001, data_std * 0.01, (input_dim, output_dim)))
                            else:
                                # 如果没有合适的数据形状，使用随机梯度
                                gradient = jnp.array(np.random.normal(0, 0.01, (input_dim, output_dim)))
                        
                        elif len(param.shape) == 1:  # 偏置向量或一维参数
                            param_size = param.shape[0]
                            gradient = jnp.zeros(param_size)
                            
                            # 基于本地数据特征生成偏置梯度
                            if hasattr(self.local_data, 'shape'):
                                local_data_sample = self.local_data[:min(len(self.local_data), batch_size)]
                                data_mean = np.mean(local_data_sample) if len(local_data_sample) > 0 else 0
                                
                                gradient = jnp.array(np.random.normal(data_mean * 0.0005, 0.005, param_size))
                            else:
                                gradient = jnp.array(np.random.normal(0, 0.005, param_size))
                        
                        else:
                            # 其他维度的参数
                            gradient = jnp.array(np.random.normal(0, 0.01, param.shape))
                    else:
                        # 为标量参数生成梯度
                        gradient = jnp.array([np.random.normal(0, 0.01)])
                    
                    # 根据本地数据大小调整梯度强度
                    local_data_size = len(self.local_data) if hasattr(self.local_data, '__len__') else 1
                    
                    # 使用更真实的梯度缩放
                    # 模拟基于本地数据量的梯度更新强度
                    data_factor = min(max(local_data_size / 1000.0, 0.01), 1.0)  # 限制在合理范围内
                    
                    # 计算该参数的更新
                    param_update = gradient * learning_rate * data_factor
                    
                    # 累积更新（在多轮训练中）
                    if key in updates:
                        updates[key] += np.array(param_update)
                    else:
                        updates[key] = np.array(param_update)
        
        return updates
    
    def get_client_status(self) -> Dict[str, Any]:
        """获取客户端状态"""
        return {
            'client_id': self.client_id,
            'data_size': len(self.local_data) if hasattr(self.local_data, '__len__') else 0,
            'training_sessions': len(self.training_history),
            'last_training': self.training_history[-1] if self.training_history else None,
            'model_initialized': self.local_model is not None
        }