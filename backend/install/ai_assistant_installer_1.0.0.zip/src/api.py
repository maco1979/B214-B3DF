"""
AI平台主API应用
集成所有服务模块，提供统一的API接口
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

# 导入核心服务
from src.core.services import model_manager, inference_engine

# 导入API路由
from src.api.routes import models, ai_control, blockchain, model_manager as model_manager_router, auth, plugins

# 导入插件管理器
from src.core.plugins.plugin_manager import plugin_manager

def create_app() -> FastAPI:
    """创建FastAPI应用"""
    app = FastAPI(
        title="AI平台API",
        description="AI决策和模型管理平台",
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc"
    )
    
    # 添加CORS中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # 注册API路由
    app.include_router(models.router, prefix="/api")
    app.include_router(ai_control.router, prefix="/api")
    app.include_router(blockchain.router, prefix="/api")
    app.include_router(model_manager_router.router, prefix="/api")
    app.include_router(auth.router, prefix="/api")
    app.include_router(plugins.router, prefix="/api")
    
    # 添加健康检查端点
    @app.get("/health")
    async def health_check():
        return {
            "status": "healthy", 
            "version": "1.0.0",
            "services": {
                "model_manager": "active",
                "inference_engine": "active",
                "plugin_manager": "active"
            }
        }
    
    @app.get("/")
    async def root():
        return {
            "message": "AI平台API服务运行中",
            "version": "1.0.0",
            "docs": "/docs",
            "plugins": "/api/plugins"
        }
    
    # 应用启动事件
    @app.on_event("startup")
    async def startup_event():
        """应用启动时初始化服务"""
        print("正在初始化模型管理器...")
        init_result = await model_manager.initialize()
        if init_result["success"]:
            print("✅ 模型管理器初始化成功")
        else:
            print(f"❌ 模型管理器初始化失败: {init_result['error']}")
        
        # 初始化插件管理器
        print("正在初始化插件管理器...")
        plugin_manager.set_app(app)
        
        # 添加插件目录
        plugin_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "plugins")
        if not os.path.exists(plugin_dir):
            os.makedirs(plugin_dir)
        plugin_manager.add_plugin_path(plugin_dir)
        
        # 发现并加载插件
        print("正在发现并加载插件...")
        discovered_plugins = await plugin_manager.discover_plugins()
        print(f"发现 {len(discovered_plugins)} 个插件")
        
        # 加载插件
        for plugin_info in discovered_plugins:
            result = await plugin_manager.load_plugin(plugin_info)
            if result:
                print(f"✅ 插件 {plugin_info.name} 加载成功")
            else:
                print(f"❌ 插件 {plugin_info.name} 加载失败")
        
        # 激活插件
        for plugin_info in plugin_manager.list_plugins():
            result = await plugin_manager.activate_plugin(plugin_info.name)
            if result:
                print(f"✅ 插件 {plugin_info.name} 激活成功")
            else:
                print(f"❌ 插件 {plugin_info.name} 激活失败")
        
        print("AI平台API启动完成")
    
    # 应用关闭事件
    @app.on_event("shutdown")
    async def shutdown_event():
        """应用关闭时清理资源"""
        print("正在关闭模型管理器...")
        await model_manager.close()
        
        # 关闭插件管理器
        print("正在关闭插件管理器...")
        await plugin_manager.unload_all_plugins()
        
        print("AI平台API已关闭")
    
    return app