"""AI助手路由
提供AI助手相关的API接口，包括语音交互、本地控制、互联网服务、智能体编排、设备控制等功能
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from src.core.services.local_controller import LocalController
from src.core.services.ai_model_service import AIModelService, aimodel_service, IntentType
from src.core.services.learning_service import learning_service
# 导入新实现的服务
from src.core.services.internet_service import internet_service
from src.core.services.agent_orchestrator import agent_orchestrator
from src.core.services.device_controller import device_controller
from src.core.services.user_habit_service import user_habit_service
from src.core.services.deployment_service import deployment_service
import time
import logging

# 配置日志
logger = logging.getLogger(__name__)

# 初始化本地控制器
local_controller = LocalController()

# 创建路由
ai_assistant_router = APIRouter(
    prefix="/ai-assistant",
    tags=["ai-assistant"],
    responses={404: {"description": "Not found"}},
)

# 数据模型
class UserRequest(BaseModel):
    """用户请求模型"""
    input_text: str
    input_type: str = "text"  # text 或 voice
    voice_data: str = None  # 语音数据（如果是语音输入）
    context_id: str = None  # 对话上下文ID

class LocalControlRequest(BaseModel):
    """本地控制请求模型"""
    command_type: str  # open_file, take_photo, run_cmd, list_files, get_system_info
    params: dict = None

# 核心API接口
@ai_assistant_router.post("/get-response")
async def get_response(request: UserRequest):
    """核心接口：接收用户输入，返回AI响应+执行本地任务
    
    Args:
        request: 用户请求数据
        
    Returns:
        AI响应和执行结果
    """
    user_input = request.input_text
    start_time = time.time()
    
    # 1. 使用AI模型服务识别意图
    intent = aimodel_service.recognize_intent(user_input)
    entities = aimodel_service.extract_entities(user_input, intent)
    
    # 2. 根据意图执行相应的操作
    response_data = None
    if intent == IntentType.OPEN_FILE:
        # 打开文件
        file_path = entities.get("file_path", "")
        if not file_path:
            response_data = {"response": "请提供要打开的文件路径", "type": "ai_response"}
        else:
            result = local_controller.open_file(file_path)
            response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.TAKE_PHOTO:
        # 拍照
        result = local_controller.take_photo()
        response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.RUN_COMMAND:
        # 执行命令
        command = entities.get("command", "")
        if not command:
            response_data = {"response": "请提供要执行的命令", "type": "ai_response"}
        else:
            result = local_controller.run_system_cmd(command)
            response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.LIST_FILES:
        # 列出文件
        directory = entities.get("directory", ".")
        result = local_controller.list_files(directory)
        response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.GET_SYSTEM_INFO:
        # 获取系统信息
        result = local_controller.get_system_info()
        response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.NAVIGATE:
        # 导航
        target = entities.get("target", "")
        response = aimodel_service.generate_response(user_input)
        response_data = {"response": response, "type": "navigation", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.OPEN_URL:
        # 打开URL
        url = entities.get("url", "")
        if not url:
            response_data = {"response": "请提供要打开的URL", "type": "ai_response"}
        else:
            result = local_controller.open_url(url)
            response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.SCREENSHOT:
        # 截图
        save_path = entities.get("save_path", "screenshot.jpg")
        result = local_controller.screenshot(save_path)
        response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.CREATE_FILE:
        # 创建文件
        file_path = entities.get("file_path", "")
        if not file_path:
            response_data = {"response": "请提供要创建的文件路径", "type": "ai_response"}
        else:
            content = entities.get("content", "")
            result = local_controller.create_file(file_path, content)
            response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.COPY_FILE:
        # 复制文件
        source = entities.get("source", "")
        destination = entities.get("destination", "")
        if not source or not destination:
            response_data = {"response": "请提供源文件路径和目标文件路径", "type": "ai_response"}
        else:
            result = local_controller.copy_file(source, destination)
            response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.DELETE_FILE:
        # 删除文件
        file_path = entities.get("file_path", "")
        if not file_path:
            response_data = {"response": "请提供要删除的文件路径", "type": "ai_response"}
        else:
            result = local_controller.delete_file(file_path)
            response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.START_APPLICATION:
        # 启动应用程序
        app_name = entities.get("app_name", "")
        if not app_name:
            response_data = {"response": "请提供要启动的应用程序名称", "type": "ai_response"}
        else:
            result = local_controller.start_application(app_name)
            response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.GET_PROCESS_LIST:
        # 获取进程列表
        result = local_controller.get_process_list()
        response_data = {"response": result, "type": "local_control", "intent": intent.value, "entities": entities}
    
    # 新增意图处理
    elif intent == IntentType.SEARCH_INTERNET:
        # 搜索互联网
        result = internet_service.search_internet(user_input)
        response_data = {"response": result, "type": "internet_service", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.RETRIEVE_DATA:
        # 检索数据
        result = internet_service.retrieve_data(user_input)
        response_data = {"response": result, "type": "internet_service", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.CALL_API:
        # 调用API
        result = internet_service.call_api(user_input)
        response_data = {"response": result, "type": "internet_service", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.DOWNLOAD_FILE:
        # 下载文件
        result = internet_service.download_file(user_input)
        response_data = {"response": result, "type": "internet_service", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.ORCHESTRATE_AGENT:
        # 编排智能体
        result = agent_orchestrator.orchestrate_task(user_input)
        response_data = {"response": result, "type": "agent_orchestration", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.MANAGE_AGENT:
        # 管理智能体
        result = agent_orchestrator.get_available_agents()
        response_data = {"response": result, "type": "agent_orchestration", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.CONTROL_DEVICE:
        # 控制设备
        result = device_controller.send_command(user_input)
        response_data = {"response": result, "type": "device_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.DISCOVER_DEVICE:
        # 发现设备
        result = device_controller.discover_devices()
        response_data = {"response": result, "type": "device_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.MONITOR_DEVICE:
        # 监控设备
        result = device_controller.health_check()
        response_data = {"response": result, "type": "device_control", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.ANALYZE_HABITS:
        # 分析习惯
        result = user_habit_service.analyze_user_habits("default_user")
        response_data = {"response": result, "type": "user_habit", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.PREDICT_BEHAVIOR:
        # 预测行为
        result = user_habit_service.predict_user_behavior("default_user", {})
        response_data = {"response": result, "type": "user_habit", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.GET_RECOMMENDATIONS:
        # 获取推荐
        result = user_habit_service.get_habit_recommendations("default_user")
        response_data = {"response": result, "type": "user_habit", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.CHECK_UPDATE:
        # 检查更新
        result = deployment_service.check_for_updates()
        response_data = {"response": result, "type": "deployment", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.UPDATE_APPLICATION:
        # 更新应用
        result = deployment_service.update_application()
        response_data = {"response": result, "type": "deployment", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.GENERATE_INSTALL_PACKAGE:
        # 生成安装包
        result = deployment_service.generate_installation_package()
        response_data = {"response": result, "type": "deployment", "intent": intent.value, "entities": entities}
    
    elif intent == IntentType.GET_INSTALL_GUIDE:
        # 获取安装指南
        result = deployment_service.get_installation_guide()
        response_data = {"response": result, "type": "deployment", "intent": intent.value, "entities": entities}
    
    # 3. 非本地指令，调用AI模型生成响应
    else:
        ai_response = aimodel_service.generate_response(user_input)
        response_data = {"response": ai_response, "type": "ai_response", "intent": intent.value, "entities": entities}
    
    # 4. 计算响应时间
    response_time = time.time() - start_time
    
    # 5. 保存交互数据到学习服务
    interaction_data = {
        "user_input": user_input,
        "input_type": request.input_type,
        "intent": intent.value,
        "entities": entities,
        "response": response_data["response"],
        "response_type": response_data["type"],
        "response_time": response_time,
        "context_id": request.context_id
    }
    learning_service.save_interaction_data(interaction_data)
    
    return response_data

# 专用本地控制接口
@ai_assistant_router.post("/local-control")
async def local_control(request: LocalControlRequest):
    """专用本地控制接口
    
    Args:
        request: 本地控制请求
        
    Returns:
        控制执行结果
    """
    command_type = request.command_type
    params = request.params or {}
    
    try:
        if command_type == "open_file":
            file_path = params.get("file_path", "")
            if not file_path:
                raise HTTPException(status_code=400, detail="文件路径不能为空")
            result = local_controller.open_file(file_path)
        
        elif command_type == "take_photo":
            save_path = params.get("save_path", "photo.jpg")
            result = local_controller.take_photo(save_path)
        
        elif command_type == "run_cmd":
            cmd = params.get("cmd", "")
            if not cmd:
                raise HTTPException(status_code=400, detail="命令不能为空")
            result = local_controller.run_system_cmd(cmd)
        
        elif command_type == "list_files":
            directory = params.get("directory", ".")
            result = local_controller.list_files(directory)
        
        elif command_type == "get_system_info":
            result = local_controller.get_system_info()
        
        elif command_type == "open_url":
            url = params.get("url", "")
            if not url:
                raise HTTPException(status_code=400, detail="URL不能为空")
            result = local_controller.open_url(url)
        
        elif command_type == "screenshot":
            save_path = params.get("save_path", "screenshot.jpg")
            result = local_controller.screenshot(save_path)
        
        elif command_type == "create_file":
            file_path = params.get("file_path", "")
            if not file_path:
                raise HTTPException(status_code=400, detail="文件路径不能为空")
            content = params.get("content", "")
            result = local_controller.create_file(file_path, content)
        
        elif command_type == "copy_file":
            source = params.get("source", "")
            destination = params.get("destination", "")
            if not source or not destination:
                raise HTTPException(status_code=400, detail="源文件路径和目标文件路径不能为空")
            result = local_controller.copy_file(source, destination)
        
        elif command_type == "delete_file":
            file_path = params.get("file_path", "")
            if not file_path:
                raise HTTPException(status_code=400, detail="文件路径不能为空")
            result = local_controller.delete_file(file_path)
        
        elif command_type == "start_application":
            app_name = params.get("app_name", "")
            if not app_name:
                raise HTTPException(status_code=400, detail="应用程序名称不能为空")
            result = local_controller.start_application(app_name)
        
        elif command_type == "get_process_list":
            result = local_controller.get_process_list()
        
        else:
            raise HTTPException(status_code=400, detail="不支持的命令类型")
        
        return {"response": result, "success": True}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"执行命令失败: {str(e)}")

# 语音处理接口（示例）
@ai_assistant_router.post("/voice-to-text")
async def voice_to_text(voice_data: str):
    """语音转文字接口（示例）
    
    Args:
        voice_data: 语音数据（base64编码或其他格式）
        
    Returns:
        识别后的文本
    """
    # 实际项目中这里应该调用语音识别模型（如Whisper）
    # 这里返回示例响应
    return {"text": "这是一段语音识别的示例结果", "confidence": 0.95}

@ai_assistant_router.post("/text-to-voice")
async def text_to_voice(text: str):
    """文字转语音接口（示例）
    
    Args:
        text: 要转换的文本
        
    Returns:
        语音数据
    """
    # 实际项目中这里应该调用语音合成模型
    # 这里返回示例响应
    return {"voice_data": "base64_encoded_voice_data", "format": "wav"}

# 学习服务相关接口
@ai_assistant_router.post("/feedback")
async def submit_feedback(feedback: dict):
    """提交反馈数据
    
    Args:
        feedback: 反馈数据，包含评分、评论、交互ID等
        
    Returns:
        反馈提交结果
    """
    try:
        learning_service.save_feedback_data(feedback)
        
        # 如果是负面反馈，触发模型自动更新
        if feedback.get("type") == "negative":
            logger.info("收到负面反馈，触发模型自动更新")
            learning_service.update_model()
        
        return {"status": "success", "message": "反馈提交成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"提交反馈失败: {str(e)}")

@ai_assistant_router.get("/learning/analyze")
async def analyze_data():
    """分析交互数据，生成分析报告
    
    Returns:
        分析报告
    """
    try:
        report = learning_service.analyze_interaction_data()
        return report
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"分析数据失败: {str(e)}")

@ai_assistant_router.post("/learning/update-model")
async def update_ai_model():
    """更新AI模型
    
    Returns:
        模型更新结果
    """
    try:
        result = learning_service.update_model()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"更新模型失败: {str(e)}")

@ai_assistant_router.get("/learning/interactions")
async def get_interactions(limit: int = 100):
    """获取交互数据
    
    Args:
        limit: 返回数据的数量限制
        
    Returns:
        交互数据列表
    """
    try:
        interactions = learning_service.get_interaction_data(limit)
        return {"interactions": interactions, "count": len(interactions)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取交互数据失败: {str(e)}")

@ai_assistant_router.get("/learning/feedbacks")
async def get_feedbacks(limit: int = 100):
    """获取反馈数据
    
    Args:
        limit: 返回数据的数量限制
        
    Returns:
        反馈数据列表
    """
    try:
        feedbacks = learning_service.get_feedback_data(limit)
        return {"feedbacks": feedbacks, "count": len(feedbacks)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取反馈数据失败: {str(e)}")

@ai_assistant_router.post("/learning/clear-old-data")
async def clear_old_data(days: int = 30):
    """清理旧数据
    
    Args:
        days: 保留最近多少天的数据
        
    Returns:
        清理结果
    """
    try:
        result = learning_service.clear_old_data(days)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"清理旧数据失败: {str(e)}")

# 动态意图规则管理接口
@ai_assistant_router.get("/intent-rules")
async def get_intent_rules():
    """获取当前意图识别规则
    
    Returns:
        当前意图识别规则
    """
    try:
        from src.core.services.ai_model_service import aimodel_service
        return {"intent_rules": aimodel_service.intent_rules}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取意图规则失败: {str(e)}")

@ai_assistant_router.post("/intent-rules")
async def update_intent_rules(rules: dict):
    """更新意图识别规则
    
    Args:
        rules: 新的意图识别规则
        
    Returns:
        更新结果
    """
    try:
        from src.core.services.ai_model_service import aimodel_service
        aimodel_service.update_intent_rules(rules)
        return {"status": "success", "message": "意图规则更新成功"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"更新意图规则失败: {str(e)}")

@ai_assistant_router.post("/intent-rules/add")
async def add_intent_keywords(request: dict):
    """添加意图关键词
    
    Args:
        request: 包含意图类型和关键词列表的请求数据
        
    Returns:
        添加结果
    """
    try:
        from src.core.services.ai_model_service import aimodel_service
        intent = request.get("intent")
        keywords = request.get("keywords", [])
        if not intent or not keywords:
            raise HTTPException(status_code=400, detail="意图类型和关键词列表不能为空")
        aimodel_service.add_intent_keywords(intent, keywords)
        return {"status": "success", "message": "意图关键词添加成功"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"添加意图关键词失败: {str(e)}")


# 互联网服务接口
@ai_assistant_router.post("/internet/search")
async def internet_search(query: str, limit: int = 5):
    """搜索互联网
    
    Args:
        query: 搜索查询
        limit: 返回结果数量
        
    Returns:
        搜索结果
    """
    try:
        result = internet_service.search_internet(query, limit=limit)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"搜索互联网失败: {str(e)}")

@ai_assistant_router.post("/internet/retrieve-data")
async def retrieve_data(request: dict):
    """检索数据
    
    Args:
        request: 包含URL和查询参数的请求数据
        
    Returns:
        检索结果
    """
    try:
        url = request.get("url")
        query_params = request.get("query_params", {})
        if not url:
            raise HTTPException(status_code=400, detail="URL不能为空")
        result = internet_service.retrieve_data(url, query_params=query_params)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"检索数据失败: {str(e)}")

@ai_assistant_router.post("/internet/call-api")
async def call_api(request: dict):
    """调用API
    
    Args:
        request: 包含URL、方法和参数的请求数据
        
    Returns:
        API调用结果
    """
    try:
        url = request.get("url")
        method = request.get("method", "GET")
        params = request.get("params", {})
        headers = request.get("headers", {})
        data = request.get("data", {})
        if not url:
            raise HTTPException(status_code=400, detail="URL不能为空")
        result = internet_service.call_api(url, method=method, params=params, headers=headers, data=data)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"调用API失败: {str(e)}")

@ai_assistant_router.post("/internet/download-file")
async def download_file(request: dict):
    """下载文件
    
    Args:
        request: 包含URL和保存路径的请求数据
        
    Returns:
        下载结果
    """
    try:
        url = request.get("url")
        save_path = request.get("save_path", "./")
        if not url:
            raise HTTPException(status_code=400, detail="URL不能为空")
        result = internet_service.download_file(url, save_path=save_path)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"下载文件失败: {str(e)}")


# 智能体编排接口
@ai_assistant_router.get("/agents")
async def get_agents():
    """获取可用智能体列表
    
    Returns:
        智能体列表
    """
    try:
        agents = agent_orchestrator.get_available_agents()
        return {"agents": agents}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取智能体列表失败: {str(e)}")

@ai_assistant_router.post("/agents/register")
async def register_agent(agent_info: dict):
    """注册智能体
    
    Args:
        agent_info: 智能体信息
        
    Returns:
        注册结果
    """
    try:
        result = agent_orchestrator.register_agent(agent_info)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"注册智能体失败: {str(e)}")

@ai_assistant_router.post("/agents/task")
async def delegate_task(task: dict):
    """委托任务给智能体
    
    Args:
        task: 任务信息
        
    Returns:
        任务委托结果
    """
    try:
        task_id = agent_orchestrator.delegate_task(task)
        return {"task_id": task_id, "status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"委托任务失败: {str(e)}")

@ai_assistant_router.get("/agents/task/{task_id}")
async def get_task_result(task_id: str):
    """获取任务结果
    
    Args:
        task_id: 任务ID
        
    Returns:
        任务结果
    """
    try:
        result = agent_orchestrator.get_task_result(task_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取任务结果失败: {str(e)}")


# 设备控制接口
@ai_assistant_router.get("/devices")
async def get_devices():
    """获取所有设备
    
    Returns:
        设备列表
    """
    try:
        devices = device_controller.get_all_devices()
        return {"devices": devices}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取设备列表失败: {str(e)}")

@ai_assistant_router.post("/devices/discover")
async def discover_devices(protocol: str = None):
    """发现设备
    
    Args:
        protocol: 通信协议
        
    Returns:
        发现的设备列表
    """
    try:
        devices = device_controller.discover_devices(protocol=protocol)
        device_dicts = [device.to_dict() for device in devices]
        return {"devices": device_dicts}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"发现设备失败: {str(e)}")

@ai_assistant_router.post("/devices/command")
async def send_device_command(request: dict):
    """向设备发送命令
    
    Args:
        request: 包含设备ID、命令和参数的请求数据
        
    Returns:
        命令执行结果
    """
    try:
        device_id = request.get("device_id")
        command = request.get("command")
        params = request.get("params", {})
        if not device_id or not command:
            raise HTTPException(status_code=400, detail="设备ID和命令不能为空")
        result = device_controller.send_command(device_id, command, params)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"向设备发送命令失败: {str(e)}")

@ai_assistant_router.get("/devices/health")
async def device_health_check():
    """设备健康检查
    
    Returns:
        健康检查结果
    """
    try:
        result = device_controller.health_check()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"设备健康检查失败: {str(e)}")

@ai_assistant_router.post("/devices/group")
async def create_device_group(request: dict):
    """创建设备组
    
    Args:
        request: 包含组名称和设备ID列表的请求数据
        
    Returns:
        创建设备组结果
    """
    try:
        name = request.get("name")
        device_ids = request.get("device_ids", [])
        if not name:
            raise HTTPException(status_code=400, detail="组名称不能为空")
        group_id = device_controller.create_device_group(name, device_ids)
        return {"group_id": group_id, "status": "success"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"创建设备组失败: {str(e)}")


# 用户习惯接口
@ai_assistant_router.post("/habits/record")
async def record_behavior(request: dict):
    """记录用户行为
    
    Args:
        request: 包含用户ID、行为类型和参数的请求数据
        
    Returns:
        记录结果
    """
    try:
        user_id = request.get("user_id", "default_user")
        behavior_type = request.get("behavior_type")
        params = request.get("params", {})
        if not behavior_type:
            raise HTTPException(status_code=400, detail="行为类型不能为空")
        result = user_habit_service.record_user_behavior(user_id, behavior_type, params)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"记录用户行为失败: {str(e)}")

@ai_assistant_router.get("/habits/analyze/{user_id}")
async def analyze_user_habits(user_id: str, time_range_days: int = 7):
    """分析用户习惯
    
    Args:
        user_id: 用户ID
        time_range_days: 分析的时间范围（天）
        
    Returns:
        习惯分析结果
    """
    try:
        result = user_habit_service.analyze_user_habits(user_id, time_range_days=time_range_days)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"分析用户习惯失败: {str(e)}")

@ai_assistant_router.post("/habits/predict")
async def predict_user_behavior(request: dict):
    """预测用户行为
    
    Args:
        request: 包含用户ID和上下文的请求数据
        
    Returns:
        行为预测结果
    """
    try:
        user_id = request.get("user_id", "default_user")
        context = request.get("context", {})
        result = user_habit_service.predict_user_behavior(user_id, context)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"预测用户行为失败: {str(e)}")

@ai_assistant_router.get("/habits/recommendations/{user_id}")
async def get_habit_recommendations(user_id: str):
    """获取习惯推荐
    
    Args:
        user_id: 用户ID
        
    Returns:
        习惯推荐列表
    """
    try:
        recommendations = user_habit_service.get_habit_recommendations(user_id)
        return {"recommendations": recommendations}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取习惯推荐失败: {str(e)}")

@ai_assistant_router.get("/habits/profile/{user_id}")
async def get_user_profile(user_id: str):
    """获取用户画像
    
    Args:
        user_id: 用户ID
        
    Returns:
        用户画像
    """
    try:
        profile = user_habit_service.get_user_profile(user_id)
        return profile
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取用户画像失败: {str(e)}")


# 自动部署接口
@ai_assistant_router.get("/deployment/check-update")
async def check_for_updates():
    """检查更新
    
    Returns:
        更新检查结果
    """
    try:
        result = deployment_service.check_for_updates()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"检查更新失败: {str(e)}")

@ai_assistant_router.post("/deployment/update")
async def update_application():
    """更新应用程序
    
    Returns:
        更新结果
    """
    try:
        result = deployment_service.update_application()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"更新应用程序失败: {str(e)}")

@ai_assistant_router.post("/deployment/generate-package")
async def generate_installation_package():
    """生成本地安装包
    
    Returns:
        安装包生成结果
    """
    try:
        result = deployment_service.generate_installation_package()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"生成本地安装包失败: {str(e)}")

@ai_assistant_router.get("/deployment/status")
async def get_deployment_status():
    """获取部署状态
    
    Returns:
        部署状态信息
    """
    try:
        status = deployment_service.get_deployment_status()
        return status
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取部署状态失败: {str(e)}")

@ai_assistant_router.get("/deployment/install-guide")
async def get_installation_guide():
    """获取安装指南
    
    Returns:
        安装指南信息
    """
    try:
        guide = deployment_service.get_installation_guide()
        return guide
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取安装指南失败: {str(e)}")

@ai_assistant_router.post("/deployment/config")
async def update_deployment_config(config: dict):
    """更新部署配置
    
    Args:
        config: 新的部署配置
        
    Returns:
        更新结果
    """
    try:
        result = deployment_service.update_config(config)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"更新部署配置失败: {str(e)}")
