"""智能体编排服务
提供智能体注册、任务分解、任务委派、结果聚合等功能
"""

from typing import Optional, Dict, List, Any, Callable
import logging
import uuid
import time
from enum import Enum

# 配置日志
logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    """任务状态枚举"""
    PENDING = "pending"      # 待处理
    RUNNING = "running"      # 执行中
    COMPLETED = "completed"  # 已完成
    FAILED = "failed"        # 失败
    CANCELLED = "cancelled"  # 已取消


class AgentStatus(str, Enum):
    """智能体状态枚举"""
    AVAILABLE = "available"    # 可用
    BUSY = "busy"              # 忙碌
    OFFLINE = "offline"         # 离线
    ERROR = "error"             # 错误


class AgentType(str, Enum):
    """智能体类型枚举"""
    SEARCH = "search"           # 搜索智能体
    ANALYSIS = "analysis"       # 分析智能体
    WRITING = "writing"         # 写作智能体
    CODE = "code"               # 代码智能体
    TRANSLATION = "translation" # 翻译智能体
    IMAGE = "image"             # 图像智能体
    AUDIO = "audio"             # 音频智能体
    VIDEO = "video"             # 视频智能体
    OTHER = "other"             # 其他类型


class Task:
    """任务类"""
    
    def __init__(self, task_id: Optional[str] = None, task_type: str = "general", 
                 description: str = "", priority: int = 0, 
                 agent_type: Optional[str] = None):
        """初始化任务
        
        Args:
            task_id: 任务ID
            task_type: 任务类型
            description: 任务描述
            priority: 任务优先级
            agent_type: 适用的智能体类型
        """
        self.task_id = task_id or str(uuid.uuid4())
        self.task_type = task_type
        self.description = description
        self.priority = priority
        self.agent_type = agent_type
        self.status = TaskStatus.PENDING
        self.result = None
        self.error = None
        self.created_at = time.time()
        self.started_at = None
        self.completed_at = None
        self.assigned_agent_id = None
        self.subtasks = []
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "description": self.description,
            "priority": self.priority,
            "agent_type": self.agent_type,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "assigned_agent_id": self.assigned_agent_id,
            "subtasks": [subtask.to_dict() for subtask in self.subtasks]
        }


class Agent:
    """智能体类"""
    
    def __init__(self, agent_id: str, name: str, agent_type: str, 
                 endpoint: str, status: str = AgentStatus.AVAILABLE):
        """初始化智能体
        
        Args:
            agent_id: 智能体ID
            name: 智能体名称
            agent_type: 智能体类型
            endpoint: 智能体端点
            status: 智能体状态
        """
        self.agent_id = agent_id
        self.name = name
        self.agent_type = agent_type
        self.endpoint = endpoint
        self.status = status
        self.current_task_id = None
        self.capabilities = []
        self.last_heartbeat = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "agent_type": self.agent_type,
            "endpoint": self.endpoint,
            "status": self.status,
            "current_task_id": self.current_task_id,
            "capabilities": self.capabilities,
            "last_heartbeat": self.last_heartbeat
        }


class AgentOrchestrator:
    """智能体编排服务类"""
    
    def __init__(self):
        """初始化智能体编排服务"""
        self.agents = {}  # 智能体注册表
        self.tasks = {}   # 任务注册表
        self.agent_callbacks = {}  # 智能体回调注册表
        logger.info("智能体编排服务初始化完成")
    
    def register_agent(self, agent: Agent) -> bool:
        """注册智能体
        
        Args:
            agent: 智能体对象
            
        Returns:
            注册是否成功
        """
        try:
            self.agents[agent.agent_id] = agent
            logger.info(f"智能体注册成功: {agent.name} ({agent.agent_id})")
            return True
        except Exception as e:
            logger.error(f"智能体注册失败: {str(e)}")
            return False
    
    def unregister_agent(self, agent_id: str) -> bool:
        """注销智能体
        
        Args:
            agent_id: 智能体ID
            
        Returns:
            注销是否成功
        """
        try:
            if agent_id in self.agents:
                del self.agents[agent_id]
                logger.info(f"智能体注销成功: {agent_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"智能体注销失败: {str(e)}")
            return False
    
    def get_available_agents(self, agent_type: Optional[str] = None) -> List[Agent]:
        """获取可用智能体列表
        
        Args:
            agent_type: 智能体类型
            
        Returns:
            可用智能体列表
        """
        available_agents = []
        for agent in self.agents.values():
            if agent.status == AgentStatus.AVAILABLE:
                if agent_type is None or agent.agent_type == agent_type:
                    available_agents.append(agent)
        return available_agents
    
    def create_task(self, task_type: str, description: str, priority: int = 0, 
                    agent_type: Optional[str] = None) -> Task:
        """创建任务
        
        Args:
            task_type: 任务类型
            description: 任务描述
            priority: 任务优先级
            agent_type: 适用的智能体类型
            
        Returns:
            任务对象
        """
        task = Task(
            task_type=task_type,
            description=description,
            priority=priority,
            agent_type=agent_type
        )
        self.tasks[task.task_id] = task
        logger.info(f"任务创建成功: {task.task_id} - {description}")
        return task
    
    def assign_task(self, task_id: str, agent_id: Optional[str] = None) -> bool:
        """分配任务
        
        Args:
            task_id: 任务ID
            agent_id: 智能体ID
            
        Returns:
            分配是否成功
        """
        try:
            if task_id not in self.tasks:
                logger.error(f"任务不存在: {task_id}")
                return False
            
            task = self.tasks[task_id]
            
            # 如果没有指定智能体，则自动选择
            if not agent_id:
                available_agents = self.get_available_agents(task.agent_type)
                if not available_agents:
                    logger.error(f"没有可用的智能体: {task.agent_type}")
                    return False
                # 简单的负载均衡：选择第一个可用智能体
                agent = available_agents[0]
            else:
                if agent_id not in self.agents:
                    logger.error(f"智能体不存在: {agent_id}")
                    return False
                agent = self.agents[agent_id]
            
            # 检查智能体状态
            if agent.status != AgentStatus.AVAILABLE:
                logger.error(f"智能体不可用: {agent_id} - {agent.status}")
                return False
            
            # 分配任务
            task.status = TaskStatus.RUNNING
            task.assigned_agent_id = agent.agent_id
            task.started_at = time.time()
            
            # 更新智能体状态
            agent.status = AgentStatus.BUSY
            agent.current_task_id = task_id
            
            logger.info(f"任务分配成功: {task_id} -> {agent_id} ({agent.name})")
            return True
            
        except Exception as e:
            logger.error(f"任务分配失败: {str(e)}")
            return False
    
    def complete_task(self, task_id: str, result: Any) -> bool:
        """完成任务
        
        Args:
            task_id: 任务ID
            result: 任务结果
            
        Returns:
            完成是否成功
        """
        try:
            if task_id not in self.tasks:
                logger.error(f"任务不存在: {task_id}")
                return False
            
            task = self.tasks[task_id]
            task.status = TaskStatus.COMPLETED
            task.result = result
            task.completed_at = time.time()
            
            # 更新智能体状态
            if task.assigned_agent_id and task.assigned_agent_id in self.agents:
                agent = self.agents[task.assigned_agent_id]
                agent.status = AgentStatus.AVAILABLE
                agent.current_task_id = None
            
            logger.info(f"任务完成: {task_id}")
            return True
            
        except Exception as e:
            logger.error(f"任务完成处理失败: {str(e)}")
            return False
    
    def fail_task(self, task_id: str, error: str) -> bool:
        """标记任务失败
        
        Args:
            task_id: 任务ID
            error: 失败原因
            
        Returns:
            处理是否成功
        """
        try:
            if task_id not in self.tasks:
                logger.error(f"任务不存在: {task_id}")
                return False
            
            task = self.tasks[task_id]
            task.status = TaskStatus.FAILED
            task.error = error
            task.completed_at = time.time()
            
            # 更新智能体状态
            if task.assigned_agent_id and task.assigned_agent_id in self.agents:
                agent = self.agents[task.assigned_agent_id]
                agent.status = AgentStatus.AVAILABLE
                agent.current_task_id = None
            
            logger.error(f"任务失败: {task_id} - {error}")
            return True
            
        except Exception as e:
            logger.error(f"任务失败处理失败: {str(e)}")
            return False
    
    def cancel_task(self, task_id: str) -> bool:
        """取消任务
        
        Args:
            task_id: 任务ID
            
        Returns:
            取消是否成功
        """
        try:
            if task_id not in self.tasks:
                logger.error(f"任务不存在: {task_id}")
                return False
            
            task = self.tasks[task_id]
            task.status = TaskStatus.CANCELLED
            task.completed_at = time.time()
            
            # 更新智能体状态
            if task.assigned_agent_id and task.assigned_agent_id in self.agents:
                agent = self.agents[task.assigned_agent_id]
                agent.status = AgentStatus.AVAILABLE
                agent.current_task_id = None
            
            logger.info(f"任务取消: {task_id}")
            return True
            
        except Exception as e:
            logger.error(f"任务取消处理失败: {str(e)}")
            return False
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """获取任务
        
        Args:
            task_id: 任务ID
            
        Returns:
            任务对象或None
        """
        return self.tasks.get(task_id)
    
    def get_tasks_by_status(self, status: TaskStatus) -> List[Task]:
        """获取指定状态的任务列表
        
        Args:
            status: 任务状态
            
        Returns:
            任务列表
        """
        return [task for task in self.tasks.values() if task.status == status]
    
    def update_agent_status(self, agent_id: str, status: AgentStatus) -> bool:
        """更新智能体状态
        
        Args:
            agent_id: 智能体ID
            status: 智能体状态
            
        Returns:
            更新是否成功
        """
        try:
            if agent_id in self.agents:
                self.agents[agent_id].status = status
                self.agents[agent_id].last_heartbeat = time.time()
                logger.info(f"智能体状态更新: {agent_id} -> {status}")
                return True
            return False
        except Exception as e:
            logger.error(f"智能体状态更新失败: {str(e)}")
            return False
    
    def heartbeat(self, agent_id: str) -> bool:
        """智能体心跳
        
        Args:
            agent_id: 智能体ID
            
        Returns:
            心跳处理是否成功
        """
        try:
            if agent_id in self.agents:
                self.agents[agent_id].last_heartbeat = time.time()
                if self.agents[agent_id].status == AgentStatus.OFFLINE:
                    self.agents[agent_id].status = AgentStatus.AVAILABLE
                return True
            return False
        except Exception as e:
            logger.error(f"心跳处理失败: {str(e)}")
            return False
    
    def register_agent_callback(self, agent_id: str, callback: Callable) -> bool:
        """注册智能体回调
        
        Args:
            agent_id: 智能体ID
            callback: 回调函数
            
        Returns:
            注册是否成功
        """
        try:
            self.agent_callbacks[agent_id] = callback
            logger.info(f"智能体回调注册成功: {agent_id}")
            return True
        except Exception as e:
            logger.error(f"智能体回调注册失败: {str(e)}")
            return False
    
    def execute_task(self, task_type: str, description: str, priority: int = 0, 
                     agent_type: Optional[str] = None) -> Any:
        """执行任务（同步方式）
        
        Args:
            task_type: 任务类型
            description: 任务描述
            priority: 任务优先级
            agent_type: 适用的智能体类型
            
        Returns:
            任务结果
        """
        # 创建任务
        task = self.create_task(task_type, description, priority, agent_type)
        
        # 分配任务
        if not self.assign_task(task.task_id):
            return {
                "error": "无法分配任务",
                "task_id": task.task_id
            }
        
        # 等待任务完成（简单的轮询机制）
        max_wait_time = 60  # 最大等待时间（秒）
        wait_interval = 0.5  # 轮询间隔（秒）
        start_time = time.time()
        
        while time.time() - start_time < max_wait_time:
            task = self.get_task(task.task_id)
            if task.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]:
                break
            time.sleep(wait_interval)
        
        # 返回结果
        if task.status == TaskStatus.COMPLETED:
            return task.result
        elif task.status == TaskStatus.FAILED:
            return {
                "error": task.error,
                "task_id": task.task_id
            }
        else:
            return {
                "error": "任务超时",
                "task_id": task.task_id
            }


# 单例模式
agent_orchestrator = AgentOrchestrator()