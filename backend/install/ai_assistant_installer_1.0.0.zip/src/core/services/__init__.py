"""
核心服务模块
提供全局共享的服务实例
"""

from .model_manager import ModelManager
from .inference_engine import InferenceEngine
from .camera_controller import CameraController
from .ptz_camera_controller import (
    PTZCameraController, 
    PTZProtocol, 
    PTZAction,
    get_ptz_controller
)
from .async_cache_service import AsyncMemoryCache, memory_cache
from .device_auth_manager import DeviceAuthManager
from .connection_pool_manager import ConnectionPoolManager
from .audit_monitoring_service import AuditLogMonitoringService
from .hardware_controller import SpectrumHardwareController, hardware_controller, advanced_features

import os

# 获取项目根目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 向上跳出4层目录到达项目根目录 (services -> core -> src -> backend -> root)
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_dir))))
models_dir = os.path.join(project_root, "models")

# 创建全局共享的服务实例
model_manager = ModelManager(models_dir)
inference_engine = InferenceEngine(model_manager)
device_auth_manager = DeviceAuthManager()
connection_pool_manager = ConnectionPoolManager()
audit_monitoring_service = AuditLogMonitoringService()

__all__ = [
    # 服务类
    "ModelManager",
    "InferenceEngine",
    "CameraController",
    "PTZCameraController",
    "PTZProtocol",
    "PTZAction",
    "AsyncMemoryCache",
    "DeviceAuthManager",
    "ConnectionPoolManager",
    "AuditLogMonitoringService",
    "SpectrumHardwareController",
    
    # 工具函数
    "get_ptz_controller",
    
    # 全局实例
    "model_manager",
    "inference_engine",
    "memory_cache",
    "device_auth_manager",
    "connection_pool_manager",
    "audit_monitoring_service",
    "hardware_controller",
    "advanced_features"
]
