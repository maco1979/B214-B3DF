"""自动部署服务
提供版本管理、安装管理、更新管理、配置管理等功能
支持本地安装包生成和自动更新
"""

from typing import Dict, List, Any, Optional, Tuple
import logging
import os
import shutil
import zipfile
import subprocess
from pathlib import Path
import json
import requests
from datetime import datetime
import uuid

# 配置日志
logger = logging.getLogger(__name__)


class DeploymentStatus(str):
    """部署状态枚举"""
    IDLE = "idle"           # 空闲
    INSTALLING = "installing"   # 安装中
    UPDATING = "updating"     # 更新中
    SUCCESS = "success"      # 成功
    FAILED = "failed"        # 失败
    CHECKING = "checking"     # 检查中


class DeploymentService:
    """自动部署服务类
    
    功能：
    1. 版本管理
    2. 安装管理
    3. 更新管理
    4. 配置管理
    5. 部署状态监控
    """
    
    def __init__(self, config_dir: str = "data/deployment"):
        """初始化自动部署服务
        
        Args:
            config_dir: 部署配置存储目录
        """
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # 配置文件路径
        self.config_file = self.config_dir / "deployment_config.json"
        self.version_file = self.config_dir / "version.json"
        
        # 当前部署状态
        self.deployment_status = DeploymentStatus.IDLE
        self.latest_version = None
        self.update_info = {}
        
        # 加载配置
        self.config = self._load_config()
        
        # 获取当前版本
        self.current_version = self._get_current_version()
        
        logger.info(f"自动部署服务初始化完成，当前版本: {self.current_version}")
    
    def _load_config(self) -> Dict[str, Any]:
        """加载部署配置"""
        default_config = {
            "auto_update": True,
            "update_check_interval": 3600,  # 1小时
            "install_dir": "./install",
            "backup_dir": "./backups",
            "repo_url": "https://github.com/example/ai-assistant",
            "release_url": "https://api.github.com/repos/example/ai-assistant/releases/latest"
        }
        
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    config = json.load(f)
                    # 合并默认配置和用户配置
                    default_config.update(config)
                    return default_config
            except Exception as e:
                logger.error(f"加载部署配置失败: {e}")
                return default_config
        
        # 保存默认配置
        self._save_config(default_config)
        return default_config
    
    def _save_config(self, config: Dict[str, Any]):
        """保存部署配置"""
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            self.config = config
        except Exception as e:
            logger.error(f"保存部署配置失败: {e}")
    
    def _get_current_version(self) -> str:
        """获取当前版本"""
        # 从version.json文件中获取版本信息
        if self.version_file.exists():
            try:
                with open(self.version_file, "r", encoding="utf-8") as f:
                    version_info = json.load(f)
                    return version_info.get("version", "1.0.0")
            except Exception as e:
                logger.error(f"获取当前版本失败: {e}")
        
        # 如果没有version.json文件，创建一个默认的
        default_version = {
            "version": "1.0.0",
            "build_time": datetime.now().isoformat(),
            "commit": "local_build"
        }
        
        self._save_version_info(default_version)
        return default_version["version"]
    
    def _save_version_info(self, version_info: Dict[str, Any]):
        """保存版本信息"""
        try:
            with open(self.version_file, "w", encoding="utf-8") as f:
                json.dump(version_info, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存版本信息失败: {e}")
    
    def check_for_updates(self) -> Dict[str, Any]:
        """检查更新
        
        Returns:
            更新检查结果
        """
        logger.info("开始检查更新")
        self.deployment_status = DeploymentStatus.CHECKING
        
        try:
            # 调用GitHub API获取最新版本信息
            response = requests.get(self.config["release_url"])
            if response.status_code == 200:
                release_info = response.json()
                self.latest_version = release_info["tag_name"]
                
                # 解析版本号，比较是否有更新
                current_ver = self._parse_version(self.current_version)
                latest_ver = self._parse_version(self.latest_version)
                
                update_available = latest_ver > current_ver
                
                self.update_info = {
                    "current_version": self.current_version,
                    "latest_version": self.latest_version,
                    "update_available": update_available,
                    "release_notes": release_info.get("body", ""),
                    "published_at": release_info.get("published_at", ""),
                    "download_url": release_info["assets"][0]["browser_download_url"] if release_info.get("assets") else ""
                }
                
                self.deployment_status = DeploymentStatus.SUCCESS
                logger.info(f"更新检查完成，当前版本: {self.current_version}，最新版本: {self.latest_version}")
                return self.update_info
            else:
                logger.error(f"获取最新版本失败，状态码: {response.status_code}")
                self.deployment_status = DeploymentStatus.FAILED
                return {
                    "current_version": self.current_version,
                    "update_available": False,
                    "error": f"获取最新版本失败，状态码: {response.status_code}"
                }
        except Exception as e:
            logger.error(f"检查更新失败: {e}")
            self.deployment_status = DeploymentStatus.FAILED
            return {
                "current_version": self.current_version,
                "update_available": False,
                "error": str(e)
            }
    
    def _parse_version(self, version: str) -> Tuple[int, int, int]:
        """解析版本号为整数元组，用于比较
        
        Args:
            version: 版本号字符串，如 "v1.2.3" 或 "1.2.3"
            
        Returns:
            版本号元组，如 (1, 2, 3)
        """
        # 移除前缀 "v" 或 "V"
        if version.startswith("v") or version.startswith("V"):
            version = version[1:]
        
        # 分割版本号并转换为整数
        parts = version.split(".")
        major = int(parts[0]) if len(parts) > 0 else 0
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch = int(parts[2]) if len(parts) > 2 else 0
        
        return (major, minor, patch)
    
    def update_application(self) -> Dict[str, Any]:
        """更新应用程序
        
        Returns:
            更新结果
        """
        logger.info("开始更新应用程序")
        self.deployment_status = DeploymentStatus.UPDATING
        
        try:
            # 检查是否有可用更新
            if not self.update_info or not self.update_info.get("update_available"):
                self.check_for_updates()
                
            if not self.update_info.get("update_available"):
                return {
                    "success": False,
                    "message": "当前已是最新版本"
                }
            
            # 备份当前版本
            backup_result = self._backup_current_version()
            if not backup_result["success"]:
                return backup_result
            
            # 下载最新版本
            download_result = self._download_latest_version()
            if not download_result["success"]:
                return download_result
            
            # 安装更新
            install_result = self._install_update(download_result["file_path"])
            if install_result["success"]:
                # 更新版本信息
                self.current_version = self.latest_version
                self._save_version_info({
                    "version": self.current_version,
                    "build_time": datetime.now().isoformat(),
                    "commit": f"update_{uuid.uuid4()[:8]}"
                })
                
                self.deployment_status = DeploymentStatus.SUCCESS
                logger.info(f"应用程序更新成功，当前版本: {self.current_version}")
                return {
                    "success": True,
                    "message": f"应用程序已成功更新到版本 {self.current_version}",
                    "new_version": self.current_version
                }
            else:
                # 回滚到备份版本
                self._rollback_to_backup(backup_result["backup_path"])
                self.deployment_status = DeploymentStatus.FAILED
                return install_result
                
        except Exception as e:
            logger.error(f"更新应用程序失败: {e}")
            self.deployment_status = DeploymentStatus.FAILED
            return {
                "success": False,
                "error": str(e)
            }
    
    def _backup_current_version(self) -> Dict[str, Any]:
        """备份当前版本
        
        Returns:
            备份结果
        """
        try:
            backup_dir = Path(self.config["backup_dir"])
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            # 创建备份文件名
            backup_name = f"backup_{self.current_version}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            backup_path = backup_dir / backup_name
            
            # 备份主要目录
            source_dirs = ["./src", "./requirements.txt", "./package.json"]
            
            # 创建zip文件
            zip_file = backup_dir / f"{backup_name}.zip"
            with zipfile.ZipFile(zip_file, "w", zipfile.ZIP_DEFLATED) as zf:
                for item in source_dirs:
                    item_path = Path(item)
                    if item_path.exists():
                        if item_path.is_dir():
                            for root, _, files in os.walk(item_path):
                                for file in files:
                                    file_path = os.path.join(root, file)
                                    arcname = os.path.relpath(file_path, ".")
                                    zf.write(file_path, arcname)
                        else:
                            zf.write(item_path, item_path.name)
            
            logger.info(f"当前版本备份成功: {zip_file}")
            return {
                "success": True,
                "backup_path": str(zip_file),
                "backup_name": backup_name
            }
        except Exception as e:
            logger.error(f"备份当前版本失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _download_latest_version(self) -> Dict[str, Any]:
        """下载最新版本
        
        Returns:
            下载结果
        """
        try:
            if not self.update_info.get("download_url"):
                return {
                    "success": False,
                    "error": "下载地址不存在"
                }
            
            download_url = self.update_info["download_url"]
            
            # 创建下载目录
            download_dir = Path("./downloads")
            download_dir.mkdir(parents=True, exist_ok=True)
            
            # 下载文件
            file_name = download_url.split("/")[-1]
            file_path = download_dir / file_name
            
            response = requests.get(download_url, stream=True)
            if response.status_code == 200:
                with open(file_path, "wb") as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                
                logger.info(f"最新版本下载成功: {file_path}")
                return {
                    "success": True,
                    "file_path": str(file_path),
                    "file_name": file_name
                }
            else:
                return {
                    "success": False,
                    "error": f"下载失败，状态码: {response.status_code}"
                }
        except Exception as e:
            logger.error(f"下载最新版本失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _install_update(self, file_path: str) -> Dict[str, Any]:
        """安装更新
        
        Args:
            file_path: 更新文件路径
            
        Returns:
            安装结果
        """
        try:
            # 解压更新文件
            temp_dir = Path("./temp_update")
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            with zipfile.ZipFile(file_path, "r") as zf:
                zf.extractall(temp_dir)
            
            # 安装依赖
            if Path(temp_dir / "requirements.txt").exists():
                logger.info("安装Python依赖")
                subprocess.run(["pip", "install", "-r", str(temp_dir / "requirements.txt")], check=True)
            
            if Path(temp_dir / "package.json").exists():
                logger.info("安装Node.js依赖")
                subprocess.run(["npm", "install"], cwd=str(temp_dir), check=True)
            
            # 复制更新文件到项目目录
            source_dir = temp_dir / "src" if (temp_dir / "src").exists() else temp_dir
            target_dir = Path("./src")
            
            # 递归复制目录
            if source_dir.exists():
                # 清空目标目录
                if target_dir.exists():
                    shutil.rmtree(target_dir)
                
                # 复制新文件
                shutil.copytree(source_dir, target_dir)
            
            # 清理临时目录
            shutil.rmtree(temp_dir)
            
            logger.info("更新安装成功")
            return {
                "success": True,
                "message": "更新安装成功"
            }
        except subprocess.CalledProcessError as e:
            logger.error(f"安装依赖失败: {e}")
            return {
                "success": False,
                "error": f"安装依赖失败: {str(e)}"
            }
        except Exception as e:
            logger.error(f"安装更新失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _rollback_to_backup(self, backup_path: str) -> Dict[str, Any]:
        """回滚到备份版本
        
        Args:
            backup_path: 备份文件路径
            
        Returns:
            回滚结果
        """
        try:
            logger.info(f"开始回滚到备份版本: {backup_path}")
            
            # 解压备份文件
            temp_dir = Path("./temp_rollback")
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            with zipfile.ZipFile(backup_path, "r") as zf:
                zf.extractall(temp_dir)
            
            # 复制文件到项目目录
            source_dir = temp_dir
            
            # 复制主要目录
            target_dirs = ["./src"]
            for target_dir in target_dirs:
                target_path = Path(target_dir)
                if target_path.exists():
                    shutil.rmtree(target_path)
                shutil.copytree(source_dir / target_dir, target_path)
            
            # 复制配置文件
            config_files = ["requirements.txt", "package.json"]
            for config_file in config_files:
                if (source_dir / config_file).exists():
                    shutil.copy2(source_dir / config_file, Path(config_file))
            
            # 清理临时目录
            shutil.rmtree(temp_dir)
            
            logger.info(f"回滚到备份版本成功: {backup_path}")
            return {
                "success": True,
                "message": f"已成功回滚到备份版本"
            }
        except Exception as e:
            logger.error(f"回滚到备份版本失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def generate_installation_package(self) -> Dict[str, Any]:
        """生成本地安装包
        
        Returns:
            安装包生成结果
        """
        try:
            logger.info("开始生成本地安装包")
            
            # 创建安装包目录
            install_dir = Path(self.config["install_dir"])
            install_dir.mkdir(parents=True, exist_ok=True)
            
            # 生成安装包文件名
            package_name = f"ai_assistant_installer_{self.current_version}.zip"
            package_path = install_dir / package_name
            
            # 要包含的文件和目录
            include_items = [
                "./src",
                "./requirements.txt",
                "./package.json",
                "./README.md",
                "./setup.py",
                "./install.bat",
                "./install.sh",
                "../frontend/dist"  # 包含前端构建产物
            ]
            
            # 创建zip文件
            with zipfile.ZipFile(package_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for item in include_items:
                    item_path = Path(item)
                    if item_path.exists():
                        if item_path.is_dir():
                            # 递归添加目录内容
                            for root, _, files in os.walk(item_path):
                                for file in files:
                                    file_full_path = Path(root) / file
                                    # 计算相对路径
                                    arcname = file_full_path.relative_to(Path("."))
                                    zf.write(file_full_path, arcname)
                        else:
                            # 添加单个文件
                            zf.write(item_path, item_path.name)
            
            # 生成安装脚本
            self._generate_install_scripts(install_dir)
            
            logger.info(f"本地安装包生成成功: {package_path}")
            return {
                "success": True,
                "package_path": str(package_path),
                "package_name": package_name,
                "size": package_path.stat().st_size,
                "message": f"本地安装包已成功生成: {package_name}"
            }
        except Exception as e:
            logger.error(f"生成本地安装包失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def _generate_install_scripts(self, install_dir: Path):
        """生成安装脚本
        
        Args:
            install_dir: 安装目录
        """
        try:
            # 生成Windows安装脚本
            windows_script = """@echo off
            echo AI Assistant 安装脚本
            echo ===================
            
            echo 正在安装Python依赖...
            pip install -r requirements.txt
            
            echo 正在安装Node.js依赖...
            npm install
            
            echo 正在创建配置文件...
            python -c "from src.core.services.deployment_service import deployment_service; deployment_service._generate_config_file()"
            
            echo 安装完成！
            echo 您可以使用以下命令启动应用程序：
            echo python -m uvicorn src.main:app --host 0.0.0.0 --port 8001
            pause
            """
            
            with open(install_dir / "install.bat", "w") as f:
                f.write(windows_script)
            
            # 生成Linux/Mac安装脚本
            linux_script = """#!/bin/bash
            echo "AI Assistant 安装脚本"
            echo "==================="
            
            echo "正在安装Python依赖..."
            pip install -r requirements.txt
            
            echo "正在安装Node.js依赖..."
            npm install
            
            echo "正在创建配置文件..."
            python -c "from src.core.services.deployment_service import deployment_service; deployment_service._generate_config_file()"
            
            echo "安装完成！"
            echo "您可以使用以下命令启动应用程序："
            echo "python -m uvicorn src.main:app --host 0.0.0.0 --port 8001"
            """
            
            with open(install_dir / "install.sh", "w") as f:
                f.write(linux_script)
            
            # 设置执行权限
            import stat
            os.chmod(install_dir / "install.sh", stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
            
        except Exception as e:
            logger.error(f"生成安装脚本失败: {e}")
    
    def _generate_config_file(self):
        """生成配置文件
        供安装脚本调用
        """
        try:
            config_dir = Path("./config")
            config_dir.mkdir(parents=True, exist_ok=True)
            
            # 生成默认配置文件
            default_config = {
                "app": {
                    "name": "AI Assistant",
                    "version": self.current_version,
                    "host": "0.0.0.0",
                    "port": 8001,
                    "debug": True
                },
                "database": {
                    "type": "sqlite",
                    "path": "./data/ai_assistant.db"
                },
                "ai_model": {
                    "name": "default",
                    "api_key": "",
                    "temperature": 0.7
                },
                "internet_service": {
                    "enabled": True,
                    "search_engine": "google"
                },
                "device_control": {
                    "enabled": True,
                    "discovery_protocols": ["ssdp", "mdns"]
                }
            }
            
            with open(config_dir / "config.json", "w", encoding="utf-8") as f:
                json.dump(default_config, f, ensure_ascii=False, indent=2)
            
            logger.info("配置文件生成成功")
        except Exception as e:
            logger.error(f"生成配置文件失败: {e}")
    
    def get_deployment_status(self) -> Dict[str, Any]:
        """获取部署状态
        
        Returns:
            部署状态信息
        """
        return {
            "status": self.deployment_status,
            "current_version": self.current_version,
            "latest_version": self.latest_version,
            "update_info": self.update_info
        }
    
    def update_config(self, new_config: Dict[str, Any]) -> Dict[str, Any]:
        """更新部署配置
        
        Args:
            new_config: 新的配置
            
        Returns:
            更新结果
        """
        try:
            # 合并配置
            self.config.update(new_config)
            self._save_config(self.config)
            
            logger.info("部署配置更新成功")
            return {
                "success": True,
                "message": "部署配置已成功更新",
                "config": self.config
            }
        except Exception as e:
            logger.error(f"更新部署配置失败: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_installation_guide(self) -> Dict[str, Any]:
        """获取安装指南
        
        Returns:
            安装指南信息
        """
        return {
            "current_version": self.current_version,
            "installation_steps": [
                {
                    "step": 1,
                    "title": "下载安装包",
                    "description": "从GitHub Releases页面下载最新版本的安装包"
                },
                {
                    "step": 2,
                    "title": "解压安装包",
                    "description": "将安装包解压到您选择的目录"
                },
                {
                    "step": 3,
                    "title": "运行安装脚本",
                    "description": "根据您的操作系统运行对应的安装脚本：\n- Windows: install.bat\n- Linux/Mac: ./install.sh"
                },
                {
                    "step": 4,
                    "title": "配置应用程序",
                    "description": "编辑config/config.json文件，配置必要的参数"
                },
                {
                    "step": 5,
                    "title": "启动应用程序",
                    "description": "使用命令：python -m uvicorn src.main:app --host 0.0.0.0 --port 8001"
                },
                {
                    "step": 6,
                    "title": "访问应用程序",
                    "description": "在浏览器中访问 http://localhost:8001"
                }
            ],
            "system_requirements": {
                "python": ">=3.8",
                "nodejs": ">=14.0",
                "memory": "至少 2GB RAM",
                "disk_space": "至少 1GB 可用空间"
            },
            "dependencies": "详见requirements.txt和package.json文件"
        }


# 单例模式
deployment_service = DeploymentService()
