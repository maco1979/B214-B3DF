"""AI模型服务
提供AI模型加载、意图识别、对话生成等功能
"""

from typing import Optional, List, Dict
from enum import Enum
import os
import logging
import json

# 配置日志
logger = logging.getLogger(__name__)

# 意图类型枚举
class IntentType(str, Enum):
    """意图类型枚举"""
    CHAT = "chat"  # 普通聊天
    OPEN_FILE = "open_file"  # 打开文件
    TAKE_PHOTO = "take_photo"  # 拍照
    RUN_COMMAND = "run_command"  # 执行命令
    LIST_FILES = "list_files"  # 列出文件
    GET_SYSTEM_INFO = "get_system_info"  # 获取系统信息
    NAVIGATE = "navigate"  # 导航
    OPEN_URL = "open_url"  # 打开URL
    SCREENSHOT = "screenshot"  # 截图
    CREATE_FILE = "create_file"  # 创建文件
    COPY_FILE = "copy_file"  # 复制文件
    DELETE_FILE = "delete_file"  # 删除文件
    START_APPLICATION = "start_application"  # 启动应用程序
    GET_PROCESS_LIST = "get_process_list"  # 获取进程列表
    # 新增意图类型
    SEARCH_INTERNET = "search_internet"  # 搜索互联网
    RETRIEVE_DATA = "retrieve_data"  # 检索数据
    CALL_API = "call_api"  # 调用API
    DOWNLOAD_FILE = "download_file"  # 下载文件
    ORCHESTRATE_AGENT = "orchestrate_agent"  # 编排智能体
    MANAGE_AGENT = "manage_agent"  # 管理智能体
    CONTROL_DEVICE = "control_device"  # 控制设备
    DISCOVER_DEVICE = "discover_device"  # 发现设备
    MONITOR_DEVICE = "monitor_device"  # 监控设备
    ANALYZE_HABITS = "analyze_habits"  # 分析习惯
    PREDICT_BEHAVIOR = "predict_behavior"  # 预测行为
    GET_RECOMMENDATIONS = "get_recommendations"  # 获取推荐
    CHECK_UPDATE = "check_update"  # 检查更新
    UPDATE_APPLICATION = "update_application"  # 更新应用
    GENERATE_INSTALL_PACKAGE = "generate_install_package"  # 生成安装包
    GET_INSTALL_GUIDE = "get_install_guide"  # 获取安装指南
    UNKNOWN = "unknown"  # 未知意图

# 对话上下文类
class ConversationContext:
    """对话上下文"""
    def __init__(self, max_history: int = 10):
        self.max_history = max_history
        self.history: List[Dict[str, str]] = []
    
    def add_message(self, role: str, content: str):
        """添加对话消息"""
        self.history.append({"role": role, "content": content})
        # 保持历史记录不超过最大值
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]
    
    def get_history(self) -> List[Dict[str, str]]:
        """获取对话历史"""
        return self.history
    
    def clear(self):
        """清空对话历史"""
        self.history = []

# AI模型服务类
class AIModelService:
    """AI模型服务"""
    
    def __init__(self):
        self.model_loaded = False
        self.context = ConversationContext()
        self.model_dir = os.path.join(os.path.dirname(__file__), "../models")
        self.intent_rules_file = os.path.join(self.model_dir, "intent_rules.json")
        self.intent_rules = self._load_intent_rules()
        self.initialize_model()
    
    def _load_intent_rules(self) -> Dict[str, List[str]]:
        """加载意图识别规则
        
        Returns:
            意图规则字典，键为意图类型，值为关键词列表
        """
        # 默认意图规则
        default_rules = {
            "open_file": ["打开文件"],
            "take_photo": ["拍照"],
            "run_command": ["执行命令", "运行命令"],
            "list_files": ["列出文件"],
            "get_system_info": ["系统信息"],
            "navigate": ["导航到", "打开页面", "进入"],
            "open_url": ["打开网页", "访问网站", "打开链接"],
            "screenshot": ["截图", "截屏"],
            "create_file": ["创建文件"],
            "copy_file": ["复制文件"],
            "delete_file": ["删除文件"],
            "start_application": ["启动应用", "打开应用"],
            "get_process_list": ["进程列表", "运行的程序"],
            "chat": ["你好", "hello", "hi", "在吗"],
            # 新增意图规则
            "search_internet": ["搜索", "查一下", "找一找", "上网搜索"],
            "retrieve_data": ["获取数据", "检索数据", "查询数据"],
            "call_api": ["调用API", "请求接口", "调用接口"],
            "download_file": ["下载文件", "保存文件", "下载"],
            "orchestrate_agent": ["编排智能体", "调用智能体", "指派任务"],
            "manage_agent": ["管理智能体", "注册智能体", "列出智能体"],
            "control_device": ["控制设备", "操作设备", "设备控制"],
            "discover_device": ["发现设备", "搜索设备", "查找设备"],
            "monitor_device": ["监控设备", "查看设备状态", "设备状态"],
            "analyze_habits": ["分析习惯", "我的习惯", "习惯分析"],
            "predict_behavior": ["预测行为", "行为预测", "预测"],
            "get_recommendations": ["推荐", "建议", "推荐内容"],
            "check_update": ["检查更新", "更新检查", "版本检查"],
            "update_application": ["更新应用", "应用更新", "升级"],
            "generate_install_package": ["生成安装包", "安装包", "本地安装"],
            "get_install_guide": ["安装指南", "如何安装", "安装说明"]
        }
        
        # 如果规则文件存在，则加载
        if os.path.exists(self.intent_rules_file):
            try:
                with open(self.intent_rules_file, "r", encoding="utf-8") as f:
                    loaded_rules = json.load(f)
                logger.info(f"从文件加载意图规则: {self.intent_rules_file}")
                return loaded_rules
            except Exception as e:
                logger.error(f"加载意图规则失败: {str(e)}")
                logger.info("使用默认意图规则")
        else:
            # 创建模型目录
            os.makedirs(self.model_dir, exist_ok=True)
            # 保存默认规则
            self._save_intent_rules(default_rules)
        
        return default_rules
    
    def _save_intent_rules(self, rules: Dict[str, List[str]]):
        """保存意图识别规则到文件
        
        Args:
            rules: 意图规则字典
        """
        try:
            with open(self.intent_rules_file, "w", encoding="utf-8") as f:
                json.dump(rules, f, ensure_ascii=False, indent=2)
            logger.info(f"意图规则已保存到文件: {self.intent_rules_file}")
        except Exception as e:
            logger.error(f"保存意图规则失败: {str(e)}")
    
    def update_intent_rules(self, new_rules: Dict[str, List[str]]):
        """更新意图识别规则
        
        Args:
            new_rules: 新的意图规则字典
        """
        # 合并规则，新规则覆盖旧规则
        for intent, keywords in new_rules.items():
            if intent in self.intent_rules:
                # 合并关键词，去重
                existing_keywords = self.intent_rules[intent]
                self.intent_rules[intent] = list(set(existing_keywords + keywords))
            else:
                self.intent_rules[intent] = keywords
        
        # 保存更新后的规则
        self._save_intent_rules(self.intent_rules)
        logger.info("意图规则已更新")
    
    def add_intent_keywords(self, intent: str, keywords: List[str]):
        """添加意图关键词
        
        Args:
            intent: 意图类型
            keywords: 关键词列表
        """
        if intent in self.intent_rules:
            # 去重添加
            existing_keywords = self.intent_rules[intent]
            self.intent_rules[intent] = list(set(existing_keywords + keywords))
        else:
            self.intent_rules[intent] = keywords
        
        # 保存更新后的规则
        self._save_intent_rules(self.intent_rules)
        logger.info(f"为意图 {intent} 添加了关键词: {keywords}")
    
    def initialize_model(self):
        """初始化AI模型"""
        try:
            # 这里可以加载真正的AI模型
            # 目前使用简单的规则引擎作为示例
            logger.info("AI模型服务初始化完成")
            self.model_loaded = True
        except Exception as e:
            logger.error(f"AI模型加载失败: {str(e)}")
            self.model_loaded = False
    
    def recognize_intent(self, text: str) -> IntentType:
        """识别用户意图
        
        Args:
            text: 用户输入文本
            
        Returns:
            意图类型
        """
        text_lower = text.lower()
        
        # 使用动态加载的意图规则进行匹配
        for intent_str, keywords in self.intent_rules.items():
            if any(keyword in text_lower for keyword in keywords):
                # 检查意图类型是否有效
                if intent_str in [intent.value for intent in IntentType]:
                    return IntentType(intent_str)
        
        # 如果没有匹配到任何意图，返回未知意图
        return IntentType.UNKNOWN
    
    def extract_entities(self, text: str, intent: IntentType) -> Dict[str, str]:
        """提取实体
        
        Args:
            text: 用户输入文本
            intent: 意图类型
            
        Returns:
            提取的实体
        """
        entities = {}
        
        if intent == IntentType.OPEN_FILE:
            # 提取文件路径
            if "打开文件" in text:
                file_path = text.split("打开文件")[-1].strip()
                entities["file_path"] = file_path
        elif intent == IntentType.RUN_COMMAND:
            # 提取命令
            if "执行命令" in text:
                command = text.split("执行命令")[-1].strip()
                entities["command"] = command
            elif "运行命令" in text:
                command = text.split("运行命令")[-1].strip()
                entities["command"] = command
        elif intent == IntentType.LIST_FILES:
            # 提取目录路径
            if "列出文件" in text:
                directory = text.split("列出文件")[-1].strip()
                entities["directory"] = directory if directory else "."
            else:
                entities["directory"] = "."
        elif intent == IntentType.NAVIGATE:
            # 提取导航目标
            for keyword in ["导航到", "打开页面", "进入"]:
                if keyword in text:
                    target = text.split(keyword)[-1].strip()
                    entities["target"] = target
                    break
        elif intent == IntentType.OPEN_URL:
            # 提取URL
            for keyword in ["打开网页", "访问网站", "打开链接"]:
                if keyword in text:
                    url = text.split(keyword)[-1].strip()
                    entities["url"] = url
                    break
        elif intent == IntentType.SCREENSHOT:
            # 提取保存路径（可选）
            if "保存到" in text:
                save_path = text.split("保存到")[-1].strip()
                entities["save_path"] = save_path
        elif intent == IntentType.CREATE_FILE:
            # 提取文件路径和内容
            if "创建文件" in text:
                content_part = text.split("创建文件")[-1].strip()
                if "内容是" in content_part:
                    file_path = content_part.split("内容是")[0].strip()
                    content = content_part.split("内容是")[-1].strip()
                    entities["file_path"] = file_path
                    entities["content"] = content
                else:
                    entities["file_path"] = content_part
        elif intent == IntentType.COPY_FILE:
            # 提取源文件路径和目标文件路径
            if "复制文件" in text:
                copy_part = text.split("复制文件")[-1].strip()
                if "到" in copy_part:
                    source = copy_part.split("到")[0].strip()
                    destination = copy_part.split("到")[-1].strip()
                    entities["source"] = source
                    entities["destination"] = destination
        elif intent == IntentType.DELETE_FILE:
            # 提取文件路径
            if "删除文件" in text:
                file_path = text.split("删除文件")[-1].strip()
                entities["file_path"] = file_path
        elif intent == IntentType.START_APPLICATION:
            # 提取应用程序名称
            for keyword in ["启动应用", "打开应用"]:
                if keyword in text:
                    app_name = text.split(keyword)[-1].strip()
                    entities["app_name"] = app_name
                    break
        
        return entities
    
    def generate_response(self, text: str, context: Optional[ConversationContext] = None) -> str:
        """生成AI响应
        
        Args:
            text: 用户输入文本
            context: 对话上下文
            
        Returns:
            AI生成的响应
        """
        # 如果没有提供上下文，使用默认上下文
        if not context:
            context = self.context
        
        # 添加用户消息到上下文
        context.add_message("user", text)
        
        # 识别意图
        intent = self.recognize_intent(text)
        entities = self.extract_entities(text, intent)
        
        # 生成响应
        response = self._generate_response_by_intent(text, intent, entities, context)
        
        # 添加AI响应到上下文
        context.add_message("assistant", response)
        
        return response
    
    def _generate_response_by_intent(self, text: str, intent: IntentType, entities: Dict[str, str], context: ConversationContext) -> str:
        """根据意图生成响应
        
        Args:
            text: 用户输入文本
            intent: 意图类型
            entities: 提取的实体
            context: 对话上下文
            
        Returns:
            AI生成的响应
        """
        if intent == IntentType.CHAT:
            # 普通聊天
            return self._generate_chat_response(text, context)
        elif intent == IntentType.OPEN_FILE:
            # 打开文件
            file_path = entities.get("file_path", "")
            return f"我将帮你打开文件: {file_path}"
        elif intent == IntentType.TAKE_PHOTO:
            # 拍照
            return "我将帮你调用摄像头拍照"
        elif intent == IntentType.RUN_COMMAND:
            # 执行命令
            command = entities.get("command", "")
            return f"我将帮你执行命令: {command}"
        elif intent == IntentType.LIST_FILES:
            # 列出文件
            directory = entities.get("directory", ".")
            return f"我将帮你列出目录 {directory} 中的文件"
        elif intent == IntentType.GET_SYSTEM_INFO:
            # 获取系统信息
            return "我将帮你获取系统信息"
        elif intent == IntentType.NAVIGATE:
            # 导航
            target = entities.get("target", "")
            return f"我将帮你导航到 {target}"
        elif intent == IntentType.OPEN_URL:
            # 打开URL
            url = entities.get("url", "")
            return f"我将帮你打开URL: {url}"
        elif intent == IntentType.SCREENSHOT:
            # 截图
            save_path = entities.get("save_path", "")
            if save_path:
                return f"我将帮你截图并保存到: {save_path}"
            else:
                return "我将帮你截图"
        elif intent == IntentType.CREATE_FILE:
            # 创建文件
            file_path = entities.get("file_path", "")
            return f"我将帮你创建文件: {file_path}"
        elif intent == IntentType.COPY_FILE:
            # 复制文件
            source = entities.get("source", "")
            destination = entities.get("destination", "")
            return f"我将帮你复制文件，从 {source} 到 {destination}"
        elif intent == IntentType.DELETE_FILE:
            # 删除文件
            file_path = entities.get("file_path", "")
            return f"我将帮你删除文件: {file_path}"
        elif intent == IntentType.START_APPLICATION:
            # 启动应用程序
            app_name = entities.get("app_name", "")
            return f"我将帮你启动应用程序: {app_name}"
        elif intent == IntentType.GET_PROCESS_LIST:
            # 获取进程列表
            return "我将帮你获取进程列表"
        # 新增意图响应
        elif intent == IntentType.SEARCH_INTERNET:
            # 搜索互联网
            return "我将帮你搜索互联网上的资料"
        elif intent == IntentType.RETRIEVE_DATA:
            # 检索数据
            return "我将帮你检索所需的数据"
        elif intent == IntentType.CALL_API:
            # 调用API
            return "我将帮你调用指定的API接口"
        elif intent == IntentType.DOWNLOAD_FILE:
            # 下载文件
            return "我将帮你下载指定的文件"
        elif intent == IntentType.ORCHESTRATE_AGENT:
            # 编排智能体
            return "我将帮你编排智能体完成任务"
        elif intent == IntentType.MANAGE_AGENT:
            # 管理智能体
            return "我将帮你管理智能体"
        elif intent == IntentType.CONTROL_DEVICE:
            # 控制设备
            return "我将帮你控制指定的设备"
        elif intent == IntentType.DISCOVER_DEVICE:
            # 发现设备
            return "我将帮你发现网络中的设备"
        elif intent == IntentType.MONITOR_DEVICE:
            # 监控设备
            return "我将帮你监控设备状态"
        elif intent == IntentType.ANALYZE_HABITS:
            # 分析习惯
            return "我将帮你分析使用习惯"
        elif intent == IntentType.PREDICT_BEHAVIOR:
            # 预测行为
            return "我将帮你预测可能的行为"
        elif intent == IntentType.GET_RECOMMENDATIONS:
            # 获取推荐
            return "我将根据你的习惯为你提供推荐"
        elif intent == IntentType.CHECK_UPDATE:
            # 检查更新
            return "我将帮你检查应用程序更新"
        elif intent == IntentType.UPDATE_APPLICATION:
            # 更新应用
            return "我将帮你更新应用程序"
        elif intent == IntentType.GENERATE_INSTALL_PACKAGE:
            # 生成安装包
            return "我将帮你生成本地安装包"
        elif intent == IntentType.GET_INSTALL_GUIDE:
            # 获取安装指南
            return "我将为你提供安装指南"
        else:
            # 未知意图
            return f"抱歉，我还不理解你的需求: {text}"
    
    def _generate_chat_response(self, text: str, context: ConversationContext) -> str:
        """生成聊天响应
        
        Args:
            text: 用户输入文本
            context: 对话上下文
            
        Returns:
            聊天响应
        """
        text_lower = text.lower()
        
        if any(greeting in text_lower for greeting in ["你好", "hello", "hi", "在吗"]):
            return "你好！我是你的AI助手，有什么可以帮助你的吗？"
        elif any(question in text_lower for question in ["你是谁", "你是什么"]):
            return "我是一个基于开源技术开发的AI助手，可以帮助你执行各种任务，如打开文件、拍照、执行命令等。"
        elif any(question in text_lower for question in ["你能做什么", "你的功能", "帮助"]):
            return "我可以帮助你执行以下任务：\n- 打开文件\n- 调用摄像头拍照\n- 执行系统命令\n- 列出目录中的文件\n- 获取系统信息\n- 导航到不同页面\n- 进行日常聊天"
        elif any(question in text_lower for question in ["谢谢", "感谢"]):
            return "不客气，很高兴能帮到你！"
        elif any(question in text_lower for question in ["再见", "拜拜", "再见了"]):
            return "再见！有需要随时找我。"
        else:
            return f"我理解你说的是: {text}。我正在不断学习中，会努力提高我的理解能力。"
    
    def clear_context(self):
        """清空对话上下文"""
        self.context.clear()
    
    def get_context(self) -> ConversationContext:
        """获取对话上下文
        
        Returns:
            对话上下文
        """
        return self.context


# 单例模式
aimodel_service = AIModelService()
