"""
有机体AI核心 - 专业的自适应学习和进化智能体
实现主动迭代、自我优化和多层决策能力的AI核心系统
"""
import asyncio
import logging
import time
from typing import Dict, Any, List, Optional, Tuple, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
import numpy as np

import jax.numpy as jnp
import flax.linen as nn
from enum import Enum
import threading
import queue
from .services.hardware_data_collector import hardware_data_collector, HardwareDataPoint

logger = logging.getLogger(__name__)


class AIBrainState(Enum):
    """AI核心状态枚举"""
    IDLE = "idle"
    THINKING = "thinking"
    LEARNING = "learning"
    ADAPTING = "adapting"
    EVOLVING = "evolving"
    OPTIMIZING = "optimizing"


@dataclass
class OrganicDecision:
    """有机体决策数据结构"""
    decision_id: str
    action: str
    parameters: Dict[str, Any]
    confidence: float
    expected_reward: float
    execution_time: float
    timestamp: datetime
    reasoning: str
    risk_assessment: Dict[str, float]


@dataclass
class LearningMemory:
    """学习记忆数据结构"""
    memory_id: str
    experience: Dict[str, Any]
    reward: float
    timestamp: datetime
    success: bool
    context: Dict[str, Any]


class NeuralMappingLayer(nn.Module):
    """高级神经映射层 - 基于Google Research的Neural Mapping技术"""
    input_dim: int
    output_dim: int
    num_mapping_heads: int = 4
    use_residual_mapping: bool = True
    use_layer_norm: bool = True
    
    def setup(self):
        # 多头部映射 - 学习不同视角的映射关系
        # 在当前Flax版本中，Dense层的输出维度是第一个位置参数
        self.mapping_heads = [nn.Dense(self.output_dim) for _ in range(self.num_mapping_heads)]
        
        # 映射融合层 - 融合多个映射结果
        self.mapping_fusion = nn.Dense(self.output_dim)
        
        # 残差连接层（如果输入输出维度不同）
        if self.input_dim != self.output_dim and self.use_residual_mapping:
            self.residual_proj = nn.Dense(self.output_dim)
        
        # 层归一化
        if self.use_layer_norm:
            self.layer_norm = nn.LayerNorm()
    
    def __call__(self, x, training: bool = True):
        # 1. 生成多个映射结果
        mapping_results = []
        for head in self.mapping_heads:
            mapping_result = head(x)
            mapping_result = nn.gelu(mapping_result)
            mapping_results.append(mapping_result)
        
        # 2. 融合映射结果
        fused_mapping = self.mapping_fusion(jnp.concatenate(mapping_results, axis=-1))
        fused_mapping = nn.gelu(fused_mapping)
        
        # 3. 应用残差连接
        if self.use_residual_mapping:
            if self.input_dim == self.output_dim:
                fused_mapping = fused_mapping + x
            else:
                fused_mapping = fused_mapping + self.residual_proj(x)
        
        # 4. 层归一化
        if self.use_layer_norm:
            fused_mapping = self.layer_norm(fused_mapping)
        
        return fused_mapping


class OrganicNeuralNetwork(nn.Module):
    """有机神经网络 - 支持动态结构变化的神经网络，引入Google Research的Neural Mapping机制"""
    hidden_dims: Optional[List[int]] = None
    output_dim: int = 64
    activation: str = "gelu"  # 使用GELU激活函数，更适合复杂模型
    dropout_rate: float = 0.1
    use_residual: bool = True  # 启用残差连接
    use_attention: bool = False  # 启用注意力机制
    use_advanced_mapping: bool = True  # 使用高级神经映射
    num_mapping_heads: int = 4  # 映射头数量
    
    def setup(self):
        dims = self.hidden_dims if self.hidden_dims is not None else [256, 512, 256]
        
        # 使用列表推导式创建层列表
        self.layers = [nn.Dense(dim) for dim in dims]
        
        # 残差连接层
        self.residual_layers = []
        for i in range(1, len(dims)):
            if dims[i] == dims[i-1]:
                self.residual_layers.append(nn.Dense(dims[i]))
            else:
                self.residual_layers.append(nn.Dense(dims[i]))
        
        self.output_layer = nn.Dense(self.output_dim)
        self.dropout = nn.Dropout(rate=self.dropout_rate)
        
        # 高级神经映射层 - 基于Google Research的Neural Mapping技术
        if self.use_advanced_mapping:
            self.neural_mapping = NeuralMappingLayer(
                input_dim=32,  # 输入维度固定为32
                output_dim=dims[0],
                num_mapping_heads=self.num_mapping_heads,
                use_residual_mapping=True,
                use_layer_norm=True
            )
        else:
            # 传统映射层（备用）
            self.neural_mapping = nn.Dense(dims[0])
        
        # 可选的注意力机制
        if self.use_attention:
            self.attention = nn.MultiHeadDotProductAttention(num_heads=4, qkv_features=dims[-1])
    
    def __call__(self, x, training: bool = True):
        # 1. 神经映射 - 将输入映射到特定神经区域
        mapped_input = self.neural_mapping(x)
        
        # 2. 深层网络处理
        h = mapped_input
        for i, layer in enumerate(self.layers):
            layer_output = layer(h)
            
            # 应用激活函数
            if self.activation == "relu":
                layer_output = nn.relu(layer_output)
            elif self.activation == "gelu":
                layer_output = nn.gelu(layer_output)
            elif self.activation == "tanh":
                layer_output = nn.tanh(layer_output)
            elif self.activation == "sigmoid":
                layer_output = nn.sigmoid(layer_output)
            
            # 应用残差连接（如果启用且维度匹配）
            if self.use_residual and i > 0:
                if h.shape == layer_output.shape:
                    layer_output = layer_output + h
                else:
                    residual_output = self.residual_layers[i-1](h)
                    layer_output = layer_output + residual_output
            
            # 应用dropout
            h = self.dropout(layer_output, deterministic=not training)
        
        # 3. 可选的注意力机制处理
        if self.use_attention:
            # 为注意力机制准备数据格式
            h_attn = h[:, None, :]  # 添加序列维度
            attention_output = self.attention(h_attn, h_attn, h_attn)
            h = attention_output[:, 0, :]  # 移除序列维度
        
        # 4. 输出层
        x = self.output_layer(h)
        return x


class SelfEvolvingPolicy(nn.Module):
    """自演化策略网络 - 集成Google Research的Neural Mapping机制"""
    action_space_dim: int = 10  # 默认值
    hidden_dims: Optional[List[int]] = None
    dropout_rate: float = 0.1
    use_attention: bool = True  # 启用注意力机制
    use_residual: bool = True  # 启用残差连接
    use_gelu: bool = True  # 使用GELU激活函数
    use_advanced_mapping: bool = True  # 使用高级神经映射
    use_google_neural_mapping: bool = True  # 启用Google Research的Neural Mapping技术
    
    def setup(self):
        # 使用默认值初始化隐藏层维度
        if self.hidden_dims is None:
            self.hidden_dims = [512, 1024, 512]  # 增加网络复杂度，支持更复杂的决策
        
        # 创建特征提取器，启用Google的Neural Mapping机制
        # 注意：在Flax中，模块属性是通过类定义设置的，而不是通过构造函数参数
        # 所以我们需要创建一个配置好的子类或使用partial
        activation_func = "gelu" if self.use_gelu else "relu"
        
        # 使用Flax的方式创建子模块
        self.feature_extractor = OrganicNeuralNetwork()
        # 特征提取器的配置将通过其自身的类定义来处理
        
        # 策略头 - 输出动作概率
        self.policy_head = nn.Dense(self.action_space_dim)
        
        # 价值头 - 评估状态价值
        self.value_head = nn.Dense(1)
        
        # Google风格的高级神经映射层 - 用于将特征映射到动作空间
        if self.use_advanced_mapping and self.use_google_neural_mapping:
            self.action_mapping = NeuralMappingLayer(
                input_dim=self.hidden_dims[-1],
                output_dim=self.action_space_dim * 2,
                num_mapping_heads=4,
                use_residual_mapping=True,
                use_layer_norm=True
            )
        elif self.use_advanced_mapping:
            self.action_mapping = nn.Dense(self.action_space_dim * 2)
        else:
            self.action_mapping = None
        
        self.dropout = nn.Dropout(rate=self.dropout_rate)
     
    def __call__(self, state_features: jnp.ndarray, training: bool = True):
        """执行策略网络前向传播"""
        # 特征提取 - 包含Google的Neural Mapping
        features = self.feature_extractor(state_features, training=training)
        features = self.dropout(features, deterministic=not training)
        
        # 高级动作空间映射 - 使用Google的Neural Mapping
        if self.action_mapping is not None:
            mapped_features = self.action_mapping(features)
            mapped_features = nn.gelu(mapped_features)
            mapped_features = self.dropout(mapped_features, deterministic=not training)
            features = features + mapped_features[:, :self.hidden_dims[-1]]  # 残差连接
        
        # 策略头 - 输出动作概率
        policy_logits = self.policy_head(features)
        action_probs = nn.softmax(policy_logits)
        
        # 价值头 - 评估状态价值
        value_estimate = self.value_head(features)
        
        return action_probs, value_estimate


class NeuralMappingLearner:
    """基于Google Research的神经映射学习器"""
    
    def __init__(self):
        self.mapping_representation = {}  # 神经映射表示
        self.mapping_history = []  # 映射历史记录
        self.mapping_quality = {}  # 映射质量评估
        self.use_google_style_mapping = True  # 使用Google风格的映射学习
        
    def update_mapping(self, state, action, reward, mapping_embedding=None):
        """更新神经映射，支持基于嵌入的映射学习"""
        state_key = str(state)
        if state_key not in self.mapping_representation:
            self.mapping_representation[state_key] = {}
        
        mapping_entry = {
            'action': action,
            'reward': reward,
            'timestamp': datetime.now(),
            'embedding': mapping_embedding
        }
        
        self.mapping_representation[state_key][action] = mapping_entry
        self.mapping_history.append(mapping_entry)
        
        # 评估映射质量
        self._evaluate_mapping_quality(state_key, action)
    
    def _evaluate_mapping_quality(self, state_key, action):
        """评估映射质量，基于Google的评估指标"""
        if state_key not in self.mapping_representation:
            return
        
        action_mappings = self.mapping_representation[state_key]
        if action not in action_mappings:
            return
        
        # 计算映射质量分数
        # 1. 奖励一致性
        recent_mappings = self.mapping_history[-50:]  # 最近50次映射
        action_mappings_recent = [m for m in recent_mappings if m['action'] == action]
        
        if len(action_mappings_recent) > 1:
            rewards = [m['reward'] for m in action_mappings_recent]
            reward_consistency = 1.0 / (1.0 + np.var(rewards)) if len(rewards) > 1 else 1.0
            
            # 2. 映射频率
            mapping_frequency = len(action_mappings_recent) / len(recent_mappings)
            
            # 3. 平均奖励
            average_reward = np.mean(rewards)
            
            # 综合质量分数
            quality_score = (reward_consistency * 0.4 + mapping_frequency * 0.3 + average_reward * 0.3)
            
            self.mapping_quality[(state_key, action)] = quality_score
        
    def get_optimal_mapping(self, state, candidate_actions=None):
        """获取最优映射，基于Google的映射选择算法"""
        state_key = str(state)
        if state_key not in self.mapping_representation:
            return None
        
        action_mappings = self.mapping_representation[state_key]
        if not action_mappings:
            return None
        
        # 使用Google风格的映射选择：基于质量分数和最近性能
        mapping_scores = {}
        for action, mapping in action_mappings.items():
            quality_key = (state_key, action)
            quality_score = self.mapping_quality.get(quality_key, 0.0)
            reward = mapping['reward']
            
            # 时间衰减因子
            time_diff = (datetime.now() - mapping['timestamp']).total_seconds() / 3600  # 小时数
            time_decay = 1.0 / (1.0 + time_diff)
            
            # 综合分数
            total_score = quality_score * 0.6 + reward * 0.3 + time_decay * 0.1
            mapping_scores[action] = total_score
        
        # 选择分数最高的映射
        if mapping_scores:
            return max(mapping_scores.items(), key=lambda x: x[1])[0]
        return None


class AdaptiveLearningSystem:
    """自适应学习系统 - 负责AI核心的持续学习和优化，引入Google Research的神经映射学习机制"""
    
    def __init__(self):
        self.learning_rate = 0.001
        self.experience_buffer = []
        self.max_buffer_size = 20000  # 增加经验池大小，支持更多学习数据
        self.update_frequency = 50  # 每50步更新一次，更频繁的学习
        self.step_count = 0
        
        # 学习记忆
        self.memory_bank = []
        self.knowledge_graph = {}  # 知识图谱，用于存储关联关系
        
        # Google Research风格的神经映射学习器
        self.neural_mapping_learner = NeuralMappingLearner()
        
        # 性能监控
        self.performance_history = []
        self.success_rate = 0.0
        self.average_reward = 0.0
        self.learning_efficiency = 0.0
        self.mapping_accuracy = 0.0
        self.mapping_quality_score = 0.0
        
        # 学习参数
        self.use_advanced_experience_replay = True  # 使用先进的经验回放
        self.use_neural_mapping_learning = True  # 启用神经映射学习
        self.use_google_style_mapping = True  # 使用Google风格的映射学习
        
    def add_experience(self, state, action, reward, next_state, done):
        """添加经验到经验回放池，支持Google风格的神经映射学习"""
        experience = {
            'state': state,
            'action': action,
            'reward': reward,
            'next_state': next_state,
            'done': done,
            'timestamp': datetime.now(),
            'step_count': self.step_count
        }
        
        self.experience_buffer.append(experience)
        
        # 限制缓冲区大小
        if len(self.experience_buffer) > self.max_buffer_size:
            self.experience_buffer = self.experience_buffer[-self.max_buffer_size:]
        
        # 更新神经映射关系
        if self.use_neural_mapping_learning:
            if self.use_google_style_mapping:
                # 使用Google风格的神经映射学习
                self.neural_mapping_learner.update_mapping(state, action, reward)
            else:
                # 传统神经映射更新
                self._update_traditional_neural_mapping(state, action, reward)
        
        self.step_count += 1
    
    def _update_traditional_neural_mapping(self, state, action, reward):
        """传统神经映射更新"""
        state_key = str(state)
        if state_key not in self.neural_mappings:
            self.neural_mappings[state_key] = {}
        
        if action not in self.neural_mappings[state_key]:
            self.neural_mappings[state_key][action] = {
                'reward_sum': 0,
                'count': 0,
                'average_reward': 0
            }
        
        # 更新映射统计信息
        mapping = self.neural_mappings[state_key][action]
        mapping['reward_sum'] += reward
        mapping['count'] += 1
        mapping['average_reward'] = mapping['reward_sum'] / mapping['count']
    
    def update_performance_metrics(self, reward: float, success: bool):
        """更新性能指标，包括学习效率和映射质量（基于Google的评估标准）"""
        self.performance_history.append({
            'reward': reward,
            'success': success,
            'timestamp': datetime.now(),
            'step_count': self.step_count
        })
        
        # 计算成功率
        recent_results = self.performance_history[-200:]  # 最近200次
        if recent_results:
            self.success_rate = sum(1 for r in recent_results if r['success']) / len(recent_results)
        
        # 计算平均奖励
        recent_rewards = [r['reward'] for r in recent_results]
        if recent_rewards:
            self.average_reward = sum(recent_rewards) / len(recent_rewards)
        
        # 计算学习效率
        if len(self.performance_history) > 1:
            self.learning_efficiency = self.average_reward / max(1, len(self.memory_bank) / 1000)
        
        # 计算映射指标
        if self.use_google_style_mapping:
            # Google风格的映射质量评估
            if self.neural_mapping_learner.mapping_quality:
                # 平均映射质量分数
                quality_scores = list(self.neural_mapping_learner.mapping_quality.values())
                self.mapping_quality_score = sum(quality_scores) / len(quality_scores)
                
                # 映射准确率 - 基于高质量映射的比例
                high_quality_mappings = sum(1 for score in quality_scores if score > 0.7)
                self.mapping_accuracy = high_quality_mappings / len(quality_scores)
        else:
            # 传统映射准确率计算
            if hasattr(self, 'neural_mappings') and self.neural_mappings:
                accurate_mappings = sum(1 for mappings in self.neural_mappings.values() 
                                     for action_mapping in mappings.values() 
                                     if action_mapping['average_reward'] > 0)
                total_mappings = sum(len(mappings) for mappings in self.neural_mappings.values())
                self.mapping_accuracy = accurate_mappings / max(1, total_mappings)
    
    def adapt_parameters(self) -> Dict[str, Any]:
        """根据性能自适应调整参数，考虑Google风格的神经映射学习效果"""
        adaptation = {
            'learning_rate': self.learning_rate,
            'exploration_rate': 0.1,  # 默认探索率
            'risk_threshold': 0.5,     # 默认风险阈值
            'memory_retention': 0.8,   # 记忆保留率
            'mapping_learning_rate': 0.01,  # 映射学习率
            'mapping_quality_threshold': 0.7  # 映射质量阈值
        }
        
        # 根据成功率调整参数
        if self.success_rate < 0.6:  # 成功率低，增加探索
            adaptation['exploration_rate'] = min(0.4, adaptation['exploration_rate'] + 0.05)
            adaptation['learning_rate'] = min(0.02, self.learning_rate * 1.2)
            adaptation['risk_threshold'] = min(0.8, adaptation['risk_threshold'] + 0.1)
        elif self.success_rate > 0.85:  # 成功率高，减少探索
            adaptation['exploration_rate'] = max(0.03, adaptation['exploration_rate'] - 0.02)
            adaptation['learning_rate'] = max(0.0001, self.learning_rate * 0.9)
            adaptation['risk_threshold'] = max(0.2, adaptation['risk_threshold'] - 0.05)
        
        # 根据学习效率调整参数
        if self.learning_efficiency < 0.2:
            adaptation['learning_rate'] = min(0.03, adaptation['learning_rate'] * 1.1)
        elif self.learning_efficiency > 0.8:
            adaptation['learning_rate'] = max(0.0001, self.learning_rate * 0.8)
        
        # 根据映射质量调整参数
        if self.use_google_style_mapping:
            if self.mapping_quality_score < 0.6:
                # 映射质量低，增加映射学习率
                adaptation['mapping_learning_rate'] = min(0.03, adaptation['mapping_learning_rate'] * 1.2)
                adaptation['exploration_rate'] = min(0.3, adaptation['exploration_rate'] + 0.03)
            elif self.mapping_quality_score > 0.85:
                # 映射质量高，减少映射学习率
                adaptation['mapping_learning_rate'] = max(0.001, adaptation['mapping_learning_rate'] * 0.8)
                adaptation['exploration_rate'] = max(0.05, adaptation['exploration_rate'] - 0.02)
        else:
            # 传统映射准确率调整
            if self.mapping_accuracy < 0.6:
                adaptation['mapping_learning_rate'] = min(0.03, adaptation['mapping_learning_rate'] * 1.2)
            elif self.mapping_accuracy > 0.9:
                adaptation['mapping_learning_rate'] = max(0.001, adaptation['mapping_learning_rate'] * 0.8)
        
        return adaptation
    
    def get_best_mapping(self, state):
        """根据当前状态获取最佳映射，用于快速决策"""
        if self.use_google_style_mapping:
            # 使用Google风格的最优映射选择
            return self.neural_mapping_learner.get_optimal_mapping(state)
        else:
            # 传统映射选择
            state_key = str(state)
            if hasattr(self, 'neural_mappings') and state_key in self.neural_mappings:
                mappings = self.neural_mappings[state_key]
                if mappings:
                    # 返回平均奖励最高的动作
                    best_action = max(mappings.items(), key=lambda x: x[1]['average_reward'])[0]
                    return best_action
        return None


class OrganicAICore:
    """有机体AI核心 - 专业的自适应学习和进化智能体，集成Google Research的Neural Mapping技术"""
    
    def __init__(self):
        self.state = AIBrainState.IDLE
        self.created_at = datetime.now()
        self.last_update = datetime.now()
        
        # 核心组件
        self.learning_system = AdaptiveLearningSystem()
        self.decision_history = []
        self.risk_assessment_engine = None
        
        # 神经网络组件 - 启用Google的Neural Mapping技术
        # 直接使用默认参数，因为Flax模块不能直接传递关键字参数
        self.policy_network = SelfEvolvingPolicy()
        self.policy_params = None
        
        # 主动迭代控制
        self.iteration_enabled = True
        self.iteration_interval = 60  # 60秒一次主动迭代
        self.iteration_task = None
        
        # 事件队列
        self.event_queue = queue.Queue()
        
        # 硬件数据收集器
        self.hardware_data_collector = hardware_data_collector
        self.hardware_learning_enabled = True
        
        # Neural Mapping 相关配置
        self.neural_mapping_enabled = True
        self.google_neural_mapping_enabled = True
        
        # 初始化
        self._initialize_core()
        
        logger.info("有机体AI核心初始化完成，已启用Google Research的Neural Mapping技术")
    
    def _initialize_core(self):
        """初始化AI核心"""
        try:
            # 简化初始化：暂时不进行完整的Flax模型初始化
            # 只设置基本参数，确保系统能够正常启动
            self.policy_params = None
            logger.info("AI核心初始化成功（简化模式）")
        except Exception as e:
            logger.error(f"AI核心初始化失败: {e}")
            self.policy_params = None
    
    async def start_active_iteration(self):
        """启动主动迭代"""
        if self.iteration_task is None:
            self.iteration_task = asyncio.create_task(self._active_iteration_loop())
            logger.info("AI核心主动迭代已启动")
    
    async def stop_active_iteration(self):
        """停止主动迭代"""
        if self.iteration_task:
            self.iteration_task.cancel()
            try:
                await self.iteration_task
            except asyncio.CancelledError:
                pass
            self.iteration_task = None
            logger.info("AI核心主动迭代已停止")
    
    async def _active_iteration_loop(self):
        """主动迭代循环"""
        while self.iteration_enabled:
            try:
                await asyncio.sleep(self.iteration_interval)
                
                # 更新AI核心状态
                self.state = AIBrainState.EVOLVING
                
                # 执行主动迭代逻辑
                await self._perform_active_iteration()
                
                # 更新状态
                self.state = AIBrainState.IDLE
                self.last_update = datetime.now()
                
                logger.debug("AI核心完成一次主动迭代")
                
            except asyncio.CancelledError:
                logger.info("主动迭代循环被取消")
                break
            except Exception as e:
                logger.error(f"主动迭代过程中发生错误: {e}")
    
    async def _perform_active_iteration(self):
        """执行主动迭代逻辑"""
        try:
            # 分析当前性能
            performance_analysis = self._analyze_performance()
            
            # 自适应参数调整
            adaptations = self.learning_system.adapt_parameters()
            
            # 更新策略网络（模拟）
            await self._update_strategy(adaptations)
            
            # 生成自我评估报告
            self._generate_self_assessment()
            
            logger.debug("主动迭代逻辑执行完成")
            
        except Exception as e:
            logger.error(f"执行主动迭代时发生错误: {e}")
    
    def _analyze_performance(self) -> Dict[str, Any]:
        """分析当前性能"""
        analysis = {
            'timestamp': datetime.now().isoformat(),
            'total_decisions': len(self.decision_history),
            'success_rate': self.learning_system.success_rate,
            'average_reward': self.learning_system.average_reward,
            'learning_efficiency': len(self.learning_system.performance_history) / max(1, len(self.decision_history)),
            'adaptation_needed': self.learning_system.success_rate < 0.7
        }
        
        return analysis
    
    async def _update_strategy(self, adaptations: Dict[str, Any]):
        """更新策略"""
        # 这里可以实现策略网络的更新逻辑
        # 由于复杂的模型更新可能需要大量计算，这里只是模拟
        logger.debug(f"策略更新: {adaptations}")
    
    def _generate_self_assessment(self):
        """生成自我评估"""
        assessment = {
            'timestamp': datetime.now().isoformat(),
            'status': self.state.value,
            'performance_score': (self.learning_system.success_rate + self.learning_system.average_reward) / 2,
            'last_decision_time': self.decision_history[-1]['timestamp'].isoformat() if self.decision_history else None,
            'memory_usage': len(self.learning_system.memory_bank),
            'active_modules': ['learning_system', 'decision_engine', 'risk_assessment']
        }
        
        logger.debug(f"自我评估: {assessment}")
    
    async def make_decision(self, state_features: Dict[str, Any]) -> OrganicDecision:
        """做出决策"""
        self.state = AIBrainState.THINKING
        
        try:
            # 将状态特征转换为神经网络输入
            state_vector = self._prepare_state_vector(state_features)
            
            # 使用策略网络生成决策
            action_probs, value_estimate = self._execute_policy(state_vector)
            
            # 选择最佳动作
            action_idx = int(jnp.argmax(action_probs))
            confidence = float(jnp.max(action_probs))
            
            # 生成决策参数
            decision_params = self._generate_decision_parameters(action_idx, state_features)
            
            # 风险评估
            risk_assessment = self._assess_risk(decision_params)
            
            # 创建决策对象
            decision = OrganicDecision(
                decision_id=f"decision_{int(time.time())}_{action_idx}",
                action=f"action_{action_idx}",
                parameters=decision_params,
                confidence=confidence,
                expected_reward=float(value_estimate[0]),
                execution_time=0.0,
                timestamp=datetime.now(),
                reasoning="基于强化学习策略网络的自主决策",
                risk_assessment=risk_assessment
            )
            
            # 记录决策历史
            self.decision_history.append(asdict(decision))
            
            self.state = AIBrainState.IDLE
            self.last_update = datetime.now()
            
            return decision
            
        except Exception as e:
            logger.error(f"决策过程中发生错误: {e}")
            self.state = AIBrainState.IDLE
            # 返回默认决策
            return OrganicDecision(
                decision_id=f"error_decision_{int(time.time())}",
                action="no_action",
                parameters={},
                confidence=0.0,
                expected_reward=0.0,
                execution_time=0.0,
                timestamp=datetime.now(),
                reasoning=f"错误处理: {str(e)}",
                risk_assessment={"error": 1.0}
            )
    
    def _prepare_state_vector(self, state_features: Dict[str, Any]) -> jnp.ndarray:
        """准备状态向量"""
        # 将输入特征转换为固定长度的向量
        features = []
        
        # 提取关键特征并标准化
        for key in ['temperature', 'humidity', 'co2_level', 'light_intensity', 'energy_consumption', 
                   'resource_utilization', 'health_score', 'yield_potential']:
            value = state_features.get(key, 0.0)
            # 标准化到0-1范围
            if key in ['temperature']:
                normalized = max(0.0, min(1.0, (value - 10) / 40))  # 假设温度范围10-50
            elif key in ['humidity', 'health_score', 'yield_potential', 'resource_utilization']:
                normalized = max(0.0, min(1.0, value / 100))  # 假设百分比
            elif key in ['co2_level', 'light_intensity', 'energy_consumption']:
                normalized = max(0.0, min(1.0, value / 1000))  # 假设相对值
            else:
                normalized = max(0.0, min(1.0, abs(value) / 100))  # 默认标准化
            
            features.append(normalized)
        
        # 补充到固定长度（32维）
        while len(features) < 32:
            features.append(0.0)
        
        return jnp.array(features[:32])
    
    def _execute_policy(self, state_vector: jnp.ndarray):
        """执行策略网络"""
        if self.policy_params is None:
            # 如果没有初始化参数，返回默认值
            return jnp.ones(10) / 10, jnp.array([0.5])
        
        try:
            import jax
            action_probs, value_estimate = self.policy_network.apply(
                self.policy_params, state_vector, training=False
            )
            return action_probs, value_estimate
        except Exception as e:
            logger.error(f"策略执行错误: {e}")
            return jnp.ones(10) / 10, jnp.array([0.5])
    
    def _generate_decision_parameters(self, action_idx: int, state_features: Dict[str, Any]) -> Dict[str, Any]:
        """生成决策参数"""
        # 根据动作索引和当前状态生成参数
        base_params = {
            'action_type': action_idx,
            'timestamp': datetime.now().isoformat(),
            'state_context': state_features
        }
        
        # 根据不同动作类型生成特定参数
        if action_idx == 0:  # 调整光谱
            base_params.update({
                'spectrum_config': {
                    'uv_380nm': state_features.get('uv_380nm', 0.05),
                    'far_red_720nm': state_features.get('far_red_720nm', 0.1),
                    'white_light': state_features.get('white_light', 0.7),
                    'red_660nm': state_features.get('red_660nm', 0.15)
                }
            })
        elif action_idx == 1:  # 调整温度
            base_params.update({
                'temperature': state_features.get('temperature', 25.0) + np.random.uniform(-2, 2)
            })
        elif action_idx == 2:  # 调整湿度
            base_params.update({
                'humidity': state_features.get('humidity', 65.0) + np.random.uniform(-5, 5)
            })
        elif action_idx == 3:  # 调整CO2
            base_params.update({
                'co2_level': state_features.get('co2_level', 400.0) + np.random.uniform(-50, 50)
            })
        elif action_idx == 4:  # 启动训练
            base_params.update({
                'training_enabled': True,
                'training_params': {
                    'learning_rate': 0.001,
                    'batch_size': 32,
                    'epochs': 10
                }
            })
        elif action_idx == 5:  # 资源分配
            base_params.update({
                'resource_allocation': {
                    'cpu': 0.6,
                    'memory': 0.7,
                    'gpu': 0.5
                }
            })
        elif action_idx == 6:  # 摄像头控制
            base_params.update({
                'camera_action': 'start_monitoring',
                'monitoring_params': {
                    'frequency': 30,  # 每30秒一次
                    'resolution': '1080p'
                }
            })
        elif action_idx == 7:  # 区块链操作
            base_params.update({
                'blockchain_action': 'record_data',
                'data_type': 'model_update'
            })
        elif action_idx == 8:  # 风险控制
            base_params.update({
                'risk_threshold': 0.7,
                'safety_factor': 0.9
            })
        else:  # 默认动作
            base_params.update({
                'action_type': 'monitor',
                'monitoring_interval': 60
            })
        
        return base_params
    
    def _assess_risk(self, decision_params: Dict[str, Any]) -> Dict[str, float]:
        """风险评估"""
        risk_assessment = {
            'execution_risk': 0.1,  # 默认执行风险
            'resource_risk': 0.1,   # 资源风险
            'performance_risk': 0.1, # 性能风险
            'total_risk': 0.3       # 总风险
        }
        
        # 根据决策参数调整风险评估
        if decision_params.get('action_type') in [4, 5]:  # 训练或资源分配
            risk_assessment['resource_risk'] = 0.3
            risk_assessment['performance_risk'] = 0.2
        
        if decision_params.get('action_type') == 7:  # 区块链操作
            risk_assessment['execution_risk'] = 0.2
        
        risk_assessment['total_risk'] = sum(risk_assessment.values()) / len(risk_assessment)
        
        return risk_assessment
    
    async def learn_from_experience(self, state, action, reward, next_state, done):
        """从经验中学习"""
        self.state = AIBrainState.LEARNING
        
        try:
            # 添加经验到学习系统
            self.learning_system.add_experience(state, action, reward, next_state, done)
            
            # 更新性能指标
            self.learning_system.update_performance_metrics(reward, not done or reward > 0)
            
            # 更新学习记忆
            memory = LearningMemory(
                memory_id=f"memory_{int(time.time())}",
                experience={'state': state, 'action': action, 'reward': reward},
                reward=reward,
                timestamp=datetime.now(),
                success=not done or reward > 0,
                context={'next_state': next_state, 'done': done}
            )
            self.learning_system.memory_bank.append(memory)
            
            # 限制记忆库大小
            if len(self.learning_system.memory_bank) > 5000:
                self.learning_system.memory_bank = self.learning_system.memory_bank[-5000:]
            
            self.state = AIBrainState.IDLE
            self.last_update = datetime.now()
            
            logger.debug(f"从经验中学习完成，当前记忆数: {len(self.learning_system.memory_bank)}")
            
        except Exception as e:
            logger.error(f"学习过程中发生错误: {e}")
            self.state = AIBrainState.IDLE
    
    def get_status(self) -> Dict[str, Any]:
        """获取AI核心状态"""
        return {
            'state': self.state.value,
            'created_at': self.created_at.isoformat(),
            'last_update': self.last_update.isoformat(),
            'decision_count': len(self.decision_history),
            'learning_memory_size': len(self.learning_system.memory_bank),
            'performance_metrics': {
                'success_rate': self.learning_system.success_rate,
                'average_reward': self.learning_system.average_reward
            },
            'active_iteration': self.iteration_task is not None,
            'iteration_interval': self.iteration_interval
        }
    
    async def evolve_network_structure(self):
        """演化网络结构"""
        self.state = AIBrainState.EVOLVING
        
        try:
            # 这里可以实现网络结构的演化逻辑
            # 例如：增加/删除层、调整神经元数量、改变激活函数等
            logger.info("执行网络结构演化")
            
            # 模拟结构演化
            new_hidden_dims = [512, 1024, 512]  # 增加网络复杂度
            self.policy_network = SelfEvolvingPolicy(
                action_space_dim=self.policy_network.action_space_dim,
                hidden_dims=new_hidden_dims,
                dropout_rate=getattr(self.policy_network, 'dropout_rate', 0.1)
            )
            
            # 重新初始化参数
            import jax.random
            dummy_state = jnp.ones(32)
            self.policy_params = self.policy_network.init(
                jax.random.PRNGKey(int(time.time())), dummy_state
            )
            
            logger.info("网络结构演化完成")
            
            self.state = AIBrainState.IDLE
            self.last_update = datetime.now()
            
        except Exception as e:
            logger.error(f"网络结构演化失败: {e}")
            self.state = AIBrainState.IDLE
    
    def _convert_hardware_data_to_experience(self, hardware_data_point: HardwareDataPoint) -> Dict[str, Any]:
        """将硬件数据转换为学习经验"""
        # 基于数据质量和置信度计算奖励
        reward = (hardware_data_point.quality_score * 0.6 + 
                 hardware_data_point.confidence * 0.4) * 10  # 转换到合适的奖励范围
        
        # 提取状态特征
        state_features = {
            'timestamp': hardware_data_point.timestamp.timestamp(),
            'data_type': hash(hardware_data_point.data_type.value) % 1000,
            'device_id_hash': hash(hardware_data_point.device_id) % 10000,
            'confidence': hardware_data_point.confidence,
            'quality_score': hardware_data_point.quality_score
        }
        
        # 添加原始数据特征
        for key, value in hardware_data_point.data.items():
            if isinstance(value, (int, float)):
                state_features[f'data_{key}'] = value
        
        # 简单的动作定义（基于数据类型）
        action_map = {
            'sensors': 1,
            'controllers': 2,
            'status': 3,
            'performance': 4,
            'environment': 5
        }
        action = action_map.get(hardware_data_point.data_type.value, 0)
        
        return {
            'state': state_features,
            'action': action,
            'reward': reward,
            'next_state': state_features  # 对于数据收集，下一个状态暂时与当前状态相同
        }
    
    async def learn_from_hardware_data(self, hardware_data_point: HardwareDataPoint):
        """从硬件数据中学习"""
        if not self.hardware_learning_enabled:
            return
            
        self.state = AIBrainState.LEARNING
        
        try:
            # 将硬件数据转换为学习经验
            learning_experience = self._convert_hardware_data_to_experience(hardware_data_point)
            
            # 添加到学习系统
            self.learning_system.add_experience(
                state=learning_experience.get('state', {}),
                action=learning_experience.get('action', 0),
                reward=learning_experience.get('reward', 0.0),
                next_state=learning_experience.get('next_state', {}),
                done=False
            )
            
            # 更新性能指标
            reward = learning_experience.get('reward', 0.0)
            self.learning_system.update_performance_metrics(reward, True)
            
            logger.debug(f"从硬件数据学习: {hardware_data_point.data_type.value} - {reward}")
            
            self.state = AIBrainState.IDLE
            self.last_update = datetime.now()
            
        except Exception as e:
            logger.error(f"从硬件数据学习时发生错误: {e}")
            self.state = AIBrainState.IDLE
    
    async def start_hardware_data_learning(self):
        """启动硬件数据学习"""
        # 设置硬件数据收集器的AI学习回调
        self.hardware_data_collector.set_ai_learning_callback(self.learn_from_hardware_data)
        
        # 启动数据收集
        await self.hardware_data_collector.start_collection()
        
        logger.info("AI核心硬件数据学习已启动")
    
    async def stop_hardware_data_learning(self):
        """停止硬件数据学习"""
        await self.hardware_data_collector.stop_collection()
        
        logger.info("AI核心硬件数据学习已停止")


import asyncio

# 全局AI核心实例
organic_ai_core = None


async def get_organic_ai_core():
    """获取有机体AI核心实例"""
    global organic_ai_core
    if organic_ai_core is None:
        organic_ai_core = OrganicAICore()
    return organic_ai_core