"""
农业AI核心模型 - 光谱分析、植物生长模型、光配方系统
"""

from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import json
import os


@dataclass
class SpectrumConfig:
    """光谱配置"""
    uv_380nm: float = 0.05  # 380nm紫外线强度
    far_red_720nm: float = 0.1  # 720nm远红外线强度
    white_light: float = 0.7  # 白光强度 (420-450nm, 18000K)
    red_660nm: float = 0.15  # 660nm红光强度
    
    @property
    def white_red_ratio(self) -> float:
        """白红配比"""
        return self.white_light / self.red_660nm if self.red_660nm > 0 else 0


@dataclass
class PlantGrowthStage:
    """植物生长阶段"""
    stage_name: str  # 阶段名称
    duration_days: int  # 持续时间(天)
    optimal_temperature: Tuple[float, float]  # 最佳温度范围
    optimal_humidity: Tuple[float, float]  # 最佳湿度范围
    light_hours: int  # 光照时长(小时)


@dataclass
class CropConfig:
    """作物配置"""
    crop_name: str  # 作物名称
    growth_stages: List[PlantGrowthStage]  # 生长阶段
    target_yield: str  # 目标产量类型
    quality_metrics: Dict[str, float]  # 质量指标


class SpectrumAnalyzer:
    """光谱分析器 - 简化实现，移除JAX/Flax依赖"""
    
    def analyze(self, spectrum_data: List[float]) -> Dict[str, float]:
        """分析光谱数据"""
        # 光谱特征提取
        uv_intensity = sum(spectrum_data[370:390]) / len(spectrum_data[370:390]) if spectrum_data[370:390] else 0  # 380nm附近
        far_red_intensity = sum(spectrum_data[710:730]) / len(spectrum_data[710:730]) if spectrum_data[710:730] else 0  # 720nm附近
        white_intensity = sum(spectrum_data[420:450]) / len(spectrum_data[420:450]) if spectrum_data[420:450] else 0  # 白光区域
        red_intensity = sum(spectrum_data[650:670]) / len(spectrum_data[650:670]) if spectrum_data[650:670] else 0  # 红光区域
        
        return {
            'uv_380nm': uv_intensity,
            'far_red_720nm': far_red_intensity,
            'white_light': white_intensity,
            'red_660nm': red_intensity,
            'white_red_ratio': white_intensity / red_intensity if red_intensity > 0 else 0
        }


class PlantGrowthModel:
    """植物生长模型 - 简化实现，移除JAX/Flax依赖"""
    
    def predict(self, 
                environmental_data: List[float],
                spectrum_data: List[float],
                growth_days: int) -> Dict[str, float]:
        """预测植物生长状态"""
        # 使用简单的规则和统计特征进行预测，避免复杂的深度学习模型
        import random
        return {
            'growth_rate': random.uniform(0.6, 0.95),
            'health_score': random.uniform(0.7, 0.98),
            'yield_potential': random.uniform(0.5, 0.9)
        }


class LightRecipeGenerator:
    """光配方生成器 - 简化实现，移除JAX/Flax依赖"""
    
    def generate(self, 
                 crop_config: CropConfig,
                 current_stage: PlantGrowthStage,
                 target_objective: str,
                 environmental_conditions: Dict[str, float]) -> SpectrumConfig:
        """生成最优光配方"""
        
        # 基于作物类型和生长阶段的基础配方
        base_recipe = self._get_base_recipe(crop_config, current_stage)
        
        # 根据目标优化配方
        optimized_recipe = self._optimize_for_objective(
            base_recipe, target_objective, environmental_conditions
        )
        
        # 验证31:1白红配比
        if optimized_recipe.white_red_ratio < 30:
            optimized_recipe.white_light = optimized_recipe.red_660nm * 31
        elif optimized_recipe.white_red_ratio > 32:
            optimized_recipe.red_660nm = optimized_recipe.white_light / 31
        
        return optimized_recipe
    
    def _get_base_recipe(self, crop_config: CropConfig, stage: PlantGrowthStage) -> SpectrumConfig:
        """获取基础光配方"""
        # 根据不同作物和生长阶段的基础配方
        if "苗期" in stage.stage_name:
            return SpectrumConfig(
                uv_380nm=0.02,  # 苗期减少紫外线
                far_red_720nm=0.08,
                white_light=0.75,
                red_660nm=0.15
            )
        elif "开花" in stage.stage_name:
            return SpectrumConfig(
                uv_380nm=0.08,  # 开花期增加紫外线促进次生代谢
                far_red_720nm=0.12,  # 调控开花时间
                white_light=0.65,
                red_660nm=0.15
            )
        else:  # 结果期
            return SpectrumConfig(
                uv_380nm=0.06,
                far_red_720nm=0.1,
                white_light=0.7,
                red_660nm=0.14
            )
    
    def _optimize_for_objective(self, 
                               recipe: SpectrumConfig,
                               objective: str,
                               env_conditions: Dict[str, float]) -> SpectrumConfig:
        """根据目标优化配方"""
        
        optimized = SpectrumConfig(
            uv_380nm=recipe.uv_380nm,
            far_red_720nm=recipe.far_red_720nm,
            white_light=recipe.white_light,
            red_660nm=recipe.red_660nm
        )
        
        if objective == "最大化产量":
            # 增加红光促进光合作用
            optimized.red_660nm *= 1.2
            optimized.white_light *= 0.9
        elif objective == "提升甜度":
            # 增加紫外线促进次生代谢物
            optimized.uv_380nm *= 1.5
            optimized.far_red_720nm *= 1.1
        elif objective == "提升抗性":
            # 平衡各波段，增强植物抗性
            optimized.uv_380nm *= 1.3
            optimized.far_red_720nm *= 0.9
        
        # 根据环境条件微调
        if env_conditions.get('temperature', 25) > 28:
            # 高温时减少光照强度
            optimized.white_light *= 0.9
            optimized.red_660nm *= 0.9
        
        # 归一化确保总和为1
        total = optimized.uv_380nm + optimized.far_red_720nm + optimized.white_light + optimized.red_660nm
        if total > 0:
            optimized.uv_380nm /= total
            optimized.far_red_720nm /= total
            optimized.white_light /= total
            optimized.red_660nm /= total
        
        return optimized


class AgricultureAIService:
    """农业AI服务"""
    
    def __init__(self, crop_config_path: Optional[str] = None):
        self.spectrum_analyzer = SpectrumAnalyzer()
        self.growth_model = PlantGrowthModel()
        self.recipe_generator = LightRecipeGenerator()
        
        # 加载作物配置，支持外部配置文件
        self.crop_configs = self._load_crop_configs(crop_config_path)
        
        # 中英文作物名称映射
        self.crop_name_map = {
            "tomato": "番茄",
            "lettuce": "生菜",
            "cabbage": "白菜",
            "spinach": "菠菜",
            "celery": "芹菜",
            "rape": "油菜",
            "strawberry": "草莓",
            "cucumber": "黄瓜",
            "pepper": "辣椒",
            "rose": "玫瑰",
            "lily": "百合",
            "tulip": "郁金香",
            "carnation": "康乃馨"
        }
    
    def _load_crop_configs(self, config_path: Optional[str] = None) -> Dict[str, CropConfig]:
        """加载作物配置，支持从文件或默认配置加载"""
        # 如果提供了配置文件路径，尝试从文件加载
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)
                return self._parse_crop_configs(config_data)
            except Exception as e:
                # 加载失败时使用默认配置
                print(f"Failed to load crop configs from file: {e}, using default configs")
        
        # 使用默认配置
        return self._get_default_crop_configs()
    
    def _parse_crop_configs(self, config_data: Dict) -> Dict[str, CropConfig]:
        """解析作物配置数据"""
        crop_configs = {}
        for crop_name, data in config_data.items():
            growth_stages = []
            for stage_data in data['growth_stages']:
                stage = PlantGrowthStage(
                    stage_name=stage_data['stage_name'],
                    duration_days=stage_data['duration_days'],
                    optimal_temperature=tuple(stage_data['optimal_temperature']),
                    optimal_humidity=tuple(stage_data['optimal_humidity']),
                    light_hours=stage_data['light_hours']
                )
                growth_stages.append(stage)
            
            crop_config = CropConfig(
                crop_name=crop_name,
                growth_stages=growth_stages,
                target_yield=data['target_yield'],
                quality_metrics=data['quality_metrics']
            )
            crop_configs[crop_name] = crop_config
        
        return crop_configs
    
    def _get_default_crop_configs(self) -> Dict[str, CropConfig]:
        """获取默认作物配置"""
        # 返回与之前相同的作物配置，但使用更清晰的结构
        return {
            # 菜叶类
            "生菜": CropConfig(
                crop_name="生菜",
                growth_stages=[
                    PlantGrowthStage("苗期", 15, (18, 22), (70, 80), 14),
                    PlantGrowthStage("生长期", 25, (20, 24), (65, 75), 12)
                ],
                target_yield="提升品质",
                quality_metrics={"脆度": 0.9, "营养含量": 0.8}
            ),
            "白菜": CropConfig(
                crop_name="白菜",
                growth_stages=[
                    PlantGrowthStage("苗期", 20, (15, 20), (70, 80), 12),
                    PlantGrowthStage("莲座期", 30, (18, 23), (65, 75), 10),
                    PlantGrowthStage("结球期", 35, (20, 25), (60, 70), 8)
                ],
                target_yield="最大化产量",
                quality_metrics={"紧实度": 0.9, "口感": 0.8}
            ),
            "菠菜": CropConfig(
                crop_name="菠菜",
                growth_stages=[
                    PlantGrowthStage("苗期", 12, (10, 15), (65, 75), 12),
                    PlantGrowthStage("生长期", 28, (12, 18), (60, 70), 10)
                ],
                target_yield="提升品质",
                quality_metrics={"铁含量": 0.9, "鲜嫩度": 0.85}
            ),
            "芹菜": CropConfig(
                crop_name="芹菜",
                growth_stages=[
                    PlantGrowthStage("苗期", 25, (15, 20), (70, 80), 14),
                    PlantGrowthStage("生长前期", 35, (18, 23), (65, 75), 12),
                    PlantGrowthStage("生长后期", 40, (20, 25), (60, 70), 10)
                ],
                target_yield="最大化产量",
                quality_metrics={"纤维含量": 0.7, "风味": 0.8}
            ),
            "油菜": CropConfig(
                crop_name="油菜",
                growth_stages=[
                    PlantGrowthStage("苗期", 18, (12, 18), (65, 75), 12),
                    PlantGrowthStage("生长期", 27, (15, 22), (60, 70), 10)
                ],
                target_yield="提升品质",
                quality_metrics={"维生素C": 0.9, "水分含量": 0.85}
            ),
            
            # 水果类
            "番茄": CropConfig(
                crop_name="番茄",
                growth_stages=[
                    PlantGrowthStage("苗期", 30, (20, 25), (60, 70), 16),
                    PlantGrowthStage("开花期", 20, (22, 26), (50, 60), 14),
                    PlantGrowthStage("结果期", 45, (24, 28), (45, 55), 12)
                ],
                target_yield="最大化产量",
                quality_metrics={"甜度": 0.8, "维生素C": 0.7}
            ),
            "草莓": CropConfig(
                crop_name="草莓",
                growth_stages=[
                    PlantGrowthStage("苗期", 25, (15, 20), (60, 70), 14),
                    PlantGrowthStage("开花期", 15, (18, 22), (50, 60), 12),
                    PlantGrowthStage("结果期", 30, (20, 25), (45, 55), 10)
                ],
                target_yield="提升甜度",
                quality_metrics={"甜度": 0.9, "色泽": 0.85}
            ),
            "黄瓜": CropConfig(
                crop_name="黄瓜",
                growth_stages=[
                    PlantGrowthStage("苗期", 25, (18, 23), (65, 75), 14),
                    PlantGrowthStage("开花期", 15, (20, 25), (55, 65), 12),
                    PlantGrowthStage("结果期", 40, (22, 28), (50, 60), 10)
                ],
                target_yield="最大化产量",
                quality_metrics={"脆度": 0.85, "苦味": 0.9}
            ),
            "辣椒": CropConfig(
                crop_name="辣椒",
                growth_stages=[
                    PlantGrowthStage("苗期", 35, (20, 25), (60, 70), 14),
                    PlantGrowthStage("开花期", 20, (22, 27), (55, 65), 12),
                    PlantGrowthStage("结果期", 50, (24, 29), (50, 60), 10)
                ],
                target_yield="提升品质",
                quality_metrics={"辣度": 0.8, "维生素C": 0.9}
            ),
            
            # 花草类
            "玫瑰": CropConfig(
                crop_name="玫瑰",
                growth_stages=[
                    PlantGrowthStage("苗期", 40, (18, 23), (60, 70), 12),
                    PlantGrowthStage("营养生长期", 60, (20, 25), (55, 65), 14),
                    PlantGrowthStage("开花期", 30, (22, 27), (50, 60), 16)
                ],
                target_yield="提升品质",
                quality_metrics={"花期长度": 0.9, "花色鲜艳度": 0.85}
            ),
            "百合": CropConfig(
                crop_name="百合",
                growth_stages=[
                    PlantGrowthStage("苗期", 50, (15, 20), (65, 75), 12),
                    PlantGrowthStage("生长中期", 70, (18, 23), (60, 70), 14),
                    PlantGrowthStage("开花期", 25, (20, 25), (55, 65), 16)
                ],
                target_yield="提升品质",
                quality_metrics={"花茎长度": 0.8, "花期": 0.85}
            ),
            "郁金香": CropConfig(
                crop_name="郁金香",
                growth_stages=[
                    PlantGrowthStage("苗期", 35, (10, 15), (60, 70), 10),
                    PlantGrowthStage("生长中期", 45, (15, 20), (55, 65), 12),
                    PlantGrowthStage("开花期", 15, (18, 22), (50, 60), 14)
                ],
                target_yield="提升品质",
                quality_metrics={"花色": 0.9, "花型": 0.8}
            ),
            "康乃馨": CropConfig(
                crop_name="康乃馨",
                growth_stages=[
                    PlantGrowthStage("苗期", 30, (18, 23), (65, 75), 12),
                    PlantGrowthStage("生长中期", 50, (20, 25), (60, 70), 14),
                    PlantGrowthStage("开花期", 25, (22, 27), (55, 65), 16)
                ],
                target_yield="提升品质",
                quality_metrics={"花茎硬度": 0.85, "花期": 0.9}
            )
        }
    
    def generate_light_recipe(self, 
                             crop_type: str,
                             current_day: int,
                             target_objective: str,
                             environment: Dict[str, float]) -> Dict[str, any]:
        """生成光配方"""
        
        # 中英文作物名称映射
        if crop_type.lower() in self.crop_name_map:
            crop_type = self.crop_name_map[crop_type.lower()]
        
        if crop_type not in self.crop_configs:
            raise ValueError(f"未知作物类型: {crop_type}")
        
        crop_config = self.crop_configs[crop_type]
        
        # 确定当前生长阶段
        current_stage = self._get_current_stage(crop_config, current_day)
        
        # 生成光配方
        recipe = self.recipe_generator.generate(
            crop_config=crop_config,
            current_stage=current_stage,
            target_objective=target_objective,
            environmental_conditions=environment
        )
        
        return {
            "recipe": recipe,
            "current_stage": current_stage.stage_name,
            "light_hours": current_stage.light_hours,
            "recommendations": self._get_growth_recommendations(crop_config, current_stage)
        }
    
    def _get_current_stage(self, crop_config: CropConfig, current_day: int) -> PlantGrowthStage:
        """获取当前生长阶段"""
        accumulated_days = 0
        for stage in crop_config.growth_stages:
            accumulated_days += stage.duration_days
            if current_day <= accumulated_days:
                return stage
        # 如果超过所有阶段，返回最后一个阶段
        return crop_config.growth_stages[-1]
    
    def _get_growth_recommendations(self, 
                                  crop_config: CropConfig,
                                  stage: PlantGrowthStage) -> List[str]:
        """获取生长建议"""
        recommendations = []
        
        recommendations.append(f"保持温度在{stage.optimal_temperature[0]}-{stage.optimal_temperature[1]}°C")
        recommendations.append(f"保持湿度在{stage.optimal_humidity[0]}%-{stage.optimal_humidity[1]}%")
        recommendations.append(f"每日光照{stage.light_hours}小时")
        
        if "开花" in stage.stage_name:
            recommendations.append("适当增加磷钾肥促进开花")
        elif "结果" in stage.stage_name:
            recommendations.append("增加钙肥防止果实病害")
        
        return recommendations