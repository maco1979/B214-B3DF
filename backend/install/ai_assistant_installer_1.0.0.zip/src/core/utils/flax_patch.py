"""
Flax兼容性补丁，用于解决Python 3.14中Flax的dataclasses问题

该补丁修复了Flax中'variable_filter'字段缺少类型注解的问题
必须在导入flax之前调用apply_flax_patch()
"""

import sys
from typing import Optional, Any

_patch_applied = False

def apply_flax_patch():
    """应用Flax兼容性补丁 - 必须在导入flax之前调用"""
    global _patch_applied
    
    if _patch_applied:
        return True
        
    try:
        import dataclasses
        
        # 获取真正的原始_process_class函数（避免递归调用）
        if hasattr(dataclasses, '_process_class') and not hasattr(dataclasses._process_class, '__patched__'):
            original_process_class = dataclasses._process_class
            
            def patched_process_class(cls, *args, **kwargs):
                """修补后的_process_class函数，专门处理'variable_filter'字段"""
                # 检查类中是否有variable_filter属性
                has_variable_filter = False
                for c in cls.__mro__:
                    if 'variable_filter' in vars(c):
                        has_variable_filter = True
                        break
                
                # 如果有variable_filter属性但没有类型注解，添加一个
                if has_variable_filter:
                    if not hasattr(cls, '__annotations__'):
                        cls.__annotations__ = {}
                    if 'variable_filter' not in cls.__annotations__:
                        cls.__annotations__['variable_filter'] = Optional[Any]
                
                # 调用真正的原始函数
                return original_process_class(cls, *args, **kwargs)
            
            # 标记函数为已修补，避免重复应用
            patched_process_class.__patched__ = True
            
            # 替换dataclasses._process_class
            dataclasses._process_class = patched_process_class
            _patch_applied = True
            print("Flax兼容性补丁应用成功")
            return True
        else:
            # 补丁已经应用或无法获取原始函数
            _patch_applied = True
            print("Flax兼容性补丁已经应用")
            return True
        
    except Exception as e:
        print(f"Flax补丁应用失败: {e}")
        return False
