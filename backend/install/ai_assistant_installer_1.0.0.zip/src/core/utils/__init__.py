"""
Core utilities package for the AI project
"""

from .risk_category_determiner import (
    determine_risk_category_extended,
    determine_risk_category_robust,
    determine_risk_category_basic,
    determine_risk_category_simple,
    determine_risk_category_enterprise,
    RiskLevel
)

from .flax_patch import apply_flax_patch
from .security_utils import SecurityUtils, security_utils, encrypt_sensitive_data, verify_password_decorator
from .retry_utils import (
    RetryExhaustedError,
    CircuitBreaker,
    BackupManager,
    retry,
    retry_database,
    retry_external,
    retry_cache,
    backup_manager,
    circuit_breakers
)

from .logging_utils import (
    LoggerManager,
    JSONFormatter,
    logger_manager,
    get_logger,
    log_context,
    debug,
    info,
    warning,
    error,
    critical
)

from .cache_utils import (
    CacheManager,
    CacheItem,
    default_cache_manager,
    get_cache,
    set_cache,
    delete_cache,
    clear_cache,
    cache
)

__all__ = [
    # 风险分类
    "determine_risk_category_extended",
    "determine_risk_category_robust", 
    "determine_risk_category_basic",
    "determine_risk_category_simple",
    "determine_risk_category_enterprise",
    "RiskLevel",
    
    # Flax补丁
    "apply_flax_patch",
    
    # 安全工具
    "SecurityUtils",
    "security_utils",
    "encrypt_sensitive_data",
    "verify_password_decorator",
    
    # 重试和容错
    "RetryExhaustedError",
    "CircuitBreaker",
    "BackupManager",
    "retry",
    "retry_database",
    "retry_external",
    "retry_cache",
    "backup_manager",
    "circuit_breakers",
    
    # 日志管理
    "LoggerManager",
    "JSONFormatter",
    "logger_manager",
    "get_logger",
    "log_context",
    "debug",
    "info",
    "warning",
    "error",
    "critical",
    
    # 缓存管理
    "CacheManager",
    "CacheItem",
    "default_cache_manager",
    "get_cache",
    "set_cache",
    "delete_cache",
    "clear_cache",
    "cache"
]